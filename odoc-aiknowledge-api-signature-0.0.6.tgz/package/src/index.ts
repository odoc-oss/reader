import HmacSHA256 from 'crypto-js/hmac-sha256';
import Base64 from 'crypto-js/enc-base64';

/**
 * Generate signature
 */
const generateSignature = (p: string) => {
  const rd = Math.ceil(Math.random() * 100000000);
  const timestamp = Date.now();
  const signature = HmacSHA256(`rd=${rd}&timestamp=${timestamp}\n${p}`, 'rp1012162');
  return `rd=${rd}&timestamp=${timestamp}&signature=${encodeURIComponent(Base64.stringify(signature))}`;
};

export default generateSignature;
