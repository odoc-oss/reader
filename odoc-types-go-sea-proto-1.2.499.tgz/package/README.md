```bash
# 0. install
yarn install --registry=https://registry.npm.taobao.org

# 1. npm login
node ./scripts/login.js

# 2. npm version
npm version patch

# 3. npm publish
npm publish
```