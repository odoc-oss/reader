/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate.protocol.response";

/**
 * 接口描述:腾讯翻译-中文翻译接口出参
 *   接口url:/ts/tencent/zh-cn
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface TencentTranslateResponse {
  /** targetContent */
  targetContent: string;
}
