/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/** url: /aiKnowledge/getUserInfo */
export interface GetUserInfoReq {
  userId: string;
}

/** url: /aiKnowledge/userCenter/getUserStatInfo */
export interface GetUserStatInfoReq {
  userId: string;
}
