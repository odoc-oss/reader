/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/**
 * console管理后台-获取banner列表
 * url: /aiKnowledge/activity/school/open
 * serviceId: microService-app-aiKnowledge
 */
export interface SchollOpenReq {
}

export interface SchollOpenResp {
  /** 活动URL */
  activityUrl: string;
  /** channel */
  channel: string;
  /** 活动图片URL */
  imageUrl: string;
}
