/* eslint-disable */
import type { VerifyStatus } from "../user/PersonalInfoAuthEnum";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/**
 * 更新用户资料
 * url: /personal/userCenter/updateUserInfo
 */
export interface UpdateUserInfoReq {
  /** 头像url */
  avatarUrl?:
    | string
    | undefined;
  /** nickName */
  nickName?:
    | string
    | undefined;
  /** realName */
  realName?:
    | string
    | undefined;
  /** 个人描述 */
  description?:
    | string
    | undefined;
  /** 职业 */
  profession?:
    | string
    | undefined;
  /** 研究领域 */
  researchField?:
    | string
    | undefined;
  /** 学校单位 */
  schoolCompany?: string | undefined;
}

/**
 * 更新用户资料(个人信息补齐)
 * url: /personal/userCenter/updateUserInfoV2
 */
export interface UpdateUserInfoReqV2 {
  /** 头像url */
  avatarUrl?:
    | string
    | undefined;
  /** nickName */
  nickName?:
    | string
    | undefined;
  /** realName */
  realName?:
    | string
    | undefined;
  /** 个人描述 */
  description?:
    | string
    | undefined;
  /** 扩展信息 */
  extUserInfo?: ExtUserInfo | undefined;
}

export interface ExtUserInfo {
  /** 学历Id */
  educationId: string;
  /** 学历 */
  education: string;
  /** 学校/单位 */
  unit: string;
  /** 身份Id */
  identityTypeId: string;
  /** 身份类型 */
  identityType: string;
  /** 专业Id */
  specialtyTypeId: string;
  /** 专业 */
  specialtyType: string;
  /** 入学时间 */
  enrollmentTime: string;
  /** 部门Id */
  departmentId: string;
  /** 所在科室' */
  department: string;
  /** 职称Id */
  titleId: string;
  /** 职称 */
  title: string;
  /** 研究方向 */
  researchDirection: string;
  /** 是否已认证 */
  verifyStatus: VerifyStatus;
  /** 国家电话区号 */
  countryCode?: string | undefined;
}

/**
 * 更新用户资料(个人信息补齐)
 * url: /personal/userCenter/getExtUserInfo
 * method: get
 */
export interface GetExtUserInfoReq {
}

export interface GetExtUserInfoResp {
  /** 扩展信息 */
  extUserInfo?:
    | ExtUserInfo
    | undefined;
  /** 未认证，启用认证场景值 */
  sceneId: string;
}
