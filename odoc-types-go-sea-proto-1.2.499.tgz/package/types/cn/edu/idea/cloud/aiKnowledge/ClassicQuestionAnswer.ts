/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/** url: /classicQuestionAnswer/delete */
export interface DeleteClassicQuestionAnswerReq {
  answerId: string;
}
