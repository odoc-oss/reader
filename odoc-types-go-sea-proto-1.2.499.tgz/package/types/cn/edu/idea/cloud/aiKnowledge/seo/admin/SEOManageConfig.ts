/* eslint-disable */
import type { SeoPageType, TdkConfig } from "../SEOCommon";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.seo.admin";

/**
 * 接口描述: 获取seo模板信息配置
 * 	接口url: /admin/seo/manage/list
 * 	接口请求方式: POST
 */
export interface SeoManageListReq {
  pageType: SeoPageType;
  /** 0表示未发布，1表示已发布，4表示已下架 */
  publishStatus: number[];
  currentPage: number;
  pageSize: number;
}

export interface SeoManageListResp {
  /** total，总页数 */
  total: string;
  /** pageNum，当前页 */
  pageNum: number;
  /** pageSize，每页的数量 */
  pageSize: number;
  /** 配置信息 */
  config: TdkConfig[];
}

/**
 * 接口描述: 添加seo模板信息
 * 	接口url: /admin/seo/manage/add
 * 	接口请求方式: POST
 */
export interface SeoManageAddReq {
  config?: TdkConfig | undefined;
}

export interface SeoManageAddResp {
  config?: TdkConfig | undefined;
}

/**
 * 接口描述: 修改seo模板信息(不覆盖原来的数据)
 * 	接口url: /admin/seo/manage/modify
 * 	接口请求方式: POST
 */
export interface SeoManageModifyReq {
  config?: TdkConfig | undefined;
}

export interface SeoManageModifyReps {
  config?: TdkConfig | undefined;
}

/**
 * 接口描述: 下架seo模板信息
 * 	接口url: /admin/seo/manage/offShelf
 * 	接口请求方式: POST
 */
export interface SeoManageOffShelfReq {
  id: string;
}

export interface SeoManageOffShelfReps {
}

/**
 * 接口描述: 发布seo模板信息
 * 	接口url: /admin/seo/manage/publish
 * 	接口请求方式: POST
 */
export interface SeoManagePublishReq {
  id: string;
}

export interface SeoManagePublishReps {
}
