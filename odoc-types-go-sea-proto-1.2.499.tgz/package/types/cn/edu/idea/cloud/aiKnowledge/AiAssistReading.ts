/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

export enum AnswerStatus {
  PENDING = 0,
  SUCCESS = 1,
  ERROR = 2,
  UNRECOGNIZED = -1,
}

export enum Type {
  QUESTION = 0,
  ANSWER = 1,
  UNRECOGNIZED = -1,
}

export enum QuestionType {
  SELECT_TEXT = 0,
  ASK_QUESTION = 1,
  IMAGE_QUESTION = 2,
  UNRECOGNIZED = -1,
}

export enum GptQuestionType {
  ADDITIONAL_TEXT = 0,
  COMMON_ASK = 1,
  UNRECOGNIZED = -1,
}

export enum LikeDislikeType {
  LIKE = 0,
  DISLIKE = 1,
  UNRECOGNIZED = -1,
}

export enum LangType {
  CHINESE = 0,
  ENGLISH = 1,
  UNRECOGNIZED = -1,
}

export enum BanStrategy {
  NONE = 0,
  INPUT = 1,
  UNRECOGNIZED = -1,
}

export enum Satisfaction {
  EXCELLENT = 0,
  GOOD = 1,
  AVERAGE = 2,
  INFERIOR = 3,
  TERRIBLE = 4,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述:点赞
 * 	接口url:/aiAnswer/like
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface AiAnswerLikeReq {
  /** 回答id */
  answerId: string;
}

/**
 * 接口描述:取消点赞
 * 	接口url:/aiAnswer/cancelLike
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface AiAnswerCancelLikeReq {
  /** 回答id */
  answerId: string;
}

/**
 * 接口描述:点踩
 * 	接口url:/aiAnswer/dislike
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface AiAnswerDisLikeReq {
  /** 回答id */
  answerId: string;
}

/**
 * 接口描述:取消点踩
 * 	接口url:/aiAnswer/cancelDislike
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface AiAnswerCancelDisLikeReq {
  /** 回答id */
  answerId: string;
}

/**
 * 接口描述:点踩反馈意见
 * 	接口url:/aiAnswer/dislikeFeedback
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface AiAnswerDisLikeFeedbackReq {
  /** 回答id */
  answerId: string;
  /** 反馈意见 */
  feedback: string;
}

/**
 * 接口描述:选区提问
 * 	接口url:/aiAssistReadingQa/selectTextQuestion
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: QuestionAnswerInfo
 */
export interface SelectTextQuestionReq {
  noteId: string;
  pdfId: string;
  /** 选择的文本 */
  text: string;
  /** page_num */
  pageNum: number;
  /** 选取的boundingbox 可以不传，业务未使用 */
  boundingBox: RectOptions[];
  pdfUrl: string;
  /** viewport 可以不传，业务未使用 */
  viewport?: Viewport | undefined;
  question: string;
  /** 参考LangType，填写：CHINESE、ENGLISH */
  lang: string;
  /** 是否深度思考 */
  isDeepThinking: boolean;
}

/**
 * 接口描述:截图提问
 * 	接口url:/aiAssistReadingQa/imageQuestion
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: QuestionAnswerInfo
 */
export interface ImageQuestionRequest {
  noteId: string;
  pdfId: string;
  pdfUrl: string;
  /** 参考LangType，填写：CHINESE、ENGLISH */
  lang: string;
  imageUrl: string;
  pageNumber: number;
}

/**
 * 接口描述:输入文本提问
 * 	接口url:/aiAssistReadingQa/askQuestion
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: QuestionAnswerInfo
 */
export interface AskQuestionReq {
  noteId: string;
  pdfId: string;
  /** 用户输入的文本 */
  text: string;
  answerId?: string | undefined;
  pdfUrl: string;
  /** 参考LangType，填写：CHINESE、ENGLISH */
  lang: string;
  /** 第一次发起提问题 */
  firstAskQuestion: boolean;
  /** 是否深度思考 */
  isDeepThinking: boolean;
}

/**
 * 接口描述:输入文本提问_demo
 * 	接口url:/gptQa/askQuestion
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: QuestionAnswerInfo
 */
export interface GptAskQuestionReq {
  /** 用户输入的文本 */
  text: string;
  /** 附加文本信息 */
  additionalText?:
    | string
    | undefined;
  /**  */
  traceId?: string | undefined;
}

export interface GptAskQuestionResponse {
  traceId: string;
  answer?: AnswerInfo | undefined;
}

/**
 * 接口描述:根据id获取回答
 * 	接口url:/aiAssistReadingQa/getAiAnswerById
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: AnswerInfo
 *
 *  接口url:/aiAssistReadingQa/getAiAnswerById/v2
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: GetAiAnswerByIdResp
 */
export interface GetAiAnswerByIdReq {
  answerId: string;
}

export interface GetAiAnswerByIdResp {
  answerInfo?: AnswerInfo | undefined;
  message: string;
  banStrategy: BanStrategy;
}

/**
 * 接口描述:根据答案ID进行重试
 * 	接口url:/aiAssistReadingQa/retryByAnswerId
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: AnswerInfo
 */
export interface RetryByAnswerIdReq {
  answerId: string;
}

/**
 * 接口描述:获取列表
 * 	接口url:/aiAssistReadingQa/getList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetListReq {
  pageSize: number;
  minId?: string | undefined;
  noteId: string;
}

export interface GetListResponse {
  /** 分页结果,是否有下一页 */
  hasNextPage: boolean;
  list: QuestionAnswerInfo[];
  changeAnswerCountLimit: number;
}

/**
 * 接口描述:辅助写论文
 * 	接口url:/aiAssistReadingQa/helpWriting
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface PaperWritingAssistRequest {
  originalText: string;
  commandText: string;
}

export interface QuestionAnswerInfo {
  question?: QuestionInfo | undefined;
  answer?: AnswerInfo | undefined;
  answers: AnswerInfo[];
}

export interface QuestionInfo {
  id: string;
  questionType: QuestionType;
  question: string;
  /** 引用的内容 */
  quoteInfo?: QuoteInfo | undefined;
  createDate: string;
  imageUrl?: string | undefined;
}

export interface AnswerInfo {
  id: string;
  /** 回答内容,当ChatGPT还没返回结果时,该字段可能为空 */
  answer?: string | undefined;
  createDate: string;
  /** 是否点赞 */
  isLike: boolean;
  /** 是否点踩 */
  isDisLike: boolean;
  /** 回答的状态 */
  answerStatus: AnswerStatus;
  /** 是否可以重试 */
  canRetry: boolean;
  errorMessage: string;
  /** 回答内容中，是否有后处理的提问 */
  hanleProcessedQuestion: string[];
  showSatisfactionFeedback?:
    | boolean
    | undefined;
  /** 是否是优化后的结果 */
  isOptimized?:
    | boolean
    | undefined;
  /** 优化后的结果反馈 */
  optimizedFeedbackResult?:
    | string
    | undefined;
  /** 是否已退豆 */
  isRefundAiBean?:
    | boolean
    | undefined;
  /** 数据创建时间 */
  createTime: string;
  /** 是否需要退豆 */
  needRefundAiBean?: boolean | undefined;
}

export interface QuoteInfo {
  quoteContent: string;
}

export interface RectOptions {
  /** 锚点横坐标 */
  x: number;
  /** 锚点纵坐标 */
  y: number;
  /** 选区宽度 */
  width: number;
  /** 选区高度 */
  height: number;
}

export interface Viewport {
  /** pdf宽度 */
  width: number;
  /** pdf高度 */
  height: number;
}

/**
 * 接口描述:换个答案
 * 	接口url:/aiAssistReadingQa/answer/change
 * 	接口请求方式: GET
 * 	参数格式:url参数
 */
export interface ChangeAnswerRequest {
  /** 字段同上 */
  lang: string;
  questionId: string;
  /** 用于追问场景,表示针对某个答案再做提问 */
  answerId?:
    | string
    | undefined;
  /** 是否属于要优化的内容 */
  optimizeId?: string | undefined;
}

export interface ChangeAnswerResponse {
  answer?: AnswerInfo | undefined;
}

/**
 * 接口描述:满意度反馈
 * 	接口url:/aiAssistReadingQa/satisfaction/feedback
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  返回通用的状态码
 *  serviceId:microservice-ai-reading
 */
export interface SatisfactionFeedbackRequest {
  answerId: string;
  satisfaction: Satisfaction;
}
