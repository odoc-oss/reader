/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.homePage.interest";

/**
 * 接口描述: 自动完成，获取兴趣-领域选择列表
 * 	接口url: /userInterest/fosAutoComplete
 * 	接口请求方式: POST
 */
export interface AutoCompleteReq {
  /** 模糊查询兴趣名 */
  query: string;
  /** 长度限制，允许空，最多返回十个 */
  limit: number;
}

export interface FosItem {
  id: string;
  name: string;
  parentName: string;
  grandParentName: string;
}

export interface AutoCompleteResp {
  fosItems: FosItem[];
}

/**
 * 接口描述: 保存我的兴趣
 * 	接口url: /userInterest/save
 * 	接口请求方式: POST
 */
export interface SaveInterestReq {
  ids: string[];
}

export interface SaveInterestResp {
}

/**
 * 接口描述: 获取我的兴趣
 * 	接口url: /userInterest/get
 * 	接口请求方式: get
 */
export interface GetInterestReq {
}

export interface GetInterestResp {
  fosItems: FosItem[];
}

/**
 * 接口描述: 获取热门，包含换一批
 * 	接口url: /userInterest/getFosHots
 * 	接口请求方式: get
 */
export interface GetHotInterestReq {
  /** 索引，首次从1开始 */
  latestIndex: number;
}

export interface GetHotInterestResp {
  fosItems: FosItem[];
  /** 当前索引 */
  latestIndex: number;
}
