/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

export enum TranslationType {
  AUTHOR = 0,
  MACHINE = 1,
  UNRECOGNIZED = -1,
}

/**
 * path: /aiKnowledge/paper/abstract/translation
 * method: post
 * description: 获取翻译
 */
export interface AbstractTranslationRequest {
  translationType: TranslationType;
  paperId: string;
}

export interface AbstractTanslationResponse {
  abstractTranslation: string;
  translater?: Translater | undefined;
}

export interface Translater {
  avatarUrl: string;
  nickName: string;
  userId: string;
  tags: string;
}

/**
 * path: /aiKnowledge/paper/summary/ai
 * method: get
 * description: AI理解论文
 */
export interface AiSummaryRequest {
  paperId: string;
}

export interface AiSummaryResponse {
  summary?: string | undefined;
  questionAndAnswerItems: QuestionAndAnswerItem[];
}

export interface QuestionAndAnswerItem {
  question: string;
  answer: string;
}
