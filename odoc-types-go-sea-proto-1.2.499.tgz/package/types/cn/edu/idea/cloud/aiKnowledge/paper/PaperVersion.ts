/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.paper";

export enum PaperVersionType {
  PAPER_LINK = 0,
  PAPER_PDF = 1,
  UNRECOGNIZED = -1,
}

/**
 * 论文详情页获取多版本PDF、链接相关信息 （不强制登录）
 * GET /aiKnowledge/paper/versions
 */
export interface GetPaperVersionsRequest {
  paperId: string;
}

export interface GetPaperVersionsResponse {
  publicVersions: PaperVersionInfo[];
  privateVersions: PaperVersionInfo[];
}

export interface PaperVersionInfo {
  type: PaperVersionType;
  name: string;
  pdfId: string;
  jumpUrl: string;
  curVersion: boolean;
  lastVersion: boolean;
  datePrefix: string;
}
