/* eslint-disable */
import type { TranslateResp } from "../translate/TranslateProto";
import type { RectOptions } from "./Common";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.notev2";

export enum displayMode {
  DEFAULT = 0,
  GLOBAL = 1,
  HIDDEN = 2,
  UNRECOGNIZED = -1,
}

export enum WordColor {
  /** BLUE - 极客蓝 */
  BLUE = 0,
  /** CYAN - 青色 */
  CYAN = 1,
  /** PURPLE - 紫色 */
  PURPLE = 2,
  /** AURATUS - 金黄色 */
  AURATUS = 3,
  /** ROSE_RED -  */
  ROSE_RED = 4,
  UNRECOGNIZED = -1,
}

/**
 * 添加/更新总结
 * url = /paperNote/summary/saveOrUpdate
 * method = POST
 */
export interface SaveOrUpdateSummaryReq {
  noteId: string;
  content: string;
}

/**
 * 根据noteId获取总结
 * url = /paperNote/summary/getByNoteId
 * method = POST
 */
export interface GetSummaryReq {
  noteId: string;
}

export interface GetSummaryResponse {
  content: string;
  modifyDate: string;
  docName: string;
}

/**
 * 保存生词
 * url = /paperNote/word/save
 * method = POST
 */
export interface SaveWordReq {
  noteId: string;
  wordInfo?: WordInfo | undefined;
}

export interface SaveWordResponse {
  id: string;
}

/**
 * 单词配置
 * url = /paperNote/word/config
 * method = POST
 */
export interface ChangeWordConfigReq {
  noteId: string;
  color: WordColor;
  displayMode: displayMode;
}

/**
 * 更新单词
 * url = /paperNote/word/update
 * method = POST
 */
export interface UpdateWordReq {
  wordId: string;
  /** 只支持更新解释部分 */
  wordInfo?: TranslateResp | undefined;
}

/**
 * 删除单词
 * url = /paperNote/word/delete
 * method = POST
 */
export interface DeleteWordReq {
  wordId: string;
}

/**
 * 根据noteId获取生词列表
 * url = /paperNote/word/getByNoteId
 * method = POST
 */
export interface GetWordsReq {
  noteId: string;
  currentPage: number;
  pageSize: number;
  minLoadedId?: string | undefined;
}

export interface GetWordsResponse {
  words: WordInfo[];
  total: number;
  color: WordColor;
  displayMode: displayMode;
}

/**
 * 笔记管理TAB——总结
 * url: /noteManage/summary/getList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetSummaryListReq {
}

export interface GetSummaryListResponse {
  /** 有总结的文献数量 */
  total: number;
  folderInfos: NoteManageFolderInfo[];
  unclassifiedDocInfos: NoteManageDocInfo[];
}

export interface NoteManageFolderInfo {
  /** 文件夹名 */
  name: string;
  /** 数量 */
  count: number;
  /** 文件夹id */
  folderId: string;
  /** 子文件夹 */
  childrenFolders: NoteManageFolderInfo[];
  /** 文献信息 */
  docInfos: NoteManageDocInfo[];
}

export interface NoteManageDocInfo {
  /** 文献名 */
  docName: string;
  /** 文献id */
  docId: string;
  /** 笔记id */
  noteId: string;
  modifyDate?: string | undefined;
}

/**
 * 笔记管理TAB——单词
 * url: /noteManage/word/getList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetWordListReq {
}

export interface GetWordListResponse {
  /** 单词数量 */
  total: number;
  folderInfos: NoteManageFolderInfo[];
  unclassifiedDocInfos: NoteManageDocInfo[];
}

/**
 * 笔记管理TAB——摘录
 * url: /noteManage/extract/getList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetExtractListReq {
}

export interface GetExtractListResponse {
  /** 数量 */
  total: number;
  folderInfos: NoteManageFolderInfo[];
  unclassifiedDocInfos: NoteManageDocInfo[];
}

/**
 * 笔记管理TAB——根据folderId获取总结列表
 * url: /noteManage/summary/getListByFolderId
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetSummaryListByFolderIdReq {
  /** 全部的时候可不传 */
  folderId?: string | undefined;
  currentPage: number;
  pageSize: number;
}

export interface GetSummaryListByFolderIdResponse {
  /** 数量 */
  total: number;
  docInfos: NoteManageDocInfo[];
}

/**
 * 笔记管理TAB——根据folderId获取单词列表
 * url: /noteManage/word/getListByFolderId
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetWordListByFolderIdReq {
  /** 全部单词的时候可不传 */
  folderId?: string | undefined;
  currentPage: number;
  pageSize: number;
}

export interface GetWordListByFolderIdResponse {
  /** 单词数量 */
  total: number;
  words: WordInfo[];
}

export interface WordInfo {
  word: string;
  translateInfo?:
    | TranslateResp
    | undefined;
  /** 单词在pdf的位置 */
  rectangle: RectOptions[];
  id?: string | undefined;
}
