/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.paper";

/**
 * 接口描述: 获取全文翻译历史记录
 * 	接口url: /fullTextTranslate/getHistoryList
 * 	接口请求方式: POST
 */
export interface GetHistoryListReq {
}

export interface GetHistoryListResponse {
  historyList: HistoryInfo[];
}

export interface HistoryInfo {
  /** 翻译结果状态码,0=翻译中,1=翻译完成,2=翻译失败 */
  status: number;
  docName: string;
  pdfId?: string | undefined;
  translateTime: string;
}

/**
 * 接口描述: 获取用户剩余翻译次数以及是否解锁权限
 * 	接口url:/fullTextTranslate/getRightInfo
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetFullTextTranslateRightInfoReq {
}

export interface GetFullTextTranslateRightInfoResponse {
  /** 剩余次数 */
  remainCount?:
    | number
    | undefined;
  /** 是否解锁权限 */
  unlockRight: boolean;
  /** 规则说明 */
  ruleDesc: string;
}

/**
 * 接口描述: 翻译
 * 	接口url:/fullTextTranslate/translate
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface TranslateReq {
  /** 需要翻译的文件url */
  needTranslateFileUrl: string;
  pdfId: string;
  userId?: string | undefined;
  takeoutTicketFlag?: boolean | undefined;
}

export interface TranslateResponse {
  /** 译文url */
  translationFileUrl?:
    | string
    | undefined;
  /** 0=上传成功(等待翻译结果),非0=翻译失败 */
  errorCode: string;
  message?: string | undefined;
}

/**
 * 接口描述: 查询翻译状态
 * 	接口url:/fullTextTranslate/getTranslateStatus
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetTranslateStatusReq {
  /** 需要翻译的文件url */
  needTranslateFileUrl: string;
  pdfId: string;
  userId?: string | undefined;
}

export interface GetTranslateStatusResponse {
  translationFileUrl?:
    | string
    | undefined;
  /** 翻译结果状态码,0=翻译中,1=翻译完成,2=翻译失败,3=无翻译记录 */
  status: number;
  /** 翻译进度 */
  progressPercent?:
    | string
    | undefined;
  /** 原文/译文块对照信息 */
  alignment?: string | undefined;
}
