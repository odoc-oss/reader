/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate";

/**
 * 【发音接口】
 * url: /translate/pronunciation
 * method: POST
 * server-id: microService-translate
 */
export interface PronunciationReq {
  content: string;
}

/** 响应 */
export interface PronunciationResp {
  /** 翻译内容 */
  targetContent: string;
  /** 音标 */
  ipa: string;
  /** 词性 */
  pos: string[];
}
