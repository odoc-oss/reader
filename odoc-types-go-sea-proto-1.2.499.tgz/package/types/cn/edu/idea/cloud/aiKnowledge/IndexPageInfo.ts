/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/**
 * /aiKnowledge/addEmail
 * http method: POST
 * serviceId: microservice-app-aiKnowledge
 */
export interface AddEmailRequest {
  /** 首页邮箱 */
  email: string;
}

/**
 * /aiKnowledge/addEurekaEmail'
 * http method: POST
 * serviceId: microservice-app-aiKnowledge
 */
export interface AddEurekaEmailRequest {
  /** 首页邮箱 */
  email: string;
  /** 联系人姓名 */
  name: string;
  /** 内容 */
  content: string;
}
