/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate";

export enum TranslateChannel {
  /** TENCENT - 腾讯 */
  TENCENT = 0,
  /** ALI - 阿里 */
  ALI = 1,
  /** GOOGLE - Google */
  GOOGLE = 2,
  /** DEEPL - DeepL */
  DEEPL = 3,
  /** OPENAI - OpenAI */
  OPENAI = 4,
  UNRECOGNIZED = -1,
}

export interface TxConfig {
  id?:
    | string
    | undefined;
  /** 是否已验证 */
  verified: boolean;
  /** 名称(可编辑) */
  name: string;
  /** 腾讯翻译君 secretId */
  txSecretId: string;
  /** 腾讯翻译君 secretKey */
  txSecretKey: string;
  /** 添加时间 */
  createDate: string;
}

export interface AliConfig {
  id?:
    | string
    | undefined;
  /** 是否已验证 */
  verified: boolean;
  /** 名称(可编辑) */
  name: string;
  /** 阿里翻译 AccessKey ID */
  aliAccessKeyId?:
    | string
    | undefined;
  /** 阿里翻译 AccessKey Secret */
  aliAccessKeySecret?:
    | string
    | undefined;
  /** 阿里翻译 接口版本（通用版/专业版） */
  aliInterfaceVersion?:
    | string
    | undefined;
  /** 添加时间 */
  createDate: string;
}

export interface GoogleConfig {
  id?:
    | string
    | undefined;
  /** 是否已验证 */
  verified: boolean;
  /** 名称(可编辑) */
  name: string;
  /** 谷歌翻译 API Key */
  googleApiKey?:
    | string
    | undefined;
  /** 添加时间 */
  createDate: string;
}

export interface DeepLConfig {
  id?:
    | string
    | undefined;
  /** 是否已验证 */
  verified: boolean;
  /** 名称(可编辑) */
  name: string;
  /** DeepL翻译 Key */
  deepLKey?:
    | string
    | undefined;
  /** DeepL翻译 API（DeepL API Free/DeepL API Pro） */
  deepLApi?:
    | string
    | undefined;
  /** DeepL翻译 Formality（默认/倾向于正式语言/倾向于非正式语言） */
  deepLFormality?:
    | string
    | undefined;
  /** 添加时间 */
  createDate: string;
}

export interface OpenAiConfig {
  id?:
    | string
    | undefined;
  /** 是否已验证 */
  verified: boolean;
  /** 名称(可编辑) */
  name: string;
  /** OpenAI翻译 API Key */
  openAiApiKey?:
    | string
    | undefined;
  /** OpenAI翻译 API域名（默认填写为https://api.openai.com) */
  openAiApiDomain?:
    | string
    | undefined;
  /** OpenAI翻译 模型（GPT-3.5-turbo/GPT-4/GPT-4-32k） */
  openAiModel?:
    | string
    | undefined;
  /** 添加时间 */
  createDate: string;
}

/**
 * 接口描述: 添加接口
 * 	接口url:/customTranslateInterface/add
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface AddInterfaceReq {
  /** 翻译渠道 */
  channel: TranslateChannel;
  /** 腾讯 */
  txConfig?:
    | TxConfig
    | undefined;
  /** 阿里翻译 */
  aliConfig?:
    | AliConfig
    | undefined;
  /** 阿里翻译 */
  googleConfig?:
    | GoogleConfig
    | undefined;
  /** DeepL翻译 */
  deepLConfig?:
    | DeepLConfig
    | undefined;
  /** OpenAI翻译 */
  openAiConfig?: OpenAiConfig | undefined;
}

/**
 * 接口描述: 删除接口
 * 	接口url:/customTranslateInterface/delete
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface DeleteInterfaceReq {
  id: string;
}

/**
 * 接口描述: 翻译接口列表
 * 	接口url:/customTranslateInterface/getList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetInterfaceListReq {
}

export interface GetInterfaceListResponse {
  /** 腾讯 */
  txConfig?:
    | TxConfig
    | undefined;
  /** 阿里翻译 */
  aliConfig?:
    | AliConfig
    | undefined;
  /** 阿里翻译 */
  googleConfig?:
    | GoogleConfig
    | undefined;
  /** DeepL翻译 */
  deepLConfig?:
    | DeepLConfig
    | undefined;
  /** OpenAI翻译 */
  openAiConfig?: OpenAiConfig | undefined;
}
