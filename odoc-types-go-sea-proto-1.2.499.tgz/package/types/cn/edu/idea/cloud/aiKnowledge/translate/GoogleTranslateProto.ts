/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate";

/**
 * 接口描述:google渠道-中文翻译接口入参
 *   接口url:/ts/google/client/enable
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface GoogleClientEnableReq {
}

export interface GoogleClientEnableResp {
  /** 是否开启，true为开启 */
  isOpen: boolean;
}

/**
 * 接口描述:google中文翻译接口入参
 *   接口url:/ts/google/zh-cn
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface GoogleTranslateReq {
  /** content */
  content: string;
  /** pdfId */
  pdfId?: string | undefined;
}

export interface GoogleTranslateResp {
  /** 目标翻译 */
  targetContent: string[];
  /** requestId */
  requestId: string;
}
