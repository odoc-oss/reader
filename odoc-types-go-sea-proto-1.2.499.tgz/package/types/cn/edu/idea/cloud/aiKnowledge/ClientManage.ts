/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

export interface GetDownloadUrlsRequest {
  locale: string;
}
