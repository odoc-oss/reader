/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/** 大纲生成的状态 */
export enum WriteOutlineStatusEnum {
  /** OUTLINE_PREPARE_TO_GEN - 准备生成 */
  OUTLINE_PREPARE_TO_GEN = 0,
  /** OUTLINE_GEN_IN_PROGRESS - 生成中 */
  OUTLINE_GEN_IN_PROGRESS = 1,
  /** OUTLINE_GEN_IN_SUCCESS - 生成成功 */
  OUTLINE_GEN_IN_SUCCESS = 2,
  /** OUTLINE_GEN_IN_FAIL - 生成失败 */
  OUTLINE_GEN_IN_FAIL = 3,
  /** OUTLINE_GEN_CAN_RETRY - 是否可以重试 */
  OUTLINE_GEN_CAN_RETRY = 4,
  /** OUTLINE_GEN_IS_LIMIT_REACHED - 已达使用次数的上限 */
  OUTLINE_GEN_IS_LIMIT_REACHED = 5,
  /** OUTLINE_AI_SEQ - ai排队中 */
  OUTLINE_AI_SEQ = 6,
  /** OUTLINE_TIMEOUT - 异常超时 */
  OUTLINE_TIMEOUT = 7,
  UNRECOGNIZED = -1,
}

/** 论文生成的状态 */
export enum WritePaperStatusEnum {
  /** PAPER_PREPARE_TO_GEN - 准备生成 */
  PAPER_PREPARE_TO_GEN = 0,
  /** PAPER_GEN_IN_PROGRESS - 生成中 */
  PAPER_GEN_IN_PROGRESS = 1,
  /** PAPER_GEN_IN_SUCCESS - 生成成功 */
  PAPER_GEN_IN_SUCCESS = 2,
  /** PAPER_GEN_IN_FAIL - 生成失败 */
  PAPER_GEN_IN_FAIL = 3,
  /** PAPER_GEN_CAN_RETRY - 是否可以重试 */
  PAPER_GEN_CAN_RETRY = 4,
  /** PAPER_GEN_IS_LIMIT_REACHED - 已达使用次数的上限 */
  PAPER_GEN_IS_LIMIT_REACHED = 5,
  /** PAPER_AI_SEQ - ai排队中 */
  PAPER_AI_SEQ = 6,
  UNRECOGNIZED = -1,
}

/** 论文风格 */
export enum PaperStyleEnum {
  OFFICIAL = 0,
  CRAZY = 1,
  UNRECOGNIZED = -1,
}

/** 流式返回完成状态 */
export enum StreamStatusEnum {
  /** STREAM_INCOMPLETE - 未完成 */
  STREAM_INCOMPLETE = 0,
  /** STREAM_COMPLETE - 完成 */
  STREAM_COMPLETE = 1,
  /** STREAM_UPDATE - 更正流 */
  STREAM_UPDATE = 2,
  /** STREAM_EXPIRE - 更正流 */
  STREAM_EXPIRE = 3,
  UNRECOGNIZED = -1,
}

/** 论文章节类型 */
export enum PaperTitleTypeEnum {
  /** PAPER_ORDINARY - 普通章节 */
  PAPER_ORDINARY = 0,
  /** PAPER_TITLE - 标题 */
  PAPER_TITLE = 1,
  /** PAPER_ABSTRACTS - 摘要 */
  PAPER_ABSTRACTS = 2,
  /** PAPER_ABSTRACTS_EN - 英文摘要 */
  PAPER_ABSTRACTS_EN = 3,
  /** PAPER_KEYWORDS - 关键词 */
  PAPER_KEYWORDS = 4,
  /** PAPER_SUMMARIZE - 总结 */
  PAPER_SUMMARIZE = 5,
  /** PAPER_INTRODUCTION - 描述 */
  PAPER_INTRODUCTION = 6,
  /** PAPER_REFERENCES - 参考文献 */
  PAPER_REFERENCES = 7,
  /** PAPER_ACKNOWLEDGMENTS - 致谢 */
  PAPER_ACKNOWLEDGMENTS = 8,
  UNRECOGNIZED = -1,
}

/** 论文解锁状态 */
export enum PaperLockStatusEnum {
  /** PAPER_LOCK - 锁定 */
  PAPER_LOCK = 0,
  /** PAPER_UNLOCK - 解锁 */
  PAPER_UNLOCK = 1,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述:生成大纲
 * 	接口url:/paper/genOutline
 *  serverId:  microService-ai-review
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GenOutlineReq {
  /** 专业 */
  major: string;
  /** 标题 */
  title: string;
  /** 风格 */
  paperStyle: PaperStyleEnum;
}

export interface GenOutlineResp {
  writePaperStatus: WriteOutlineStatusEnum;
  taskId: string;
}

/**
 * 接口描述: 流式获取正在生成的大纲
 * 	接口url:/paper/getGenOutlineStreamById
 *  serverId:  microService-ai-review
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface OutlineStreamReq {
  taskId: string;
}

export interface OutlineStreamResp {
  /** 论文大纲生成状态 */
  writeOutlineStatusEnum: WriteOutlineStatusEnum;
  /** 流式返回结束标识 */
  streamStatusEnum: StreamStatusEnum;
  /** 数据 */
  content: string;
  /** 论文id */
  paperId: string;
}

/**
 * 接口描述: 获取已经生成完毕的大纲
 * 	接口url:/paper/getGenOutlineById
 *  serverId:  microService-ai-review
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface GetGenOutlineReq {
  taskId: string;
}

export interface GetGenOutlineResp {
  /** WriteOutlineStatusEnum writeOutlineStatusEnum = 1; */
  paperMetaInfo?: PaperMetaInfo | undefined;
}

/** 论文元数据 */
export interface PaperMetaInfo {
  /** 论文风格 */
  paperStyleEnum: PaperStyleEnum;
  /** 大纲生成状态 */
  writeOutlineStatusEnum: WriteOutlineStatusEnum;
  /** 论文生成状态 */
  writePaperStatusEnum: WritePaperStatusEnum;
  /** 论文锁定状态 */
  paperLockStatusEnum: PaperLockStatusEnum;
  /** 论文标题 */
  paperTitle: string;
  /** 论文内容 */
  paperText: PaperText[];
}

export interface PaperText {
  /** 序号 */
  chapterNumber: number;
  /** 标题 */
  chapterTitle: string;
  /** 内容 */
  chapterContent: string;
  /** 父级节点 */
  chapterParent: string;
  /** 类型 */
  paperTitleTypeEnum: PaperTitleTypeEnum;
}

/**
 * 接口描述:生成论文
 * 	接口url:/paper/genPaper
 *  serverId:  microService-ai-review
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GenPaperReq {
  /**  */
  taskId: string;
  /** 标题 */
  title: string;
  /** 论文生成 */
  paperMetaInfo?: PaperMetaInfo | undefined;
}

export interface GenPaperResp {
  writePaperStatus: WritePaperStatusEnum;
  taskId: string;
}

/**
 * 接口描述: 获取正在生成的论文
 * 	接口url:/paper/getGenPaperStreamById
 *  serverId:  microService-ai-review
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface PaperStreamByIdReq {
  taskId: string;
}

export interface PaperStreamByIdResp {
  /** 论文生成的状态 */
  writePaperStatusEnum: WritePaperStatusEnum;
  /** 流式返回结束标识 */
  streamStatusEnum: StreamStatusEnum;
  /** 数据 */
  content: string;
  /** 论文id */
  paperId: string;
}

/**
 * 接口描述: 获取已经生成的论文
 * 	接口url:/paper/getGenPaperById
 *  serverId:  microService-ai-review
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface GetGenPaperByIdReq {
  taskId: string;
}

export interface GetGenPaperByIdResp {
  paperMetaInfo?:
    | PaperMetaInfo
    | undefined;
  /**  */
  paperHtmlContent: string;
}

/**
 * 接口描述: 转发并永久解锁
 * 	接口url:/paper/forwardAndUnlockPaperById
 *  serverId:  microService-ai-review
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ForwardAndUnlockPaperByIdReq {
  taskId: string;
  /** 转发用户id */
  forwardId: string;
}

export interface ForwardAndUnlockPaperByIdResp {
  /** 免费额度 */
  freeCount: number;
  /** 转发获得的临时额度 */
  temporaryCount: number;
}

/**
 * 接口描述: 转发增加临时额度
 * 	接口url:/paper/forward
 *  serverId:  microService-ai-review
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface ForwardReq {
  taskId: string;
}

export interface ForwardResp {
  /** 转发获得的临时额度 */
  temporaryCount: number;
}

/**
 * 接口描述: 下载论文的word文档
 * 	接口url:/paper/downloadPaperWord
 *  serverId:  microService-ai-review
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface DownloadPaperWordReq {
  taskId: string;
}

export interface DownloadPaperWordResp {
  /** 下载链接 */
  downloadUrl: string;
}

/**
 * 接口描述: 查看用户额度
 * 	接口url:/paper/userPaperInfo
 *  serverId:  microService-ai-review
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface UserPaperResp {
  /** 免费额度 */
  freeCount: string;
  /** 可用临时额度 */
  temporaryCount: string;
}

export interface GetIsCreatorReq {
  /** 论文Id */
  taskId: string;
}

export interface GetIsCreatorResp {
  /** 是否本人 */
  hasSelf: boolean;
}
