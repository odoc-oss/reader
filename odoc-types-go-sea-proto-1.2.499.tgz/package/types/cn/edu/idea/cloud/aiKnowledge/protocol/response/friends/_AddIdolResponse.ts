/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.response.friends";

export interface AddIdolResponse {
  idolId: string;
  idolInfos: IdolInfo[];
  idolInfos1: IdolInfo[];
}

export interface IdolInfo {
  idolId: string;
  name: string;
}
