/* eslint-disable */
import type { VipType } from "../../../user/VipUserInterface";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.vip.proxy";

export enum CodeStatus {
  DEFAULT = 0,
  /** UNREDEEMED - 未兑换 */
  UNREDEEMED = 1,
  /** REDEEMED - 已兑换 */
  REDEEMED = 2,
  /** REFUNDED - 已退费 */
  REFUNDED = 3,
  /** EXPIRED - 已过期 */
  EXPIRED = 4,
  /** FROZEN - 已冻结 */
  FROZEN = 5,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 获取兑换码列表
 * 	接口url: /proxy/distribution/admin/code/getList
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetCodeListReq {
  code: string;
  distributionId: string;
  codeStatus: CodeStatus;
  redeemTimestampStart: string;
  redeemTimestampEnd: string;
  redeemerId: string;
  currentPage: number;
  pageSize: number;
}

export interface GetCodeListResp {
  pageNum: number;
  pageSize: number;
  size: number;
  total: number;
  proxyDistributionItem: ProxyDistributionItem[];
}

export interface ProxyDistributionItem {
  codeId: string;
  redemptionCode: string;
  creator: string;
  distributionId: string;
  codeStatus: CodeStatus;
  validityStartTime: string;
  validityEndTime: string;
  redeemerId: string;
  vipType: string;
  redeemTimestamp: string;
  refundTimestamp: string;
  createTimestamp: string;
  mobile: string;
}

/**
 * 接口描述: 退费
 * 	接口url: /proxy/distribution/admin/code/changeStatus
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface ChangeStatusReq {
  codeId: string;
  codeStatus: CodeStatus;
}

/**
 * 接口描述: 冻结
 * 	接口url: /proxy/distribution/admin/code/frozen
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface FrozenReq {
  code: string[];
}

/**
 * 接口描述: 兑换
 * 	接口url: /proxy/distribution/code/redeem
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface RedeemReq {
  code: string;
}

/**
 * 接口描述: 删除
 * 	接口url: /proxy/distribution/admin/code/remove
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface RemoveReq {
  codeIds: string[];
}

/**
 * 接口描述: 生成兑换码
 * 	接口url: /proxy/distribution/admin/code/generate
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GenerateCodeReq {
  vipType: VipType;
  amount: number;
  valiDays: number;
  distributionId: string;
}

/**
 * 接口描述: 导出
 * 	接口url: /proxy/distribution/admin/code/exportExcel
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface ExportExcelReq {
  code: string;
  distributionId: string;
  codeStatus: CodeStatus;
  redeemTimestampStart: string;
  redeemTimestampEnd: string;
  redeemerId: string;
  currentPage: number;
  pageSize: number;
}
