/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

export enum FunctionTypeEnum {
  /** COLOR_PATTERN - 颜色模式 */
  COLOR_PATTERN = 0,
  /** USE_TIPS - 使用小技巧 */
  USE_TIPS = 1,
  /** BIND_EMAIL - 绑定邮箱 */
  BIND_EMAIL = 2,
  /** BIND_PHONE_NUMBER - 绑定手机号 */
  BIND_PHONE_NUMBER = 3,
  /** BIND_WECHAT - 绑定微信 */
  BIND_WECHAT = 4,
  /** FILL_PROFESSION - 填写职业信息 */
  FILL_PROFESSION = 5,
  /** FILL_RESEARCH_FIELD - 填写研究领域 */
  FILL_RESEARCH_FIELD = 6,
  /** FILL_SCHOOL_COMPANY - 填写学校/单位 */
  FILL_SCHOOL_COMPANY = 7,
  /** DOC_RIGHTS_CARD - 领取文献大咖权益卡 */
  DOC_RIGHTS_CARD = 8,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述:获取用户红点列表
 * 	接口url:/redDot/getUserRedDotList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetUserRedDotListReq {
}

export interface GetUserRedDotListResponse {
  redDotList: RedDotInfo[];
}

export interface RedDotInfo {
  functionType: FunctionTypeEnum;
}

/**
 * 接口描述:消除红点
 * 	接口url:/redDot/clearRedDot
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ClearRedDotReq {
  functionType: FunctionTypeEnum;
}

export interface ClearRedDotResponse {
  status: number;
  message: string;
}
