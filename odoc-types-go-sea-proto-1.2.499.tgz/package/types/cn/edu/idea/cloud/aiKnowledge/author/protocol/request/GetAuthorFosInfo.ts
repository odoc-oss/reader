/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.protocol.request";

/**
 * 接口描述:获取作者的研究领域
 * 	接口url:/aiKnowledge/author/getAuthorFos
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetAuthorFosReq {
  /** 作者id */
  authorId: string;
}

export interface GetAuthorFosResponse {
  status: number;
  message: string;
  /** 作者研究领域 */
  data: AuthorDomainInfo[];
}

export interface AuthorDomainInfo {
  /** 领域id */
  domainId: string;
  /** 领域名称 */
  domainName: string;
}
