/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.doc.response";

/**
 * 接口描述:获取用户的文件夹列表
 * 	接口url:/folder/getUserFolderTree
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetUserFolderTreeResponse {
  /** 文件夹目录树 */
  folderList: UserFolderInfo[];
}

export interface UserFolderInfo {
  /** 文件夹名称 */
  name: string;
  /** 文件夹下的文献数 */
  docCount: number;
  /** 文件夹id */
  folderId: string;
  /** 子文件夹列表 */
  childrenFolders: UserFolderInfo[];
}
