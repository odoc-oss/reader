/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.ios.appApprove.request";

/**
 * 接口描述:通过verion获取ios app审核状态
 * 	接口url:/aiKnowledge/ipad/getStatusByVersion
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface AppApproveIdReq {
  /** version */
  version: string;
}
