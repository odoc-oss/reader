/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.search";

/**
 * 接口描述: 根据图片md5获取图片搜索结果(上传搜索以及相似图片查找最终都调用该接口查找数据)
 * 	接口url:/aiKnowledge/search/getPicSearchResult
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetPicSearchResultReq {
  picMd5: string;
  currentPage: number;
  pageSize: number;
}

/** 接口描述:GetPicSearchResultReq返回结果 */
export interface PicSearchResponse {
  picUrl: string;
  total: number;
  items: PicSearchItem[];
}

export interface PicSearchItem {
  picUrl: string;
  citationCount: number;
  collectionCount: number;
  paperId: string;
  isCollected: boolean;
  noteCount: number;
  pdfId: string;
  primaryVenue: string;
  publishDate: string;
  summary: string;
  title: string;
  venues: string[];
  versionCount: number;
  venueTags: string[];
  authors: string[];
}

/**
 * 接口描述: 图片搜索(返回图片唯一标识(md5))
 * 	接口url:/search/picSearch
 * 	接口请求方式: POST
 *  proto协议没有文件类型, 参考 /mergePaper/batchAdd 这个接口的传参
 */
export interface PicSearchReq {
}

/**
 * 接口描述:查找相似图片(返回图片唯一标识(md5))
 * 	接口url:/search/similarPicSearch
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface SimilarPicSearchReq {
  /** 图片url */
  picUrl: string;
}

/** 接口描述: PicSearchReq&SimilarPicSearchReq的返回结果 */
export interface GetPicMd5Response {
  picMd5: string;
}
