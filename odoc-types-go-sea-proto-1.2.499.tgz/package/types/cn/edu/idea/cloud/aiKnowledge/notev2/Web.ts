/* eslint-disable */
import type {
  AnnotateTag,
  CommentatorInfoView,
  DrawShapeType,
  Erase,
  IDEAAnnotateType,
  Point,
  RectOptions,
  ToolType,
} from "./Common";
import type { AnnotateTextBox } from "./Persistence";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.notev2";

export enum OperationTypeOfSort {
  /** addToPage - 添加到某一页 */
  addToPage = 0,
  /** exchangeInPage - 在内页交换 */
  exchangeInPage = 1,
  UNRECOGNIZED = -1,
}

export interface WebNoteAnnotationModel {
  /** 标注类型 */
  type: IDEAAnnotateType;
  /** 图片选区标注 */
  rect?:
    | WebNoteRectAnnotation
    | undefined;
  /** 文字选区标注 */
  select?:
    | WebNoteSelectAnnotation
    | undefined;
  /** 标注所在页码 */
  pageNumber: number;
  /** 标注创建时间 */
  createDate: string;
  /** 标注所属论文id */
  paperId: string;
  /** 标注所属论文标题 */
  paperTitle: string;
  /** 群组id */
  groupId: string;
  commentatorInfoView?:
    | CommentatorInfoView
    | undefined;
  /** 当前用户是否拥有删除权限 */
  deleteAuthority: boolean;
  /** 笔记所属文献名称 */
  docName: string;
  /** 当前的笔记id，用来校验数据是否已过期 */
  markIdsOfCurrentPage: string[];
  /** 新增笔记的排序,position是指在markIdsOfCurrentPage中的位置 */
  position: number;
  /** 标签 */
  tags: AnnotateTag[];
  drawAnnotation?: WebNoteAnnotateDraw | undefined;
  webDrawV2?:
    | WebDrawV2
    | undefined;
  /** 文本框 */
  textBox?:
    | AnnotateTextBox
    | undefined;
  /** 是否为高亮内容 */
  isHighlight?:
    | boolean
    | undefined;
  /** 当前annotate ID */
  id: string;
  /** 标注所属论文id */
  pdfId: string;
}

export interface WebNoteRectAnnotation {
  /** 标注ID */
  uuid: string;
  /** 笔记ID */
  documentId: string;
  /** 样式ID */
  styleId: number;
  /** 选区 */
  rectangle?:
    | RectOptions
    | undefined;
  /** 用户文字标注 */
  idea: string;
  /** 图片链接 */
  picUrl: string;
}

export interface WebNoteSelectAnnotation {
  /** 标注ID */
  uuid: string;
  /** 笔记ID */
  documentId: string;
  /** 选区（多行） */
  rectangle: RectOptions[];
  /** 选中文字 */
  rectStr: string;
  /** 用户文字标注 */
  idea: string;
  /** 样式ID */
  styleId: number;
  /** 同样选中此处的人数 */
  score: number;
}

/**
 * 添加标注（可选携带标签信息）
 * url = /pdfMark/v2/web/saveWithTag
 * method = POST
 */
export interface AddNoteResp {
  markId: string;
  newTags: AnnotateTag[];
  rawContent: string;
}

/**
 * 更新标注（可选携带标签信息）
 * url = /pdfMark/v2/web/updateWithTag
 * method = PUT
 */
export interface UpdateNoteResp {
  newTags: AnnotateTag[];
  rawContent: string;
}

/**
 * 调整标注排序
 * url = /pdfMark/v2/web/sortAnnotation
 * method = PUT
 */
export interface SortAnnotationRequest {
  markIdsWithSort: SortOfPdfMark[];
  /** 笔记id */
  noteId: string;
  /** 页码 */
  pageNumber: number;
}

export interface SortOfPdfMark {
  markId: string;
  operationTypeOfSort: OperationTypeOfSort;
}

/** empty */
export interface SortAnnotationResponse {
}

/**
 * 热点选区
 * GET /pdfMark/v2/web/hotSelect
 * 响应为 WebNoteAnnotationModel
 */
export interface HotSelectRequest {
  pdfId: string;
}

export interface WebNoteAnnotateDraw {
  nsDataUrl: string;
}

/**
 * 删除手写笔记
 * url = /pdfMark/v2/web/pencil/batch/delete
 * method = DELETE
 * 返回通用状态码
 */
export interface BatchDeleteDrawReq {
  id: string[];
}

export interface WebDrawV2 {
  pageNumber: number;
  webDrawItems: WebDrawItem[];
}

export interface WebDrawItem {
  lineHexColor: string;
  lineAlpha: number;
  points: Point[];
  id: string;
  lineWidth: number;
  tooltype: ToolType;
  drawShapeType: DrawShapeType;
  erase?: Erase | undefined;
}
