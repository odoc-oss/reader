/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.scim";

export enum SCIMType {
  /** OBJECTIVES - 实验目的 */
  OBJECTIVES = 0,
  /** METHODS - 实验方法 */
  METHODS = 1,
  /** NOVELTY - 实验创新点 */
  NOVELTY = 2,
  /** RESULTS - 实验结果 */
  RESULTS = 3,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 获取论文划重点配置
 * 	接口url:/scim/getConfig
 * 	接口请求方式: GET
 *  服务：microservice-ai-reading
 * 	参数格式:application/json
 */
export interface GetSCIMConfigReq {
}

export interface GetSCIMConfigResp {
  canUse: boolean;
  remainingTimes: number;
}

/**
 * 接口描述: 开始论文划重点配置
 * 	接口url:/scim/start
 * 	接口请求方式: POST
 *  服务：microservice-ai-reading
 * 	参数格式:application/json
 */
export interface StartSCIMReq {
  pdfId: string;
  noteId: string;
}

export interface StartSCIMResp {
}

/**
 * 接口描述: 获取论文划重点配置
 * 	接口url:/scim/getProgress
 * 	接口请求方式: GET
 *  服务：microservice-ai-reading
 * 	参数格式:application/json
 */
export interface GetSCIMResultReq {
  pdfId: string;
  noteId: string;
}

export interface GetSCIMResultResp {
  progress: number;
  items: SCIMItem[];
}

export interface SCIMItem {
  color: string;
  content: string;
  page: number;
  checked: boolean;
  /** 支持中、英文 */
  scimType: string;
  traceId: string;
  taskId: string;
}
