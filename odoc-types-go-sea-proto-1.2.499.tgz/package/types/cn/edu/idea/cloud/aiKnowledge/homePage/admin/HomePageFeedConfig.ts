/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.homePage.admin";

/**
 * 接口描述: 获取社区信息流配置
 * 	接口url: /admin/homePage/operator/feed/list
 * 	接口请求方式: POST
 */
export interface HomePageOperatorFeedListReq {
  title: string;
  feedType: string;
  currentPage: number;
  pageSize: string;
}

export interface HomePageOperatorFeedListResp {
  id: string;
  config?: Config | undefined;
}

export interface Config {
  /** 推荐标题 */
  title: string;
  /** 推荐描述 */
  description: string;
  /** 推荐类型(单选) */
  recommendType: string;
  /** 推荐位置 */
  rowIndex: number;
  /** 被推荐用户ID */
  userId: string;
  /** 被推荐论文ID */
  paperId: string;
  /** 被推荐评论ID */
  paperCommentId: string;
  /** 论文集ID */
  collectId: string;
  /** 图片（单张） */
  picUrl: string;
  /** 跳转链接 */
  targetUrl: string;
  /** 标签（多选） */
  tags: string[];
  /** 标签颜色（多选） */
  tagColors: string[];
  /** 开始时间 */
  startTime: string;
  /** 结束时间 */
  endTime: string;
  /** 发布状态 */
  publishStatus: boolean;
}

/**
 * 接口描述: 添加社区信息流
 * 	接口url: /admin/homePage/operator/feed/add
 * 	接口请求方式: POST
 */
export interface HomePageOperatorFeedAddReq {
  config?: Config | undefined;
}

export interface HomePageOperatorFeedAddResp {
  id: string;
  config?: Config | undefined;
}

/**
 * 接口描述: 修改社区信息流
 * 	接口url: /admin/homePage/operator/feed/modify
 * 	接口请求方式: POST
 */
export interface HomePageOperatorFeedModifyReq {
  id: string;
  config?: Config | undefined;
}

export interface HomePageOperatorFeedModifyReps {
  id: string;
  config?: Config | undefined;
}

/**
 * 接口描述: 删除社区信息流
 * 	接口url: /admin/homePage/operator/feed/delete
 * 	接口请求方式: POST
 */
export interface HomePageOperatorFeedDeleteReq {
  id: string;
}

export interface HomePageOperatorFeedDeleteReps {
}

/**
 * 接口描述: 发布社区信息流
 * 	接口url: /admin/homePage/operator/feed/publish
 * 	接口请求方式: POST
 */
export interface HomePageOperatorFeedPublishReq {
}

export interface HomePageOperatorFeedPublishReps {
}
