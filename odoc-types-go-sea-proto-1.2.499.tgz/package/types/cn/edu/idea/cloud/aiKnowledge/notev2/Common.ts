/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.notev2";

export enum ShapeType {
  rectangle = 0,
  ellipse = 1,
  arrow = 2,
  UNRECOGNIZED = -1,
}

export enum AnnotationColor {
  other = 0,
  blue = 1,
  yellow = 2,
  red = 3,
  green = 4,
  black = 5,
  UNRECOGNIZED = -1,
}

/** 注释类型 */
export enum IDEAAnnotateType {
  /** IDEAAnnotateTypeComment - 注释 */
  IDEAAnnotateTypeComment = 0,
  /** IDEAAnnotateTypeRect - 矩形 */
  IDEAAnnotateTypeRect = 1,
  /** IDEAAnnotateTypeIOSDraw - IOS笔触笔记 */
  IDEAAnnotateTypeIOSDraw = 2,
  /** IDEAAnnotateTypeHotRect - 热门选区 */
  IDEAAnnotateTypeHotRect = 3,
  /** IDEAAnnotateTypeTextBox - 文本框 */
  IDEAAnnotateTypeTextBox = 4,
  /** IDEAAnnotateTypeDrawV2 - 手写笔记v2 */
  IDEAAnnotateTypeDrawV2 = 5,
  UNRECOGNIZED = -1,
}

export enum ToolType {
  /** IDEADrawToolTypeNone - invalid for web */
  IDEADrawToolTypeNone = 0,
  /** IDEADrawToolTypePen -  */
  IDEADrawToolTypePen = 1,
  /** IDEADrawToolTypeMarker -  */
  IDEADrawToolTypeMarker = 2,
  /** IDEADrawToolTypePencil - invalid for web */
  IDEADrawToolTypePencil = 3,
  IDEADrawToolTypeEraser = 4,
  /** IDEADrawToolTypeLasso - invalid for web */
  IDEADrawToolTypeLasso = 5,
  IDEADrawShapeType = 6,
  UNRECOGNIZED = -1,
}

export enum DrawShapeType {
  IDEADrawShapeTypeNormal = 0,
  /** IDEADrawShapeTypePentagon - 五角星 */
  IDEADrawShapeTypePentagon = 1,
  /** IDEADrawShapeTypeCircle - 正圆 */
  IDEADrawShapeTypeCircle = 2,
  /** IDEADrawShapeTypeEllipse - 椭圆 */
  IDEADrawShapeTypeEllipse = 3,
  /** IDEADrawShapeTypeCurve - 曲线 */
  IDEADrawShapeTypeCurve = 4,
  /** IDEADrawShapeTypeArrow - 箭头 */
  IDEADrawShapeTypeArrow = 5,
  /** IDEADrawShapeTypeStraightLine - 直线 */
  IDEADrawShapeTypeStraightLine = 6,
  IDEADrawShapeTypeRectangle = 7,
  IDEADrawShapeTypeTraingle = 8,
  UNRECOGNIZED = -1,
}

export interface ShapeAnnotation {
  uuid: string;
  type: ShapeType;
  /**
   * 当type为rectangle、text时，x、y为图形左上角位置
   * 当type为ellipse时，x、y为圆心位置
   * 当type为arrow时，x、y为箭头起点位置
   */
  x: number;
  y: number;
  strokeColor: AnnotationColor;
  /** 当type为retangle时，width属性代表宽度 */
  width: number;
  /** 当type为retangle时，height属性代表高度 */
  height: number;
  /** 当type为ellipse时，radiusX为横向半径 */
  radiusX: number;
  /** 当type为ellipse时，radiusY为纵向半径 */
  radiusY: number;
  /** 当type为arrow时，endX、endY为箭头终点位置 */
  endX: number;
  endY: number;
  /** 所在页数 */
  pageNumber: number;
  /** 更新时需要传该参数 */
  shapeId?: string | undefined;
}

export interface RectOptions {
  /** 锚点横坐标 */
  x: number;
  /** 锚点纵坐标 */
  y: number;
  /** 选区宽度 */
  width: number;
  /** 选区高度 */
  height: number;
  /** 选区所在页数 */
  pageNumber: number;
  /** 旋转角度 */
  rotation: number;
}

export interface AnnotationPointer {
  id: string;
  /** 群组id */
  groupId: string;
}

export interface AnnotateTag {
  tagId: string;
  tagName: string;
  latestUseTime: string;
}

export interface CommentatorInfoView {
  nickName: string;
  avatarCdnUrl: string;
  userId: string;
}

/**
 * /pdfMark/v2/page/noteCount
 * GET
 */
export interface NoteCountOfPdfPerPageRequest {
  pdfId: string;
}

export interface NoteCountOfPdfPerPageResponse {
  noteCountList: NoteCountOfPdfPerPage[];
}

export interface NoteCountOfPdfPerPage {
  page: number;
  noteCount: number;
}

export interface Point {
  x: number;
  y: number;
  altitude?: number | undefined;
  size?: Size | undefined;
  opacity?: number | undefined;
  time?: string | undefined;
  azimuth?: number | undefined;
  force?: number | undefined;
}

export interface Size {
  width: number;
  height: number;
}

export interface BasePoint {
  x: number;
  y: number;
}

export interface Erase {
  points: BasePoint[];
  lineWidth: number;
}
