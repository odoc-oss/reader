/* eslint-disable */
import type { BaseAuthorInfo } from "../../author/AuthorInfo";
import type { PaperCommentLevel } from "../../paper/PaperCommentView";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.homePage";

/** 流类型 */
export enum FeedType {
  /** OPERATOR_CLASSIC_ANSWER - 十问回答 */
  OPERATOR_CLASSIC_ANSWER = 0,
  /** OPERATOR_REVIEW_COMMENT - 同行评审 */
  OPERATOR_REVIEW_COMMENT = 1,
  /** OPERATOR_COLLECT - 论文集 */
  OPERATOR_COLLECT = 2,
  /** OPERATOR_IMG_TEXT - 运营图文 */
  OPERATOR_IMG_TEXT = 3,
  /** OPERATOR_TEXT - 运营文字 */
  OPERATOR_TEXT = 4,
  /** PAPER_CLASSIC_ANSWER - 社区十问回答 */
  PAPER_CLASSIC_ANSWER = 5,
  /** PAPER_REVIEW_COMMENT - 社区同行评审 */
  PAPER_REVIEW_COMMENT = 6,
  /** PAPER_QUESTION - 社区论文提问 */
  PAPER_QUESTION = 7,
  /** PAPER_QUESTION_ANSWER - 社区论文回答 */
  PAPER_QUESTION_ANSWER = 8,
  /** FOS_DISCUSSION - 学科页讨论 */
  FOS_DISCUSSION = 9,
  /** PAPER - 论文流类型 */
  PAPER = 10,
  UNRECOGNIZED = -1,
}

/** 基本数据流字段 */
export interface BaseFeed {
  /** 用户ID */
  userId: string;
  /** 用户昵称 */
  nickName: string;
  /** 用户头像 */
  avatarUrl: string;
  /** 推荐时间 */
  recommendDate: string;
  /** 论文ID */
  paperId: string;
  /** 论文标题 */
  paperTitle: string;
  /** 推荐类型 */
  recommendType: FeedType;
  /** 是否已收藏 */
  isCollected: boolean;
  /** 唯一Id 用于社区流数据上报 */
  uniqueId: string;
}

/**
 * 经典十问回答
 * 2023年2月1号，modify by bing.yi 十问需要合并，此类作为Item
 */
export interface PaperClassicAnswer {
  /** 回答内容 */
  content: string;
  /** 提问 */
  question: string;
  /** 排序 */
  questionOrder: number;
}

/** 经典十问回答 */
export interface PaperClassicTenAnswer {
  /** 直接获取本集合的长度，即可知道回答了多少条问题 */
  answers: PaperClassicAnswer[];
}

/** 同行评审 */
export interface PaperReviewComment {
  /** 评论内容 */
  content: string;
  /** 评审ID */
  paperCommentId: string;
  /** 是否匿名 */
  isAnonymous: boolean;
  /** 论文评价尺度 */
  commentLevel: PaperCommentLevel;
}

/** 提问 */
export interface PaperQuestion {
  /** 提问内容 */
  content: string;
  /** 提问id */
  questionId: string;
}

/** 回答 */
export interface PaperQuestionAnswer {
  /** 回答内容 */
  content: string;
  /** 回答ID */
  answerId: string;
  /** 提问Id */
  questionId: string;
  /** 提问内容 */
  questionContent: string;
}

/** 运营流的通用数据类型 */
export interface BaseOperatorFeed {
  /** 标题 */
  title: string;
  /** 描述 */
  description: string;
  /** 标签 */
  tags: Tag[];
  /** 标签颜色 */
  tagColors: string[];
  /** 开始时间 */
  startTime?:
    | string
    | undefined;
  /** 结束时间 */
  endTime?: string | undefined;
}

export interface Tag {
  idName: string;
  name: string;
}

/** 运营推荐十问 */
export interface OperatorClassicAnswer {
  /** 回答内容 */
  content: string;
}

/** 运营推荐同行评审 */
export interface OperatorReviewComment {
  /** 评论内容 */
  content: string;
  paperCommentId: string;
  /** 是否匿名 */
  isAnonymous: boolean;
}

/** 运营推荐论文集 */
export interface OperatorCollect {
  /** 评论内容 */
  collectId: string;
  /** 条数 */
  count: number;
}

/** 运营推荐图文集 */
export interface OperatorImageText {
  /** 图片地址 */
  picUrl: string;
  /** 跳转链接 */
  targetUrl: string;
}

/** 运营推荐论文集 */
export interface OperatorText {
  /** 跳转链接 */
  targetUrl: string;
}

export interface FOSDiscussion {
  discussionTitle: string;
  discussionBriefContent?: string | undefined;
  discussionId: string;
  discussionThumbnailImageUrl: string;
  fosTitle: string;
  fosId: string;
}

export interface Paper {
  id: string;
  /** 标题 */
  title: string;
  /** 发布日期 */
  publishDate: string;
  /** 原文摘要 */
  summary: string;
  /** 引用数(参考文献数) */
  referenceCount: number;
  /** 被引用数 */
  citationCount: number;
  /** 笔记数 */
  noteCount: number;
  /** 是否已经收藏了该论文 */
  isCollected: boolean;
  /** 作者信息 */
  authorList: BaseAuthorInfo[];
  /** 论文DOI */
  doi: string;
  /** 期刊会议(新) */
  venueTags: string[];
  /** 推荐理由 */
  recommendItem?:
    | RecommendItem
    | undefined;
  /** pdfId */
  pdfId: string;
  /** 收藏数 */
  collectionCount: number;
}

export interface RecommendItem {
  /** 推荐id */
  id: string;
  /** 理由 */
  reason: string;
  /** 推荐评分 */
  score: number;
  /** 来源id */
  qid: string;
  /** 来源标题 */
  qtitle: string;
}
