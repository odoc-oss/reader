/* eslint-disable */
import type { AcquirePolicyCallbackInfoResponse, UploadBizScene } from "../oss/AliOSS";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

export enum AiPolishResultStatus {
  POLISH_PENDING = 0,
  POLISH_SUCCESS = 1,
  POLISH_FAILED = 2,
  POLISH_TIMEOUT = 3,
  POLISH_WAITING = 4,
  UNRECOGNIZED = -1,
}

export enum PolishType {
  ABSTRACT = 0,
  INTRODUCTION = 1,
  OVERALL = 2,
  RELATED_WORK = 3,
  GEN_TITLE = 4,
  GEN_ABS = 5,
  MODIFY_ABS = 6,
  UNRECOGNIZED = -1,
}

export interface Sentence {
  originalSentence: string;
  newSentence: string;
  accept: boolean;
  id: string;
  reason: string;
}

export interface OverallPolish {
  expressionOptimizeCount: number;
  sentencesOptimize: Sentence[];
  aiPolishResultStatus: AiPolishResultStatus;
  errorMessage?: string | undefined;
}

export interface OverallAdvicePolish {
  content: string;
  aiPolishResultStatus: AiPolishResultStatus;
  errorMessage?: string | undefined;
}

export interface TitlePolish {
  currentTitle: string;
  score: number;
  scoreReason: string;
  advicedTitles: string[];
  choosed: number;
  aiPolishResultStatus: AiPolishResultStatus;
  errorMessage?: string | undefined;
}

export interface AbstractPolish {
  sourceAbstract: string;
  newAbstract: string;
  problems: string[];
  selectedTags: string[];
  accept: boolean;
  id: string;
  aiPolishResultStatus: AiPolishResultStatus;
  errorMessage?: string | undefined;
  createTime: string;
  repolish: boolean;
}

export interface IntroductionPolish {
  sourceIntroduction: string;
  newIntroduction: string;
  problems: string[];
  selectedTags: string[];
  accept: boolean;
  id: string;
  aiPolishResultStatus: AiPolishResultStatus;
  errorMessage?: string | undefined;
  createTime: string;
  repolish: boolean;
}

export interface RelatedWorkPolish {
  problems: string[];
  recommendReferences: string[];
  accept: boolean;
  id: string;
  aiPolishResultStatus: AiPolishResultStatus;
  errorMessage?: string | undefined;
}

/**
 * 接口描述: 获取上传到阿里云OSS所需的policy和Callback等信息
 * 	接口url:/ai/polish/token
 * 	接口请求方式: POST
 */
export interface GetFileIsNeedUploadReq {
  scene: UploadBizScene;
  md5: string;
}

export interface GetFileIsNeedUploadResponse {
  data?: AcquirePolicyCallbackInfoResponse | undefined;
  status: number;
  message: string;
}

/**
 * /ai/polish/task/current
 * method: GET
 * 无参请求
 */
export interface CurrentTaskResponse {
  taskId?: string | undefined;
}

/**
 * /ai/polish/task/start
 * method: POST
 */
export interface AiPolishStartTaskRequest {
  bucketName: string;
  objectName: string;
}

export interface AiPolishStartTaskResponse {
  taskId: string;
}

/**
 * /ai/polish/result
 * /text/polish/result/all
 * /text/polish/result/review
 * /text/polish/result/title
 * /text/polish/result/abstract
 * /text/polish/result/introduction
 * method: GET
 */
export interface AiPolishRequest {
  taskId: string;
  start?: number | undefined;
}

export interface AiPolishResponse {
  overallAdvicePolish?: OverallAdvicePolish | undefined;
  overallPolish?: OverallPolish | undefined;
  titlePolish?: TitlePolish | undefined;
  abstractPolishes: AbstractPolish[];
  introductionPolishes: IntroductionPolish[];
  relatedWorkPolish?: RelatedWorkPolish | undefined;
  aiPolishResultStatus: AiPolishResultStatus;
  errorMessage: string;
  pdfUrl: string;
}

export interface TagsRequest {
  polishType: PolishType;
}

export interface TagsResponse {
  tags: string[];
}

/**
 * /ai/polish/repolish/start
 * method: POST
 */
export interface RepolishStartRequest {
  tags: string[];
  taskId: string;
  polishType: PolishType;
  repolishId?: string | undefined;
}

export interface RepolishStartResponse {
  repolishId: string;
}

/**
 * /ai/polish/repolish/result
 * method: GET
 */
export interface RepolishResultRequest {
  repolishId: string;
  taskId: string;
  polishType: PolishType;
}

export interface RepolishResultResponse {
  abstractPolish?: AbstractPolish | undefined;
  introductionPolish?: IntroductionPolish | undefined;
  errorMessage: string;
}

/**
 * /ai/polish/abstract
 * method: PUT
 */
export interface UpdateAbstractRepolishRequest {
  abstractPolish?: AbstractPolish | undefined;
  taskId: string;
}

/**
 * /ai/polish/introduction
 * method: PUT
 */
export interface UpdateIntroductionRepolishRequest {
  introductionPolish?: IntroductionPolish | undefined;
  taskId: string;
}

/**
 * /ai/polish/accept
 * method: PUT
 */
export interface AcceptPolishRequest {
  taskId: string;
  targetId: string;
  polishType: PolishType;
}

/**
 * /ai/polish/title/choose
 * method: PUT
 */
export interface ChooseTitleRequest {
  taskId: string;
  /** 从0开始计算 */
  index: number;
}
