/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/** url: /translate/delete */
export interface DeleteTranslationReq {
  translationId: string;
}
