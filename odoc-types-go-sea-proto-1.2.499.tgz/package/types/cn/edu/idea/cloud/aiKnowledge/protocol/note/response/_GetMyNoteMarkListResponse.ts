/* eslint-disable */
import type { WebNoteAnnotationModel } from "../../../notev2/Web";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.note.response";

/**
 * 接口描述:查询我的笔记列表
 * 	接口url:/pdfMark/v2/web/getMyNoteMarkList
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetMyNoteMarkListResponse {
  /** 笔记内容 */
  annotationModelList: WebNoteAnnotationModel[];
  total: number;
}
