/* eslint-disable */
import type { OrderStatus, PayStatus, VipPayType } from "./VipPayInfo";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.vip";

/**
 * 接口描述: 获取订单列表
 * 	接口url: /pay/admin/order/getList
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetOrderListReq {
  /** 查询开始时间，格式：yyyy-MM-dd HH:mm:ss */
  orderStartTime: string;
  /** 查询结束时间,格式同上 */
  orderEndTime: string;
  orderId: string;
  userId: string;
  vipPayType: VipPayType;
  payStatus: PayStatus;
  /** 支付通道 */
  payChannel: string;
  /** 支付通道状态 */
  payChannelStatus: string;
  currentPage: number;
  pageSize: number;
}

export interface GetOrderListResp {
  pageNum: number;
  pageSize: number;
  size: number;
  total: number;
  orderInfos: VipPayOrderInfo[];
  /** 一次查询所有金额总计 */
  totalAmount: string;
}

export interface VipPayOrderInfo {
  /** 订单号 */
  orderId: string;
  /** 用户id */
  userId: string;
  /** 支付内容 */
  subject: string;
  /** 支付金额，单位：分 */
  totalAmount: string;
  /** 订单支付状态 */
  payStatus: PayStatus;
  /** 支付类型 */
  vipPayType: VipPayType;
  /** 支付通道 */
  payChannel: string;
  /** 订单状态 */
  orderStatus: OrderStatus;
  /** 支付时间 */
  payTimestamp: string;
  /** 退款时间 */
  refundTimestamp: string;
  /** 支付通道状态 */
  payChannelStatus: string;
  /** vip有效开始时间 */
  vipStartTimestamp: string;
  /** vip有效结束时间 */
  vipEndTimestamp: string;
  /** 订单创建时间 */
  createTimestamp: string;
  /** 订单修改时间 */
  modifyTimestamp: string;
  /** pay account channel */
  payAccountId: string;
}

/**
 * 接口描述: 退费
 * 	接口url: /pay/admin/order/refund
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface RefundReq {
  orderId: string;
}
