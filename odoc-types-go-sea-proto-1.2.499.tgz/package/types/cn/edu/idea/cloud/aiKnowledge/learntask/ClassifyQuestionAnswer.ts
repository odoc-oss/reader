/* eslint-disable */
import type { UserInfoBean } from "../../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.learntask";

/**
 * 接口描述:置顶回答
 * 	接口url:/classicQuestionAnswer/setTop
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ClassicQuestionAnswerSetTopReq {
  /** 回答id */
  answerId: string;
}

/**
 * 接口描述:取消回答置顶
 * 	接口url:/classicQuestionAnswer/cancelSetTop
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface CancelClassicQuestionAnswerSetTopReq {
  /** 回答id */
  answerId: string;
}

/**
 * 接口描述:点赞/认同回答
 * 	接口url:/classicQuestionAnswer/like
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ClassicQuestionAnswerLikeReq {
  /** 回答id */
  answerId: string;
}

/**
 * 接口描述:取消回答点赞/认同
 * 	接口url:/classicQuestionAnswer/cancelLike
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface CancelClassicQuestionAnswerLikeReq {
  /** 回答id */
  answerId: string;
}

/**
 * 接口描述:论文详情页十问list
 * 	接口url:/aiKnowledge/classicQuestionAnswer/list
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ClassicQuestionAnswerListReq {
  /** 论文id */
  paperId: string;
}

export interface ClassicQuestionAnswerListResponse {
  list: ClassicQuestionAnswerInfo[];
}

export interface ClassicQuestionAnswerInfo {
  questionId: string;
  questionContent: string;
  questionTitle: string;
  answerCount: number;
  answers: AnswerInfo[];
  systemSort: number;
}

export interface AnswerInfo {
  answerId: string;
  /** 回答者信息 */
  ownerInfo?:
    | UserInfoBean
    | undefined;
  /** 是否已经点赞/认同 */
  likeFlag: boolean;
  /** 回答发布时间 */
  createDate: string;
  /** 点赞/认同数 */
  likeCount: number;
  /** 回答内容 */
  answer: string;
  htmlAnswer: string;
  /** 是否已经置顶 */
  topFlag: boolean;
}

/**
 * 接口描述:十问list
 * 	接口url:/aiKnowledge/classicQuestion/list
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ClassicQuestionListReq {
  /** 论文id */
  paperId: string;
}

export interface ClassicQuestionListResponse {
  questions: ClassicQuestionInfo[];
}

export interface ClassicQuestionInfo {
  questionId: string;
  questionContent: string;
  questionTitle: string;
}

/**
 * 接口描述:十问详情
 * 	接口url:/aiKnowledge/classicQuestionAnswer/detail
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ClassicQuestionAnswerDetailReq {
  /** 论文id */
  paperId: string;
  questionId: string;
  pageSize: number;
  currentPage: number;
  /** 排序方式,0=默认排序,1=最受认同,2=最新 */
  sortType: number;
}

export interface ClassicQuestionAnswerDetailResponse {
  /** 回答总数 */
  answerCount: number;
  /** 回答列表 */
  answers: AnswerInfo[];
  /** 我的翻译信息 */
  myAnswerInfo?: AnswerInfo | undefined;
}

/**
 * 接口描述:获取某个用户的问答详情
 * 	接口url:/aiKnowledge/classicQuestionAnswer/getUserQuestionAnswerDetail
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetUserQuestionAnswerDetailReq {
  /** 论文id */
  paperId: string;
  userId: string;
}

export interface GetUserQuestionAnswerDetailResponse {
  /** 回答者信息 */
  ownerInfo?:
    | UserInfoBean
    | undefined;
  /** 问答详情列表 */
  questionAnswerInfos: SingleClassicQuestionAnswerInfo[];
  paperTitle: string;
}

export interface SingleClassicQuestionAnswerInfo {
  questionId: string;
  questionContent: string;
  questionTitle: string;
  systemSort: number;
  answer?: AnswerInfo | undefined;
}
