/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

export enum ReasonTypeOfReportUgc {
  SEXY_CONTENT = 0,
  /** ILLEGAL_CONTENT - 违法 */
  ILLEGAL_CONTENT = 1,
  /** ILLEGAL1_CONTENT - 违规 */
  ILLEGAL1_CONTENT = 2,
  /** TORT_CONTENT - 侵权 */
  TORT_CONTENT = 3,
  UNRECOGNIZED = -1,
}

export enum ReportType {
  USER_PROFILE = 0,
  USER_GENERATED_CONTENT = 1,
  UNRECOGNIZED = -1,
}

export enum UgcReportSubType {
  TEN_QA_ANSWER = 0,
  USER_QUESTION = 1,
  USER_ANSWER = 2,
  USER_QA_REPLY = 3,
  FOS_DISCUSSION = 4,
  FOS_DISCUSSION_REPLY = 5,
  GROUP_QUESTION = 6,
  GROUP_ANSWER = 7,
  PEER_REVIEW_COMMENT = 8,
  PERSONAL_OPEN_NOTE = 9,
  UNRECOGNIZED = -1,
}

export enum BlockedStatus {
  UN_BLOCKED = 0,
  BLOCKED = 1,
  UNRECOGNIZED = -1,
}

export enum ReportHandledStatus {
  HANDLED = 0,
  UN_HANDLED = 1,
  UNRECOGNIZED = -1,
}

/**
 * path: /ugc/report
 * method: post
 * description: 用户上报
 * return: 通用的状态码
 */
export interface UgcReportRequest {
  pageUrl: string;
  reasonTypeOfReportUgc: ReasonTypeOfReportUgc;
  imageUrls: string[];
  description: string;
  contentId: string;
  reportType: ReportType;
  ugcReportSubType?: UgcReportSubType | undefined;
}

/**
 * path: /admin/ugc/report:list
 * method: get
 */
export interface UgcReportListRequest {
  reportType: ReportType;
  /** start from 1 */
  pageNumber: number;
  pageSize: number;
  complainedUserId: string;
  ugcReportSubType: UgcReportSubType;
}

export interface UgcReportListResponse {
  ugcReportItems: UgcReportItem[];
  totalNumber: number;
}

/**
 * path: /admin/ugc/report/description
 * method: put
 * description: 添加备注
 */
export interface UgcReportUpdateDescriptionRequest {
  id: string;
  description: string;
}

export interface UgcReportUpdateDescriptionResponse {
  id: string;
}

/**
 * path: /admin/ugc/report/block
 * method: put
 * description: 封禁内容
 */
export interface BlockUgcRequest {
  id: string;
}

export interface BlockUgcResponse {
  reportHandledStatus: ReportHandledStatus;
  blockedStatus: BlockedStatus;
}

export interface UgcReportItem {
  id: string;
  pageUrl: string;
  reasonTypeOfReportUgc: ReasonTypeOfReportUgc;
  imageUrls: string[];
  description: string;
  contentId: string;
  reportType: ReportType;
  ugcReportSubType: UgcReportSubType;
  handledPerson?: string | undefined;
  handleDescription: string;
  reportHandledStatus: ReportHandledStatus;
  reportTime: string;
  complainedUser?: ComplainedUser | undefined;
  reportUserId: string;
}

export interface ComplainedUser {
  userId: string;
  nickName: string;
  blockedStatus: BlockedStatus;
}

/**
 * path: /admin/ugc/report/user/destroy
 * method: delete
 * description: 注销用户
 * return: 返回通用的状态码
 */
export interface DestroyUserRequest {
  ugcReportId: string;
}
