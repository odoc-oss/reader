/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/**
 * 接口描述:获取最新更新时间
 * 	接口url:/aiKnowledge/getNewestUpdateTime
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetNewestUpdateTimeReq {
}

export interface GetNewestUpdateTimeResponse {
  status: number;
  message: string;
  /** 更新时间 */
  data: string;
}

/**
 * 接口描述:获取使用小技巧链接
 * 	接口url:/aiKnowledge/getUseTipsLink
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetUseTipsLinkReq {
}

export interface GetUseTipsLinkResponse {
  status: number;
  message: string;
  /** 使用小技巧链接 */
  data: string;
}
