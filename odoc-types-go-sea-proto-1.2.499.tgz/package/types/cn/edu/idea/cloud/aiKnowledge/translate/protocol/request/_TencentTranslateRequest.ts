/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate.protocol.request";

/**
 * 接口描述:腾讯渠道-中文翻译接口入参
 *   接口url:/ts/tencent/zh-cn
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface TencentTranslateRequest {
  /** content */
  content: string;
  /** noteId */
  noteId: string;
}
