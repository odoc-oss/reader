/* eslint-disable */
import type { PaperQuestion } from "../../paper/QuestionAnswer";
import type { ClassicQuestionAnswerInfo } from "../learntask/ClassifyQuestionAnswer";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.paper";

export enum QuestionType {
  /** TEN - 十问 */
  TEN = 0,
  /** SOCIAL - 社区问答 */
  SOCIAL = 1,
  UNRECOGNIZED = -1,
}

/**
 * 详情页经典十问和社区问答混合
 * 请求方式：GET
 * url:/aiKnowledge/paper/qa/getQuestionAnswerByPaperId
 */
export interface CombineQuestionAnswerRequest {
  paperId: string;
  startPage?: number | undefined;
  pageSize?: number | undefined;
}

export interface CombineQuestionAnswerResponse {
  questionList: CombineQuestionInfo[];
}

export interface CombineQuestionInfo {
  type: QuestionType;
  order?: number | undefined;
  lastAnswerTime?:
    | string
    | undefined;
  /** 十问 */
  classicQuestion?: ClassicQuestionAnswerInfo | undefined;
  socialQuestion?: PaperQuestion | undefined;
}
