/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.activitys.protocol.request";

/**
 * 接口描述:活动合集-获取tag列表入参
 *   接口url:/aiKnowledge/activitys/tag
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface ActivitysTagRequest {
}
