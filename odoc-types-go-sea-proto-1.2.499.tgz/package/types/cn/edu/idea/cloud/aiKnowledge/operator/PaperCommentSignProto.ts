/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.operator";

/**
 * 接口描述:论文荣誉关键字外显-入参
 *   接口url:/aiKnowledge/operator/paper/comment/sign
 *   接口请求方式: POST
 *   参数格式:application/json
 */
export interface PaperCommentSignReq {
  /** 论文id */
  paperId: string;
}

export interface PaperCommentSignResp {
  /** 论文荣誉标题 */
  title: string;
}
