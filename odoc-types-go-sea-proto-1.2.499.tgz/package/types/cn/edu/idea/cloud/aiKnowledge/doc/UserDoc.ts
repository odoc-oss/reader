/* eslint-disable */
import type { BaseAuthorInfo } from "../../author/AuthorInfo";
import type { DisplayPublishDate, DisplayVenue, DocDetailInfo } from "../../client/ClientDoc";
import type { DocFolder } from "./folder";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.doc";

/**
 * 用户手动修改个人文献的收录情况
 * method:PUT
 * url:/userDoc/venue
 *
 * venue传 null 则回滚至官方信息
 */
export interface UpdateVenueRequest {
  docId: string;
  venue?: string | undefined;
}

export interface UpdateVenueResponse {
  newVenue?: DisplayVenue | undefined;
}

/**
 * 用户手动修改个人文献的发布时间
 * method:PUT
 * url:/userDoc/publishDate
 *
 * publishDate传 null 则回滚至官方信息
 */
export interface UpdatePublishDateRequest {
  docId: string;
  publishDate?: string | undefined;
}

export interface UpdatePublishDateResponse {
  newPublishDate?: DisplayPublishDate | undefined;
}

/**
 * 用户手动修改个人文献的作者
 * method:PUT
 * url:/userDoc/authors
 *
 * authors 传空列表 null 则回滚至官方信息
 */
export interface UpdateAuthorsRequest {
  docId: string;
  authors: BaseAuthorInfo[];
}

export interface UpdateAuthorsResponse {
  newAuthor?: DisplaySimpleAuthors | undefined;
}

/**
 * 获取文献的作者列表
 * method:GET
 * url:/userDoc/authors
 */
export interface GetAuthorsRequest {
  docId: string;
}

export interface GetAuthorsResponse {
  displayAuthor?: DisplaySimpleAuthors | undefined;
}

export interface DisplaySimpleAuthors {
  authors: BaseAuthorInfo[];
  rollbackEnable: boolean;
  originAuthors: BaseAuthorInfo[];
}

/**
 * 个人文献搜索
 * method:GET
 * url:/userDoc/search
 * 请求使用SearchNote.UserCenterSearchRequest
 */
export interface SearchResponse {
  items: UserDocSearchItem[];
  total: number;
}

export interface UserDocSearchItem {
  searchTitle: string;
  searchContent: string;
  searchRemark: string;
  docInfo?: DocDetailInfo | undefined;
}

/**
 * 获取一个个人文献信息
 * method:GET
 * url:/userDoc
 * 回包使用client.DocDetailInfo
 */
export interface GetUserDocRequest {
  id?: string | undefined;
  noteId: string;
}

/**
 * 获取一个个人文献在哪些目录下
 * method:GET
 * url:/userDoc/folders
 */
export interface GetUserDocFoldersRequest {
  docId?: string | undefined;
  noteId: string;
}

export interface GetUserDocFoldersResponse {
  folders: DocFolder[];
}

/**
 * 根据docId返回一个相对简单的文献信息
 * method:GET
 * url:/userDoc/simple
 */
export interface GetSimpleDocRequest {
  docId: string;
}

export interface GetSimpleDocResponse {
  title: string;
  publishDate: string;
  primaryVenue: string;
  authorList: string[];
}
