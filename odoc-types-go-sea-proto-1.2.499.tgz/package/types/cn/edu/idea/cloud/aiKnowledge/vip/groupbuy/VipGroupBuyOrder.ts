/* eslint-disable */
import type { VipType } from "../../../user/VipUserInterface";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.vip.groupbuy";

export enum GroupBuyCodeStatus {
  DEFAULT = 0,
  /** UNREDEEMED - 未兑换 */
  UNREDEEMED = 1,
  /** REDEEMED - 已兑换 */
  REDEEMED = 2,
  /** REFUNDED - 已退费 */
  REFUNDED = 3,
  /** EXPIRED - 已过期 */
  EXPIRED = 4,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: vip权益，当有用户状态时，根据用户状态计算各个版本
 * 	接口url: /order/groupbuy/getOrderList
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetOrderListReq {
  /** 团购码状态 */
  groupBuyCodeStatus: GroupBuyCodeStatus;
  /** vip类型 */
  vipType: VipType;
  /** 团购兑换码 */
  groupBuyCode: string;
  /** 兑换人id */
  redeemerId: string;
  /** 兑换时间 */
  redeemTimestamp: string;
  /** 团购订单id */
  groupBuyOrderId: string;
  currentPage: number;
  pageSize: number;
}

export interface GroupBuyCodeItem {
  /** id */
  codeId: string;
  /** 团购码状态 */
  groupBuyCodeStatus: GroupBuyCodeStatus;
  /** vip类型 */
  vipType: VipType;
  /** 团购兑换码 */
  groupBuyCode: string;
  /** 团购码有效期开始时间 */
  validityStartTime: string;
  /** 团购码有效期结束时间 */
  validityEndTime: string;
  /** 兑换人id */
  redeemerId: string;
  /** 兑换时间 */
  redeemTimestamp: string;
  /** 退款时间 */
  refundTimestamp: string;
  /** 创建时间 */
  createTimestamp: string;
}

export interface GetOrderListResp {
  pageNum: number;
  pageSize: number;
  size: number;
  total: number;
  groupBuyCodeItem: GroupBuyCodeItem[];
}

/**
 * 接口描述: 兑换
 * 	接口url: /order/groupbuy/code/redeem
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GroupBuyRedeemReq {
  code: string;
}

/**
 * 接口描述: 为他人兑换
 * 	接口url: /order/groupbuy/code/otherRedeem
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GroupBuyRedeemToOtherReq {
  code: string;
  userId: string;
}
