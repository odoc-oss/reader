/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.protocol.request";

/**
 * 接口描述:获取作者的基本信息
 * 	接口url:/aiKnowledge/author/getBaseInfo
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetAuthorBaseInfoReq {
  /** 作者id */
  authorId: string;
}

export interface GetAuthorBaseInfoResponse {
  /** 作者id */
  authorId: string;
  /** 作者名称 */
  authorName: string;
  /** 作者论文数量 */
  paperCount: number;
  /** h-index */
  hindex: number;
  /** 被引用数 */
  citationCount: number;
  /** 作者每年发表论文数统计信息 */
  publishPaperStatInfo: AuthorAnnuallyPublishPaperStatBean[];
  /** 作者每年新增引用数统计信息 */
  increaseCitationCountStatInfo: AuthorAnnuallyIncreaseCitationCountStatBean[];
  /** 是否已认证作者 */
  isAuthentication: boolean;
  /** 作者-对应的用户ID */
  userId: string;
  /** 作者-对应的用户昵称 */
  nickName: string;
}

export interface AuthorAnnuallyIncreaseCitationCountStatBean {
  /** 年份 */
  year: number;
  /** 数量 */
  count: number;
}

export interface AuthorAnnuallyPublishPaperStatBean {
  /** 年份 */
  year: number;
  /** 数量 */
  count: number;
}
