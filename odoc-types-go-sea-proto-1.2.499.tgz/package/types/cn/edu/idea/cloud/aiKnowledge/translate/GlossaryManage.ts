/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate";

/**
 * 接口描述:添加术语
 *  接口url:/glossary/add
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface AddGlossaryReq {
  /** 原文 */
  originalText: string;
  /** 译文 */
  translationText: string;
  /** 是否区分大小写 */
  matchCase: boolean;
  /** 是否不翻译该术语 */
  ignored: boolean;
}

export interface AddGlossaryResponse {
  id: string;
}

/**
 * 接口描述:编辑术语
 *  接口url:/glossary/update
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface UpdateGlossaryReq {
  id: string;
  /** 原文 */
  originalText: string;
  /** 译文 */
  translationText: string;
  /** 是否区分大小写 */
  matchCase: boolean;
  /** 是否不翻译该术语 */
  ignored: boolean;
}

/**
 * 接口描述:删除术语
 *  接口url:/glossary/delete
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface DeleteGlossaryReq {
  ids: string[];
}

/**
 * 接口描述:术语列表
 *  接口url:/glossary/list
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface GetGlossaryListReq {
  /** 搜索术语 */
  searchText?: string | undefined;
  currentPage: number;
  pageSize: number;
}

export interface GetGlossaryListResponse {
  total: number;
  items: GlossaryItem[];
}

export interface GlossaryItem {
  id: string;
  /** 原文 */
  originalText: string;
  /** 译文 */
  translationText: string;
  /** 是否区分大小写 */
  matchCase: boolean;
  /** 是否不翻译该术语 */
  ignored: boolean;
}
