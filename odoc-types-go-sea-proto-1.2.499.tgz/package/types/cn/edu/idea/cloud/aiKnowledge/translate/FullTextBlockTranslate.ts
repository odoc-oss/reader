/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate";

/**
 * 接口描述: 内部翻译接口入参
 *   接口url:/internal/translate/zh-cn
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface FullTextBlockTranslateReq {
  /** content */
  content: string;
  /** pdfId */
  pdfId?:
    | string
    | undefined;
  /** paperId */
  paperId?:
    | string
    | undefined;
  /** pageId */
  pageId?:
    | string
    | undefined;
  /** blockId */
  blockId?: string | undefined;
}

export interface FullTextBlockTranslateResp {
  /** 翻译引擎 */
  engine: string;
  /** 翻译内容 */
  content: string;
  /** 是否缓存 */
  cached: boolean;
}
