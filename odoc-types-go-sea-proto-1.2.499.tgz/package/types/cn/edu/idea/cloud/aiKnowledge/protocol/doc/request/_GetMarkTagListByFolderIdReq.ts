/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.doc.request";

/**
 * 接口描述:根据文件夹Id获取笔记标签列表
 * 	接口url:/folder/getMarkTagListByFolderId
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetMarkTagListByFolderIdReq {
  /** 文件夹ID */
  folderId: string;
}
