/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.ios.appApprove.request";

/**
 * 接口描述:获取ios app审核配置列表
 * 	接口url:/admin/ipad/approve/deleteById
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface DeleteAppApproveReq {
  /** id */
  id: string;
}
