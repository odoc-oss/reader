/* eslint-disable */
import type { OrderStatus } from "./VipPayInfo";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.vip";

/**
 * 接口描述: 修改订单状态
 * 	接口url: /pay/order/updateOrderStatus
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface updateOrderStatusReq {
  /** 订单id */
  orderId: string;
  /** 订单状态 */
  orderStatus: OrderStatus;
}
