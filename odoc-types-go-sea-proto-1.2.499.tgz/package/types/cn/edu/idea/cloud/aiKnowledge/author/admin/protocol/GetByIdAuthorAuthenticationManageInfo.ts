/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.admin.protocol";

/**
 * 接口描述:作者认证管理端协议-getById
 * 	接口url:/admin/authorAuthentication/getById
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface AuthorGetByIdRequest {
  /** id */
  id: string;
}

export interface AuthorGetByIdResponse {
  /** id */
  id: string;
  /** userId */
  userId: string;
  /** authorId */
  authorId: string;
  /** authorName */
  authorName: string;
  /** description */
  description: string;
  /** publishStatus */
  publishStatus: number;
}
