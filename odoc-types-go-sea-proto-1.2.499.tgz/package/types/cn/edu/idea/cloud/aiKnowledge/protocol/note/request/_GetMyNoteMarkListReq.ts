/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.note.request";

export enum SortTypeEnum {
  /** NEWEST - 最新 */
  NEWEST = 0,
  /** EARLIEST - 最早 */
  EARLIEST = 1,
  /** DEFAULT - 默认排序: 列表时：按文献最近阅读倒序，搜索时：按搜索匹配度 */
  DEFAULT = 2,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述:查询我的笔记列表
 * 	接口url:
 *  web: /pdfMark/v2/web/getMyNoteMarkList
 *  ios: /pdfMark/v2/ios/getMyNoteMarkList
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetMyNoteMarkListReq {
  /** 文件夹id */
  folderId?:
    | string
    | undefined;
  /** 标签id */
  tagIdList: string[];
  /** 排序 */
  sortType: SortTypeEnum;
  currentPage: number;
  pageSize: number;
  /** 搜索内容 */
  searchContent: string;
  /** 显示规则 */
  styleIdList: number[];
  /**  */
  docId?: string | undefined;
}
