/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.seo";

/**
 * 接口描述: 获取sitemap接口，前端专用
 * 	接口url: /aiKnowledge/seo/getSitemap
 * 	接口请求方式: GET
 */
export interface GetSitemapReq {
}

export interface GetSitemapResp {
  /** sitemap信息 */
  item: FosItem[];
}

export interface FosItem {
  /** id */
  id: string;
  /** name */
  name: string;
}
