/* eslint-disable */
import type { AiPolishResultStatus } from "./AiPolishPdf";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

export enum PolishTaskType {
  ALL_POLISH = 0,
  REVIEW = 1,
  TITLE_POLISH = 2,
  ABSTRACT_POLISH = 3,
  INTRODUCTION_POLISH = 4,
  TITLE_GEN = 5,
  ABSTRACT_GEN = 6,
  ABSTRACT_MODIFY = 7,
  UNRECOGNIZED = -1,
}

export enum SelectTextEnum {
  /** SelectTextEnum_DEFAULT - 占位符，不用管 */
  SelectTextEnum_DEFAULT = 0,
  /** STANDARD - 标准模式 */
  STANDARD = 1,
  /** SHORTEN - 缩写模式 */
  SHORTEN = 2,
  /** EXPAND - 扩展模式 */
  EXPAND = 3,
  /** SIMPLE - 口语模式 */
  SIMPLE = 4,
  /** OPTIMIZATION - 优化 */
  OPTIMIZATION = 5,
  /** REDUCE_REPETITION - 降重 */
  REDUCE_REPETITION = 6,
  UNRECOGNIZED = -1,
}

export enum SynonymsEnum {
  /** SynonymsEnum_DEFAULT - 占位符，不用管 */
  SynonymsEnum_DEFAULT = 0,
  /** LEVEL1 - 一级强度 */
  LEVEL1 = 1,
  /** LEVEL2 - 二级强度 */
  LEVEL2 = 2,
  /** LEVEL3 - 三级强度 */
  LEVEL3 = 3,
  /** LEVEL4 - 四级强度 */
  LEVEL4 = 4,
  UNRECOGNIZED = -1,
}

export enum ApplyQuotaStatus {
  /** WAITING - 等待申请 */
  WAITING = 0,
  /** APPLYING - 已申请，等待审核 */
  APPLYING = 1,
  /** ACCEPT - 申请通过 */
  ACCEPT = 2,
  UNRECOGNIZED = -1,
}

export enum MaintenanceStatus {
  /** NORMAL - 系统正常 */
  NORMAL = 0,
  /** WARN - 弹窗提醒 */
  WARN = 1,
  /** MAINTENANCE - 系统维护 */
  MAINTENANCE = 2,
  UNRECOGNIZED = -1,
}

export enum TranslateMode {
  EN_TO_CN = 0,
  CN_TO_EN = 1,
  UNRECOGNIZED = -1,
}

/**
 * url:/text/polish/all
 *  /text/polish/review
 *  /text/polish/review2 (上一个任务的taskId和sectionId)
 *  /text/polish/title
 *  /text/polish/title2 (上一个任务的taskId和sectionId)
 *  /text/polish/abstract
 *  /text/polish/abstract2 (上一个任务的taskId和sectionId)
 *  /text/polish/introduction
 *  /text/polish/introduction2 (上一个任务的taskId和sectionId)
 *  /text/polish/absModify
 *  /text/polish/absModify2 (上一个任务的taskId和sectionId)
 *  /text/polish/genTitle
 *  /text/polish/genAbs
 * 	接口请求方式: POST
 */
export interface PolishRequest {
  /**
   * optional string title = 1[(common.notNull) = false];
   *  optional string abs = 2[(common.notNull) = false];
   *  optional string introduction = 3[(common.notNull) = false];
   *  optional string text = 4[(common.notNull) = false];
   *  optional string mark = 5[(common.notNull) = false];
   */
  pageId?: string | undefined;
  taskId?: string | undefined;
  sectionId?: string | undefined;
  parentPolishRequest?: ParentPolishRequest | undefined;
  demand?: string | undefined;
  temp?: string | undefined;
}

export interface ParentPolishRequest {
  taskId: string;
  sectionId: string;
}

export interface PolishResponse {
  taskId: string;
  sectionId?: string | undefined;
}

/**
 * url:/text/polish/result/all
 *  /text/polish/result/review
 *  /text/polish/result/title
 *  /text/polish/result/abstract
 *  /text/polish/result/introduction
 *  /text/polish/result/genTitle
 *  /text/polish/result/genAbs
 *  /text/polish/result/absModify
 *  /text/polish/result/absModify2
 * 调用方式:get
 */
export interface PolishResultRequest {
  taskId: string;
  sectionId?: string | undefined;
}

/**
 * /text/polish/result/genTitle
 * 调用方式:get
 * 参数类型:response
 */
export interface TitleGenResult {
  taskId: string;
  status: AiPolishResultStatus;
  sections: TitleGenSection[];
  errorMessage?: string | undefined;
  problems: string[];
}

export interface TitleGenSection {
  sectionId: string;
  sentences: TitleGenSentence[];
  status: AiPolishResultStatus;
  errorMessage?: string | undefined;
  isRefundAiBean?: boolean | undefined;
  createTime: string;
}

export interface TitleGenSentence {
  sentenceId: string;
  title: string;
  isDelete: boolean;
}

/**
 * /text/polish/result/genAbs
 * 调用方式:get
 * 参数类型:response
 */
export interface AbsGenResult {
  taskId: string;
  sectionId: string;
  newAbstract: string;
  translation: string;
  status: AiPolishResultStatus;
  errorMessage?: string | undefined;
  problems: string[];
  isRefundAiBean?:
    | boolean
    | undefined;
  /** 数据创建时间 */
  createTime: string;
}

/**
 * /text/polish/result/all
 * 调用方式:get
 * 参数类型:response
 */
export interface PolishAllResult {
  sentences: PolishSentence[];
  status: AiPolishResultStatus;
  percent: number;
  errorMessage?: string | undefined;
  isRefundAiBean?: boolean | undefined;
  createTime: string;
}

export interface PolishSentence {
  originalSentence: string;
  newSentence: string;
  taskId: string;
  sectionId: string;
  reason: string;
  createTime: string;
  index: number;
  accept: boolean;
  ignore: boolean;
}

/**
 * /text/polish/result/review
 * 调用方式:get
 * 参数类型:response
 */
export interface ReviewResult {
  taskId: string;
  content: string;
  scoreContent: string;
  status: AiPolishResultStatus;
  errorMessage?: string | undefined;
  createTime: string;
  ignore: boolean;
  isRefundAiBean?: boolean | undefined;
}

/**
 * /text/polish/result/title
 * 调用方式:get
 * 参数类型:response
 */
export interface PolishTitleResult {
  taskId: string;
  currentTitle: string;
  problems: string[];
  advicedTitles: string[];
  choosed: number;
  status: AiPolishResultStatus;
  errorMessage?: string | undefined;
  createTime: string;
  ignore: boolean;
  isRefundAiBean?: boolean | undefined;
}

/**
 * url:/text/polish/result/absModify
 * 调用方式:get
 * 参数类型:response
 */
export interface AbsModifyResult {
  taskId: string;
  sectionId: string;
  sourceAbstract?: string | undefined;
  newAbstract?: string | undefined;
  translation?: string | undefined;
  status: AiPolishResultStatus;
  errorMessage?: string | undefined;
  temp: string;
  isRefundAiBean?: boolean | undefined;
  createTime: string;
}

/**
 * url:/text/polish/result/abstract
 * 调用方式:get
 * 参数类型:response
 * url:/text/polish/result/updateAbstract
 * 调用方式:get
 * 参数类型:request
 */
export interface PolishAbstractResult {
  taskId: string;
  sourceAbstract: string;
  newAbstract: string;
  problems: string[];
  selectedTags: string[];
  accept: boolean;
  status: AiPolishResultStatus;
  errorMessage?: string | undefined;
  createTime: string;
  sectionId: string;
  index: number;
  ignore: boolean;
  isRefundAiBean?: boolean | undefined;
}

/**
 * /text/polish/result/introduction
 * 调用方式:get
 * 参数类型:response
 */
export interface PolishIntroductionResult {
  taskId: string;
  sourceIntroduction: string;
  newIntroduction: string;
  problems: string[];
  selectedTags: string[];
  accept: boolean;
  status: AiPolishResultStatus;
  errorMessage?: string | undefined;
  createTime: string;
  sectionId: string;
  index: number;
  ignore: boolean;
  isRefundAiBean?: boolean | undefined;
}

/**
 * url:/text/polish/getProjectIds
 * 	接口请求方式: GET
 */
export interface ProjectRequest {
}

export interface ProjectResponse {
  debug: boolean;
  projectId: string[];
}

/**
 * url:/text/polish/getPageIds
 * 	接口请求方式: GET
 */
export interface PageRequest {
  projectId: string;
}

export interface PageResponse {
  pages: Page[];
  projectName?: string | undefined;
}

export interface Page {
  pageId: string;
  version: string;
}

/**
 * url:/text/polish/getPageInfo
 * 	接口请求方式: GET
 */
export interface PageInfoRequest {
  pageId: string;
}

export interface PageInfoResponse {
  title?: string | undefined;
  abs?: string | undefined;
  introduction?: string | undefined;
  text: string;
  mark: string;
}

/**
 * url:/text/polish/savePageInfo
 * 	接口请求方式: POST
 */
export interface SavePageInfoRequest {
  projectId?: string | undefined;
  pageId?: string | undefined;
  title?: string | undefined;
  abs?: string | undefined;
  introduction?: string | undefined;
  text: string;
  mark?: string | undefined;
  parser?: boolean | undefined;
}

export interface SavePageInfoResponse {
  pageId: string;
  version: string;
}

/**
 * url:/text/polish/getTasks
 * 	接口请求方式: GET
 */
export interface AllPolishTaskRequest {
  projectId: string;
}

export interface AllPolishTaskResponse {
  tasks: PolishTask[];
}

/**
 * url:/text/polish/deleteTask
 * 	接口请求方式: POST
 */
export interface DeleteTaskRequest {
  taskId: string;
  sectionId?: string | undefined;
}

export interface PolishTask {
  taskId: string;
  sectionId: string;
  type: PolishTaskType;
  subTasks: Subtask[];
  /** 主任务创建时间 */
  createTime: string;
  /** 最后一个任务创建时间 */
  lastTaskTime: string;
  status: AiPolishResultStatus;
}

export interface Subtask {
  taskId: string;
  sectionId: string;
  status: AiPolishResultStatus;
}

/**
 * /text/polish/repolish/start
 * method: POST
 */
export interface RepolishTaskRequest {
  tags: string[];
  taskId: string;
  polishType: PolishTaskType;
}

export interface RepolishTaskResponse {
  sectionId: string;
}

/**
 * /text/polish/accept
 * method: PUT
 */
export interface PolishAcceptRequest {
  taskId: string;
  sectionId?: string | undefined;
}

/**
 * /text/polish/ignore
 * method: PUT
 */
export interface PolishIgnoreRequest {
  taskId: string;
  sectionId?: string | undefined;
}

/**
 * /text/polish/title/choose
 * method: PUT
 */
export interface TitleChooseRequest {
  taskId: string;
  /** 从0开始计算 */
  index: number;
}

/**
 * url:/text/polish/updateAbstract
 * 调用方式:get
 * 参数类型:request
 */
export interface UpdateAbstractRequest {
  taskId: string;
  sectionId: string;
  newAbstract: string;
}

/**
 * url:/text/polish/updateIntroduction
 * 调用方式:get
 * 参数类型:request
 */
export interface UpdateIntroductionRequest {
  taskId: string;
  sectionId: string;
  newIntroduction: string;
}

/**
 * 解析latex结果
 * 	url:/text/polish/parselatex
 * 	接口请求方式: get
 */
export interface ParseLatexReq {
  bucketName?: string | undefined;
  objectName?: string | undefined;
  pageId?: string | undefined;
  projectId: string;
}

export interface ParseLatexResp {
  pageId: string;
  version: string;
  markdownContent: string;
}

/**
 * 获取修改的解析结果，与latex上传共用结果
 * 	url:/text/polish/getParseResult
 * 	接口请求方式: get
 */
export interface GetParseResultReq {
  /** PageId */
  pageId: string;
  /** 是否强制解析 */
  mustParse: boolean;
}

export interface GetParseResultResp {
  /** 标题 */
  title?: string | undefined;
  titleSelectInfo?:
    | SelectInfo
    | undefined;
  /** 摘要 */
  abstarcts?: string | undefined;
  abstarctsSelectInfo?:
    | SelectInfo
    | undefined;
  /** 引言 */
  introduction?: string | undefined;
  introductionSelectInfo?:
    | SelectInfo
    | undefined;
  /** 方法 */
  method?: string | undefined;
  methodSelectInfo?:
    | SelectInfo
    | undefined;
  /** 结论与讨论 */
  conclusionDiscussion?: string | undefined;
  conclusionDiscussionSelectInfo?:
    | SelectInfo
    | undefined;
  /** 最新版本号 */
  latestVersion: number;
}

/**
 * 修改解析结果，上传哪个字段就修改哪个字段
 * 	url:/text/polish/modifyParseResult
 * 	接口请求方式: post
 */
export interface ModifyParseResultReq {
  pageId: string;
  title?: string | undefined;
  titleSelectInfo?: SelectInfo | undefined;
  abstarcts?: string | undefined;
  abstarctsSelectInfo?: SelectInfo | undefined;
  introduction?: string | undefined;
  introductionSelectInfo?: SelectInfo | undefined;
  method?: string | undefined;
  methodSelectInfo?: SelectInfo | undefined;
  conclusionDiscussion?: string | undefined;
  conclusionDiscussionSelectInfo?: SelectInfo | undefined;
  latestVersion: number;
}

/** 选段信息 */
export interface SelectInfo {
  /** 开始位置 */
  start: number;
  /** 结束位置 */
  end: number;
}

export interface ModifyParseResultResp {
}

/**
 * 选段润色
 *  url:/text/polish/text
 * 	接口请求方式: post
 *  content-type: text/stream
 */
export interface PolishTextReq {
  /** 模式 */
  selectTextEnum: SelectTextEnum;
  /** 强度 */
  synonymsEnum: SynonymsEnum;
  /** 字数 */
  wordCount?:
    | number
    | undefined;
  /** 选段 */
  text: string;
  /** 全文信息 */
  pageId: string;
  requestId?: string | undefined;
}

export interface PolishTextResponse {
  sessionId: string;
  content: string;
}

/**
 * 查看申请名额状态
 *  url:/text/polish/getApplyQuotaStatus
 * 	接口请求方式: get
 */
export interface GetApplyQuotaReq {
}

/**
 * 查看申请名额状态
 *  url:/text/polish/getApplyQuotaStatus
 * 	接口请求方式: post
 */
export interface GetApplyQuotaResp {
  status: ApplyQuotaStatus;
}

/**
 * 申请名额
 *  url:/text/polish/applyQuota
 * 	接口请求方式: post
 */
export interface ApplyQuotaReq {
}

export interface ApplyQuotaResp {
  status: ApplyQuotaStatus;
}

/**
 * 算法服务器状态
 * url:/text/polish/health/status
 * 接口请求方式: get
 */
export interface ServerStatusResponse {
  /** 多少任务正在运行 */
  running: number;
  /** 多少任务正在等待 */
  waiting: number;
  /**
   * 1： 正常工作
   * -1：无法接入新任务
   * 0：繁忙，可接入少量任务
   */
  status: number;
  /** gpu使用率 */
  gpuCacheUsage: number;
}

/**
 * 系统服务状态
 * url:/text/polish/maintenance/status
 * 接口请求方式: get
 */
export interface MaintenanceStatusResponse {
  status: MaintenanceStatus;
  text?: string | undefined;
}

/**
 * 创建项目
 * url:/text/polish/createProject
 * 接口请求方式: post
 */
export interface CreateProjectResponse {
  projectId: string;
}

/**
 * 修改项目
 * url:/text/polish/updateProject
 * 接口请求方式: post
 */
export interface UpdateProjectRequest {
  projectId: string;
  projectName: string;
}

export interface UpdateProjectResponse {
  success: boolean;
}

/**
 * 删除项目
 * url:/text/polish/deleteProject
 * 接口请求方式: post
 */
export interface DeleteProjectRequest {
  projectId: string;
}

export interface DeleteProjectResponse {
  success: boolean;
}

/**
 * 获取近期项目
 * url:/text/polish/recentProjects
 * 接口请求方式: get
 */
export interface RecentProjectsResponse {
  debug: boolean;
  simpleProjectInfos: SimpleProjectInfo[];
}

export interface SimpleProjectInfo {
  projectId: string;
  pageId?: string | undefined;
  version?: string | undefined;
  simpleTitle?: string | undefined;
  simpleText?: string | undefined;
}

/**
 * 选段润色保存用户偏好
 * url:/text/polish/saveSegmentPreference
 * 接口请求方式: post
 */
export interface SaveSegmentPreferenceRequest {
  segmentPreference?: SegmentPreference | undefined;
  windowSize?: WindowSize | undefined;
}

export interface SegmentPreference {
  selectTextEnum: SelectTextEnum;
  synonymsEnum: SynonymsEnum;
}

export interface SaveSegmentPreferencesResponse {
  success: boolean;
}

/**
 * 选段润色获取用户偏好
 * url:/text/polish/getSegmentPreference
 * 接口请求方式: get
 */
export interface GetSegmentPreferencesResponse {
  segmentPreference?: SegmentPreference | undefined;
  windowSize?: WindowSize | undefined;
}

export interface WindowSize {
  height: string;
  width: string;
}

/**
 * 解析上传文件结果
 * 	url:/text/polish/parseFile
 * 	接口请求方式: get
 */
export interface ParseFileRequest {
  bucketName?: string | undefined;
  objectName?: string | undefined;
  pageId?: string | undefined;
  projectId: string;
  latexName?:
    | string
    | undefined;
  /** 用户没有选则latex并且latexName为空时传true，其余可为null或者false */
  chooseLatex?: boolean | undefined;
}

export interface ParseFileResponse {
  pageInfo?: PageInfo | undefined;
  latexNames: string[];
}

export interface PageInfo {
  pageId: string;
  version: string;
  markdownContent: string;
}

/**
 * url:/text/polish/deleteSentence
 * 	接口请求方式: POST
 */
export interface DeleteSentenceRequest {
  taskId: string;
  sectionId: string;
  sentenceId: string;
}

/**
 * url:/text/polish/translate
 * 	接口请求方式: POST
 */
export interface TranslateRequest {
  text: string;
  mode: TranslateMode;
}

/**
 * 整段
 * 	url:/text/polish/rewrite (返回:String)
 *  逐句
 *  url:/text/polish/rewriteSentence
 * 	接口请求方式: POST
 */
export interface PolishRewriteRequest {
  mode: SelectTextEnum;
  text: string;
  uniqueId?:
    | string
    | undefined;
  /** 是否为中文 */
  isZH?: boolean | undefined;
}

/**
 * 整段
 * 	url:/text/polish/zhToEn (返回:String)
 *  逐句
 *  url:/text/polish/zhToEnSentence
 * 	接口请求方式: POST
 */
export interface ZhToEnRequest {
  text: string;
  uniqueId?: string | undefined;
}

/**
 * url:/text/polish/rewriteSentence
 * 	接口请求方式: POST
 */
export interface PolishRewriteResponse {
  sentences: TranslateSentence[];
}

/**
 * url:/text/polish/zhToEnSentence
 * 	接口请求方式: POST
 */
export interface ZhToEnResponse {
  sentences: TranslateSentence[];
  createTime: string;
}

export interface TranslateSentence {
  taskId: string;
  origin: string;
  target: string;
  uniqueId: string;
  createTime: string;
}
