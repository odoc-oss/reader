/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.activitys.protocol.response";

/**
 * 接口描述:活动合集-获取活动数据列表出参
 *   接口url:/aiKnowledge/activitys/item
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface ActivitysItemResponse {
  /** total，总页数 */
  total: number;
  /** pageNum，当前页 */
  pageNum: number;
  /** pageSize，每页的数量 */
  pageSize: number;
  /** 活动数据列表 */
  list: ActivitysItem[];
  /** 系统时间 */
  unixTime: number;
}

export interface ActivitysItem {
  /** 活动名称 */
  title: string;
  /** 活动图片url */
  picUrl: string;
  /** 跳转url */
  jumpUrl: string;
  /** theme color */
  themeColor: string;
  /** 活动标签 */
  label: string;
  /** 活动开始时间 */
  startTime: number;
  /** 活动结束时间 */
  endTime: number;
}
