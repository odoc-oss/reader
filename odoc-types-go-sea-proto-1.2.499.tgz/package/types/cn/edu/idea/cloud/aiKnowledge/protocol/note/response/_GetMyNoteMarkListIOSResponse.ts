/* eslint-disable */
import type { IOSNoteAnnotateContentModel } from "../../../notev2/IOS";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.note.response";

/**
 * 接口描述:查询我的笔记列表
 * 	接口url:/pdfMark/v2/ios/getMyNoteMarkList
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetMyNoteMarkListIOSResponse {
  /** 笔记内容 */
  annotationModelList: IOSNoteAnnotateContentModel[];
  total: number;
}
