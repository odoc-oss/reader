/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.activitys.protocol.request";

/**
 * 接口描述:活动-获取活动数据列表入参
 *   接口url:/aiKnowledge/activitys/item
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface ActivitysItemRequest {
  /** tagId不能为空，全部时为0 */
  tagId: string;
  currentPage: number;
  pageSize: number;
}
