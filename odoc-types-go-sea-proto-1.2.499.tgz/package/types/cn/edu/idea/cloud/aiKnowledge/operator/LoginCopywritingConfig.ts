/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.config";

/**
 * path: /public/config/login/copywriting
 * GET 请求
 * 服务名: microService-app-aiknowledge
 */
export interface GetLoginCopywritingReq {
  /** 设备 */
  deviceId: string;
  /** url，当前页面的url */
  url: string;
}

export interface GetLoginCopywritingResp {
  /** 文案列表 */
  copywritingList: string[];
  /** 文案标题 */
  title: string;
}
