/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.protocol.request";

/**
 * 接口描述:获取信息纠错问题类型列表
 * 	接口url:/aiKnowledge/author/getCorrectInfoQuestionTypeList
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetCorrectInfoQuestionTypeListReq {
}

export interface GetCorrectInfoQuestionTypeListResponse {
  /** 问题类型列表 */
  questionTypeList: CorrectInfoQuestionTypeInfo[];
}

export interface CorrectInfoQuestionTypeInfo {
  /** id */
  id: string;
  /** 名称 */
  name: string;
}
