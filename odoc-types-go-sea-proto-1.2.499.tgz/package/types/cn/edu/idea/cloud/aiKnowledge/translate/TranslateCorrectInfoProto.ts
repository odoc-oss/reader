/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate";

/**
 * 接口描述:翻译纠错
 *   接口url:/ts/correct
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface TranslateCorrectInfoReq {
  /** requestId */
  requestId: string;
  /** youdao/tencent/google/baidu/deepl/idea 对齐数据上报 */
  sources: string;
}
