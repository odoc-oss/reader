/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.operator.admin.paper";

/**
 * 接口描述: 论文荣誉外显-入参
 *   接口url:/admin/operator/paperCommentSign/getById
 *   接口请求方式: POST
 *   参数格式:application/json
 */
export interface PaperCommentSignAdminGetByIdReq {
  id: string;
}

export interface PaperCommentSignAdminGetByIdResp {
  /** 显示标题 */
  title: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
  /** 发布状态 */
  publishStatus: number;
}

/**
 * 接口描述: 论文荣誉外显-moidfy
 * 	接口url:/admin/operator/paperCommentSign/modify
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface PaperCommentSignAdminModifyReq {
  /** id */
  id: string;
  /** paper id */
  paperId: string;
  /** 显示标题 */
  title: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
}

export interface PaperCommentSignAdminModifyResp {
  /** 数据id */
  id: string;
  /** paper id */
  paperId: string;
  /** paper name */
  paperName: string;
  /** 显示标题 */
  title: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
  /** 发布状态 */
  publishStatus: number;
}

/**
 * 接口描述: 论文荣誉外显-save
 * 	接口url:/admin/operator/paperCommentSign/save
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface PaperCommentSignAdminSaveReq {
  /** 显示标题 */
  title: string;
  /** 显示时长 */
  paperId: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
}

export interface PaperCommentSignAdminSaveResp {
  /** paper id */
  paperId: string;
  /** paper name */
  paperName: string;
  /** 显示标题 */
  title: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
  /** 发布状态 */
  publishStatus: number;
}

/**
 * 接口描述: 论文荣誉外显-deleteById
 * 	接口url:/admin/operator/paperCommentSign/deleteById
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface PaperCommentSignAdminDeleteByIdReq {
  /** 数据id */
  id: string;
}

export interface PaperCommentSignAdminDeleteByIdResp {
}

/**
 * 接口描述: 论文荣誉外显-list
 * 	接口url:/admin/operator/paperCommentSign/list
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface PaperCommentSignAdminListReq {
  /** title */
  title: string;
  /** paperId */
  paperId: string;
  /** publishStatus */
  publishStatus: number;
  currentPage: number;
  pageSize: number;
}

export interface PaperCommentSignAdminListResp {
  /** total，总页数 */
  total: string;
  /** pageNum，当前页 */
  pageNum: number;
  /** pageSize，每页的数量 */
  pageSize: number;
  /** 列表数据 */
  list: PaperCommentSignItem[];
}

export interface PaperCommentSignItem {
  /** 数据id */
  id: string;
  /** paper id */
  paperId: string;
  /** paper name */
  paperName: string;
  /** 显示标题 */
  title: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
  /** 发布状态 */
  publishStatus: number;
}

/**
 * 接口描述: 论文荣誉管理-publishAll
 * 	接口url:/admin/operator/paperCommentSign/publishAll
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SearchCommentSignAdminPublishAllReq {
}
