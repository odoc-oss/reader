/* eslint-disable */
import type { UserInfoBean } from "../../user/UserInfo";
import type { VipPrivilege, VipType } from "../../user/VipUserInterface";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.vip";

export enum PaySourceType {
  /** NONE - 占位用 */
  NONE = 0,
  /** WX_H5 - 微信H5渠道直接购买 */
  WX_H5 = 1,
  UNRECOGNIZED = -1,
}

export enum PayStatus {
  /** PAY_PRE - 预下单 */
  PAY_PRE = 0,
  /** PAY_WAITING - 等待支付 */
  PAY_WAITING = 1,
  /** PAY_SUCCESS - 支付成功 */
  PAY_SUCCESS = 2,
  /** PAY_FAIL - 支付失败 */
  PAY_FAIL = 3,
  /** PAY_COMPLETED - 支付已完成，成功后才有 */
  PAY_COMPLETED = 4,
  /** PAY_TIMEOUT - 支付超时 */
  PAY_TIMEOUT = 5,
  /** REFUND_PRE - 预退款 */
  REFUND_PRE = 6,
  /** REFUND_WAITING - 等待退款 */
  REFUND_WAITING = 7,
  /** REFUND_SUCCESS - 退款成功 */
  REFUND_SUCCESS = 8,
  /** REFUND_FAIL - 退款失败 */
  REFUND_FAIL = 9,
  /** REFUND_COMPLETED - 退款完成，成功后才有 */
  REFUND_COMPLETED = 10,
  /** REFUND_TIMEOUT - 退款超时 */
  REFUND_TIMEOUT = 11,
  UNRECOGNIZED = -1,
}

/** 订单状态 */
export enum OrderStatus {
  /** NOT_INVOICED - 未开票 */
  NOT_INVOICED = 0,
  /** WAIT_INVOICED - 开票中 */
  WAIT_INVOICED = 1,
  /** INVOICED - 已开票 */
  INVOICED = 2,
  UNRECOGNIZED = -1,
}

/** 付费类型 */
export enum VipPayType {
  /** STANDARD - 标准版 */
  STANDARD = 0,
  /** PROFESSIONAL - 专业版 */
  PROFESSIONAL = 1,
  /** OUTSTANDING - 杰出版 */
  OUTSTANDING = 2,
  /** AIBEAN - ai豆 */
  AIBEAN = 3,
  /** PAPER_AI_REVIEW - 毕业论文-ai评审 */
  PAPER_AI_REVIEW = 4,
  /** GROUP_PAY - 团购 */
  GROUP_PAY = 5,
  UNRECOGNIZED = -1,
}

export enum AIBeanType {
  VIP_PRIVILEGE = 0,
  AI_PACKAGE = 1,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: vip权益，当有用户状态时，根据用户状态计算各个版本
 * 	接口url: /pay/public/getVipPrivilege
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetVipPrivilegeReq {
}

export interface GetVipPrivilegeResp {
  paySwitch: boolean;
  vipPayPrivilege: VipPrivilege[];
  contract: string;
  enterpriseQRCode: string;
  enabled: boolean;
  payByDialog: boolean;
  licensee: string;
  /** 团队功能tips */
  teamFeatureTips: string;
  /** 最大续费天数 */
  maxDays: number;
  /** 当低于xx天时，可以续费标准版 */
  allowPlanLowVipDays: number;
  /** 环境 */
  env: string;
  /** 访问的域名 */
  payOrigin?:
    | string
    | undefined;
  /** 团购订单付款上限 */
  groupBuyAmountLimit: string;
}

/**
 * 接口描述: vip权益，当有用户状态时，根据用户状态计算各个版本
 * 	接口url: /public/pay/getOrderReceiptInfo
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetOrderReceiptInfoReq {
  /** 微信给的订单流水号 */
  outTradeNo: string;
}

export interface GetOrderReceiptInfoResp {
  /** 支付内容 */
  subject: string;
  /** 支付金额 */
  payTotalAmount: string;
  /** 支付来源渠道 */
  paySourceType?:
    | PaySourceType
    | undefined;
  /** 支付类型 */
  vipPayType?: VipPayType | undefined;
}

/**
 * 接口描述: 获取付款二维码,支持支付宝、微信扫码
 * 	接口url: /pay/getScanQRCode
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetScanQRCodeReq {
  /** 根据vip付费方式生成订单信息、二维码信息、订单金额 */
  vipPayType: VipPayType;
  taskId?: string | undefined;
  reservedResourceId?: string | undefined;
}

export interface GetScanQRCodeResp {
  /** 通过当前请求时的host+payRouteUri来确定支付渠道，参数会附带在payRouteUri */
  payRouteUri: string;
  /** 预支付订单号 */
  preOrderId: string;
  /** 剩余vip天数 */
  remainingVip: string;
  /** 付款金额 */
  payTotalAmount?:
    | string
    | undefined;
  /** 付款时的domain */
  payDomain: string;
}

/**
 * 接口描述: 获取付款二维码,支持支付宝、微信扫码
 * 	接口url: /pay/getGroupBuyScanQRCode
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetGroupBuyScanQRCodeReq {
  /** 根据付款类型生成订单信息、二维码信息、订单金额 */
  vipPayType: VipPayType;
  /** 需要团购的信息 */
  groupBuyItem: GroupBuyItem[];
}

export interface GroupBuyItem {
  /** 购买的vip类型 */
  buyVipType: VipType;
  /** 购买的vip数量 */
  vipAmount: number;
}

export interface GetGroupBuyScanQRCodeResp {
  /** 通过当前请求时的host+payRouteUri来确定支付渠道，参数会附带在payRouteUri */
  payRouteUri: string;
  /** 预支付订单号 */
  preOrderId: string;
  /** 付款金额 */
  payTotalAmount?:
    | string
    | undefined;
  /** 付款时的domain */
  payDomain: string;
}

/**
 * 接口描述: 获取付款二维码,支持支付宝、微信扫码
 * 	接口url: /pay/getLenovoGroupBuyScanQRCode
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetLenovoGroupBuyScanQRCodeReq {
  /** 根据付款类型生成订单信息、二维码信息、订单金额 */
  vipPayType: VipPayType;
  /** 需要团购的信息 */
  groupBuyItem: GroupBuyItem[];
}

export interface GetLenovoGroupBuyScanQRCodeResp {
  /** 通过当前请求时的host+payRouteUri来确定支付渠道，参数会附带在payRouteUri */
  payRouteUri: string;
  /** 预支付订单号 */
  preOrderId: string;
  /** 付款金额 */
  payTotalAmount?:
    | string
    | undefined;
  /** 付款时的domain */
  payDomain: string;
}

/**
 * 接口描述: 获取付款二维码,支持支付宝、微信扫码
 * 	接口url: /pay/getLenovoScanQRCode
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetLenovoScanQRCodeReq {
  /** 根据vip付费方式生成订单信息、二维码信息、订单金额 */
  vipPayType: VipPayType;
  taskId?: string | undefined;
  reservedResourceId?: string | undefined;
}

export interface GetLenovoScanQRCodeResp {
  /** 通过当前请求时的host+payRouteUri来确定支付渠道，参数会附带在payRouteUri */
  payRouteUri: string;
  /** 预支付订单号 */
  preOrderId: string;
  /** 剩余vip天数 */
  remainingVip: string;
  /** 付款金额 */
  payTotalAmount?:
    | string
    | undefined;
  /** 付款时的domain */
  payDomain: string;
}

/**
 * 接口描述: 扫码后，获取付款信息
 *  注意：仅支持微信和支付宝，使用其他方法扫码，会提示错误
 * 	接口url: /public/pay/getPayInfo
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetPayInfoReq {
  preOrderId: string;
}

export interface GetPayInfoResp {
  status: PayStatus;
  payInfo?: PayInfo | undefined;
  payUserInfo?:
    | UserInfoBean
    | undefined;
  /** 支付微信公众号id */
  wxAppId?:
    | string
    | undefined;
  /** 支付宝生活号id */
  aliAppId?: string | undefined;
}

/**
 * 接口描述: 扫码后，获取调起支持渠道信息接口，通过user-agent来区分不同的支付渠道
 *  注意：仅支持微信和支付宝，使用其他方法扫码，会提示错误
 * 	接口url: /public/pay/prePay
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface PrePayReq {
  preOrderId: string;
  wxCode?: string | undefined;
  aliCode?: string | undefined;
  paySourceType?: PaySourceType | undefined;
}

export interface PrePayResp {
  status?: PayStatus | undefined;
  wechatJsPayInfo?: WechatJsPayInfo | undefined;
  aliJsPayInfo?: AliJsPayInfo | undefined;
}

/**
 * 接口描述: 获取付款状态，轮询，要鉴权
 * 	接口url: /pay/getPayStatus
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetPayStatusReq {
  /** 预支付订单号 */
  preOrderId: string;
}

export interface GetPayStatusResp {
  status: PayStatus;
}

export interface WechatJsPayInfo {
  /** 公众号ID，由商户传入 */
  appId: string;
  /** 时间戳，自1970年以来的秒数 */
  timeStamp: string;
  /** 随机串 */
  nonceStr: string;
  packages: string;
  /** 微信签名方式： */
  signType: string;
  /** 微信签名 */
  paySign: string;
}

export interface AliJsPayInfo {
  /** 支付宝返回的预下单信息 */
  prePayId: string;
}

export interface PayInfo {
  /** 付款的vip类型 */
  vipPayType: VipPayType;
  /** 不同类型会员对应的权益 */
  vipPrivilege?: VipPrivilege | undefined;
}

/** 全局：当status为2时，里面的内容,Free->STANDARD，返回STANDARD, STANDARD->PERFRESSIONAL，返回PERFRESSIONAL */
export interface NeedVipException {
  needVipType: VipType;
  /** 为true时，表示权限不受当前用户限制 */
  notCurrentUser?: boolean | undefined;
}

/** 全局：当status为3时，里面的内容,Free->STANDARD，返回STANDARD, STANDARD->PERFRESSIONAL，返回PERFRESSIONAL */
export interface NeedAiBeanException {
  needVipType: VipType;
}

/**
 * 接口描述: 获取当前用户的ai豆数量及消耗
 * 	接口url: /pay/bean/count
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface AiBeanCountResponse {
  aiBeanCount: string;
  aiBeanCountCostEveryQuesion: string;
  aiBeanCountCostEveryPolish: string;
  aiBeanCountCostEveryReview: string;
  aiBeanCountCostEveryTitleGeneration: string;
  aiBeanCountCostEveryAbstractGeneration: string;
  aiBeanCountCostEveryAbstractRewrite: string;
  aiBeanCountCostEveryAbstractTruingFramework: string;
  promptIfAiBeanCostMoreThan: number;
  promptIfAiBeanLeft: number;
  promptIfVipNotEnough: number;
  /** 是否能信用退豆 */
  canCreditRefund: boolean;
  /** 退豆的时效性 */
  refundTimeliness: number;
  aiBeanCountCostEveryAiTranslate: string;
}

/**
 * 接口描述: 获取当前用户的ai豆数量详细情况
 * 	接口url: /pay/bean/count/detail
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface AiBeanCountDetailResponse {
  items: AiBeanCountDetail[];
}

export interface AiBeanCountDetail {
  aiBeanType: AIBeanType;
  count: string;
  originalCount: string;
  effectiveEndDate: string;
}

/**
 * 接口描述: 升级专业版或者买豆
 * 	接口url: /pay/bean/buy
 * 	接口请求方式: get
 *  serviceId: readpaper-pay
 */
export interface BuyAiBeanResponse {
  upgradeVipPro?: UpgradeVipPro | undefined;
  aiBeanPackage?: AiBeanPackage | undefined;
  paySwitch: boolean;
}

export interface UpgradeVipPro {
  cost: number;
  aiBeanCountEveryWeek: number;
  vipPayType: VipPayType;
}

export interface AiBeanPackage {
  /** 单元 分 */
  price: string;
  aiBeanCount: number;
  expireDays: number;
}
