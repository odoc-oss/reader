/* eslint-disable */
import type { UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/**
 * 新增/强制新增
 * url: /mergePaper/add
 * 请求方式: JSON
 */
export interface AddReq {
  forceFlag: boolean;
  mergeIds: MergeId[];
}

export interface MergeId {
  masterId: string;
  slaveId: string;
}

/**
 * 批量新增
 * url: /mergePaper/batchAdd
 * 请求方式: application/x-www-form-urlencoded
 */
export interface BatchAddReq {
  file: Uint8Array;
}

/**
 * 获取合并历史列表
 * url: /mergePaper/getHistoryList
 * 请求方式: JSON
 */
export interface GetHistoryListReq {
  masterId: string;
  slaveId: string;
  currentPage: number;
  pageSize: number;
}

export interface GetHistoryListResponse {
  total: string;
  historyList: MergePaperHistoryVO[];
}

export interface MergePaperHistoryVO {
  masterId: string;
  slaveId: string;
  /** 类型:0=系统,1=人工 */
  type: number;
  /** 0=合并完成,1=合并失败,2=校验不通过 */
  status: number;
  id: string;
  createDate: string;
  operator?: UserInfoBean | undefined;
}
