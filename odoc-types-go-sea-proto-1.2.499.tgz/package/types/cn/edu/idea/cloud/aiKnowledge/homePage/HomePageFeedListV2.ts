/* eslint-disable */
import type {
  BaseFeed,
  BaseOperatorFeed,
  FOSDiscussion,
  OperatorClassicAnswer,
  OperatorCollect,
  OperatorImageText,
  OperatorReviewComment,
  OperatorText,
  Paper,
  PaperClassicTenAnswer,
  PaperQuestion,
  PaperQuestionAnswer,
  PaperReviewComment,
} from "./HomePageFeedCommon";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.homePage";

/**
 * 接口描述: 首页获取信息流-不需要登录
 * 	接口url: /aiKnowledge/feed/list/v2
 * 	接口请求方式: GET
 */
export interface GetFeedListReqV2 {
  /**
   * enum
   * "ALL"  混排
   * "PAPER" 仅看paper
   */
  showType: string;
  /** 当前页，第一页从1开始 */
  currentPage: number;
  /** 最后位置,第一页第一条从0开始 */
  lastedPosition: number;
}

export interface GetFeedListRespV2 {
  feeds: FeedV2[];
  /** 是否已到底 */
  isEnd: boolean;
  /** 最后位置，每次获取下一页时，回传给后台 */
  lastedPosition: number;
}

export interface FeedV2 {
  baseFeed?: BaseFeed | undefined;
  baseOperatorFeed?: BaseOperatorFeed | undefined;
  paperClassicTenAnswer?: PaperClassicTenAnswer | undefined;
  paperReviewComment?: PaperReviewComment | undefined;
  paperQuestion?: PaperQuestion | undefined;
  paperQuestionAnswer?: PaperQuestionAnswer | undefined;
  operatorClassicAnswer?: OperatorClassicAnswer | undefined;
  operatorReviewComment?: OperatorReviewComment | undefined;
  operatorCollect?: OperatorCollect | undefined;
  operatorImageText?: OperatorImageText | undefined;
  operatorText?: OperatorText | undefined;
  fosDiscussion?: FOSDiscussion | undefined;
  paper?: Paper | undefined;
}
