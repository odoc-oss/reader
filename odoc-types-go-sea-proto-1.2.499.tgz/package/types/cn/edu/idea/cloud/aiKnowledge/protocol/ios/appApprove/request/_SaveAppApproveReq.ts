/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.ios.appApprove.request";

/**
 * 接口描述:保存ios app审核配置
 * 	接口url:/admin/ipad/approve/save
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SaveAppApproveReq {
  /** id */
  id: string;
  /** 版本信息 */
  version: string;
  /** app store 审核状态 */
  appStoreStatus: string;
}
