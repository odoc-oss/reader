/* eslint-disable */
import type { AdministratorEnum } from "./FieldOfStudyDetail";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.fieldOfStudy";

export enum SortType {
  DEFAULT = 0,
  LASTEST = 1,
  HOTTEST = 2,
  UNRECOGNIZED = -1,
}

/**
 * url: /fos/discussion
 *  method: POST
 */
export interface CreateDiscussionRequest {
  title: string;
  relatedPaperIds: string[];
  content?:
    | string
    | undefined;
  /** fos is short for 'field of study' */
  fosId: string;
  briefContent?: string | undefined;
}

export interface CreateDiscussionResponse {
  id: string;
}

/**
 * url: /fos/discussion
 *  method: PUT
 *  返回通用的状态码
 */
export interface UpdateDiscussionRequest {
  title: string;
  relatedPaperIds: string[];
  content?: string | undefined;
  id: string;
  briefContent?: string | undefined;
}

/**
 * url: /fos/discussion
 *  method: DELETE
 *  返回通用的状态码
 */
export interface DeleteDiscussionRequest {
  id: string;
}

/**
 * url: /fos/discussion
 *  method: GET
 */
export interface FetchDiscussionRequest {
  id: string;
}

export interface FetchDiscussionResponse {
  discussionElement?: DiscussionElement | undefined;
  content?: string | undefined;
  paperDetailList: PaperDetail[];
  fosId: string;
  fosTitle: string;
}

/**
 * url: /fos/discussion:list
 *  method: GET
 *  返回通用的状态码
 */
export interface FetchDiscussionsRequest {
  fosId: string;
  pageNumber: number;
  pageSize: number;
  sortType: SortType;
}

export interface FetchDiscussionsResponse {
  discussions: DiscussionElement[];
  totalSize: number;
}

export interface DiscussionElement {
  title: string;
  briefContent?: string | undefined;
  id: string;
  createTimestamp: string;
  modifyTimeStamp: string;
  browseCount: string;
  replyCount: number;
  discussionCreator?: DiscussionCreator | undefined;
  isTop: boolean;
  /** 是否置顶 */
  isRecommended: boolean;
  thumbnailImageUrl: string;
  isHide: boolean;
}

export interface DiscussionCreator {
  avatarUrl: string;
  nickName: string;
  platformTags: string[];
  role: AdministratorEnum;
  userId: string;
  lastLoginTimeByDay: number;
}

/**
 * url: /fos/discussion:hide
 *  method: PUT
 *  返回通用的状态码
 */
export interface HideDiscussionRequest {
  id: string;
}

/**
 * url: /fos/discussion:unhide
 *  method: PUT
 *  返回通用的状态码
 */
export interface UnhideDiscussionRequest {
  id: string;
}

/**
 * url: /fos/discussion:recommend
 *  method: PUT
 *  返回通用的状态码
 *  加精。没有太好的中文翻译，使用recommend
 */
export interface RecommendDiscussionRequest {
  id: string;
}

/**
 * url: /fos/discussion:unrecommend
 *  method: PUT
 *  返回通用的状态码
 */
export interface UnrecommendDiscussionRequest {
  id: string;
}

/**
 * url: /fos/discussion:top
 *  method: PUT
 *  返回通用的状态码
 */
export interface TopDiscussionRequest {
  id: string;
}

export interface TopDiscussionResponse {
  showTips: boolean;
}

/**
 * url: /fos/discussion:untop
 *  method: PUT
 *  返回通用的状态码
 */
export interface UntopDiscussionRequest {
  id: string;
}

export interface PaperDetail {
  paperId: string;
  title: string;
}
