/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.paper";

/**
 * 接口描述: 获取上传token
 * 	接口url:/paperDuplicateCheck/getUploadToken
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetPaperDuplicateCheckUploadTokenReq {
  md5: string;
  fileName: string;
}

export interface GetPaperDuplicateCheckUploadTokenResponse {
  needUpload: boolean;
  /** 用来上传文件的token */
  uploadToken?: string | undefined;
}

/**
 * 接口描述: 获取用户剩余查重次数以及是否解锁权限
 * 	接口url:/paperDuplicateCheck/getRightInfo
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetPaperDuplicateCheckRightInfoReq {
}

export interface GetPaperDuplicateCheckRightInfoResponse {
  /** 试用体验剩余次数 */
  experienceCount?:
    | number
    | undefined;
  /** 当天剩余次数 */
  todayCount?:
    | number
    | undefined;
  /** 试用体验总次数 */
  experienceTotalCount?:
    | number
    | undefined;
  /** 当天总次数 */
  todayTotalCount?:
    | number
    | undefined;
  /** 是否解锁权限 */
  unlockRight: boolean;
}

/**
 * 接口描述: 获取用户查重历史列表(以及正在查重中的论文)
 * 	接口url:/paperDuplicateCheck/getHistory
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetPaperDuplicateCheckHistoryReq {
  currentPage?: number | undefined;
  pageSize?: number | undefined;
}

export interface GetPaperDuplicateCheckHistoryResponse {
  total: number;
  /** 查重中的论文 */
  checkingItem?:
    | HistoryItem
    | undefined;
  /** 已出查重结果的历史 */
  items: HistoryItem[];
  /** 案例 */
  caseItem?: HistoryItem | undefined;
}

export interface HistoryItem {
  fileId: string;
  fileTitle: string;
  createDate: string;
  /** 查重结果状态码,0=上传成功,110=验证中,120=验证成功,130=验证失败,210=查重中,220=查重处理完成,1=上传中 */
  status: number;
}

/**
 * 接口描述: 获取查重结果
 * 	接口url:/aiKnowledge/paperDuplicateCheck/getResult
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetPaperDuplicateCheckResultReq {
  fileId: string;
}

export interface GetPaperDuplicateCheckResultResponse {
  fileTitle: string;
  /** 查重结果 */
  result: string;
}

/**
 * 接口描述: 上传需要查重的文件
 * 	接口url:/paperDuplicateCheck/upload
 * 	接口请求方式: POST
 *  proto协议没有文件类型, 参考 /mergePaper/batchAdd 这个接口的传参
 */
export interface PaperDuplicateCheckUploadReq {
}
