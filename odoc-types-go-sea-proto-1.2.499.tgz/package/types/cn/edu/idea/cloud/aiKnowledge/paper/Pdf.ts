/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.paper";

/**
 * 用户选择要使用的版本
 * POST /pdf/select
 */
export interface SelectPdfRequest {
  pdfId: string;
  paperId: string;
}

export interface SelectPdfResponse {
}
