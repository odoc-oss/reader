/* eslint-disable */
import type {
  BaseFeed,
  BaseOperatorFeed,
  FOSDiscussion,
  OperatorClassicAnswer,
  OperatorCollect,
  OperatorImageText,
  OperatorReviewComment,
  OperatorText,
  PaperClassicAnswer,
  PaperQuestion,
  PaperQuestionAnswer,
  PaperReviewComment,
} from "./HomePageFeedCommon";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.homePage";

/**
 * 接口描述: 首页获取信息流-不需要登录
 * 	接口url: /aiKnowledge/feed/list
 * 	接口请求方式: GET
 */
export interface GetFeedListReq {
  currentPage: number;
}

export interface GetFeedListResp {
  feeds: Feed[];
  /** 是否已到底 */
  isEnd: boolean;
}

export interface Feed {
  baseFeed?: BaseFeed | undefined;
  baseOperatorFeed?: BaseOperatorFeed | undefined;
  paperClassicAnswer?: PaperClassicAnswer | undefined;
  paperReviewComment?: PaperReviewComment | undefined;
  paperQuestion?: PaperQuestion | undefined;
  paperQuestionAnswer?: PaperQuestionAnswer | undefined;
  operatorClassicAnswer?: OperatorClassicAnswer | undefined;
  operatorReviewComment?: OperatorReviewComment | undefined;
  operatorCollect?: OperatorCollect | undefined;
  operatorImageText?: OperatorImageText | undefined;
  operatorText?: OperatorText | undefined;
  fosDiscussion?: FOSDiscussion | undefined;
}
