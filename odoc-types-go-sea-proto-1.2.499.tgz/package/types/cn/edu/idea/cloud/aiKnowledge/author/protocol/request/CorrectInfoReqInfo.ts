/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.protocol.request";

/**
 * 接口描述:作者信息纠错
 * 	接口url:/author/correctInfo
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface CorrectInfoReq {
  /** 问题类型ID */
  questionTypeIdList: string[];
  /** 作者id */
  authorId: string;
  /** 问题描述 */
  description: string;
}
