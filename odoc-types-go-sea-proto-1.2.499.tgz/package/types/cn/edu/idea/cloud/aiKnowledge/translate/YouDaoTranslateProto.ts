/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate";

/**
 * 接口描述:中文翻译接口入参
 *   接口url:/ts/youdao/zh-cn
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface YoudaoTranslateReq {
  /** content */
  content: string;
}

export interface YouDaoTranslateResp {
  /** 目标翻译 */
  targetContent: string[];
  /** 网络释义，有道专用，有可能不存在 */
  netWorkContent: YouDaoTranslateNetworkContentResp[];
  /** requestId */
  requestId: string;
}

export interface YouDaoTranslateNetworkContentResp {
  list: string[];
}
