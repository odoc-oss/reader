/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.request.friends";

export enum IdolTypeEnum {
  BAD = 0,
  GOOD = 1,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述:添加关注
 * 	接口url:/idea/nice
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface AddIdolReq {
  /** 被关注者id */
  idolId: string;
  idolInfos: IdolInfo[];
  idolType: IdolTypeEnum;
}

export interface IdolInfo {
  idolId: string;
  name: string;
}
