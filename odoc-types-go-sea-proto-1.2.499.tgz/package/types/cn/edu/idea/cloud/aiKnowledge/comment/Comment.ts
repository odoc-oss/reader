/* eslint-disable */
import type { CommentatorInfoView } from "../notev2/Common";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.comment";

export enum CommentType {
  /** RESOURCE - 评论的是外部资源，比如讨论、笔记 */
  RESOURCE = 0,
  /** COMMENT - 评论的是其它的[评论] */
  COMMENT = 1,
  UNRECOGNIZED = -1,
}

export enum SceneEnum {
  DISCUSSION = 0,
  FIELD_OF_STUDY = 1,
  UNRECOGNIZED = -1,
}

/**
 * url: /common/comment
 *  method: POST
 */
export interface AddCommentRequest {
  content: string;
  /** 如果是直接回复资源，这里就是资源的id。如果回复别人的评论，那就是评论的id */
  commentedObjectId: string;
  /** 被评论的资源id,比如说讨论的id。最上层的资源id */
  resourceId: string;
  sceneEnum: SceneEnum;
  /** 父级资源id.如果是评论，这里就是资源的id。如果是回复，则是上级回复的id */
  parentResourceId: string;
}

export interface AddCommentResponse {
  id: string;
}

/**
 * url: /common/comment
 *  method: Delete
 *  请求参数放在url上
 *  返回通用的状态码
 */
export interface DeleteCommentRequest {
  id: string;
}

/**
 * url: /common/comment
 *  method: PUT
 *  返回通用的状态码
 */
export interface UpdateCommentRequest {
  id: string;
  content: string;
}

/**
 * url: /common/comment:list
 *  method: GET
 */
export interface FetchCommentRequest {
  resourceId: string;
  pageNumber: number;
  pageSize: number;
}

export interface FetchCommentResponse {
  layeredCommtent: LayeredComment[];
  totalSize: number;
}

export interface CommentElement {
  content: string;
  id: string;
  /** 评论人信息 */
  commentator?:
    | CommentatorInfoView
    | undefined;
  /** 被评论人信息 */
  commentedUser?: CommentatorInfoView | undefined;
  timestamp: string;
}

export interface LayeredComment {
  /** 资源的评论 */
  resourceComment?:
    | CommentElement
    | undefined;
  /** 评论的评论，或称之为子评论 */
  commentsOfComment: CommentElement[];
}
