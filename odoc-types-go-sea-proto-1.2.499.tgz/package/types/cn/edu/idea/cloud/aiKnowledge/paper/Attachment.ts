/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.paper";

export enum PaperAttachmentType {
  FILE = 0,
  LINK = 1,
  UNRECOGNIZED = -1,
}

export enum AttachmentStatus {
  UPLOAD = 0,
  VERIFY = 1,
  SAVE = 2,
  FINISH = 3,
  FAILED = 4,
  CANCELED = 5,
  UNRECOGNIZED = -1,
}

export interface PaperAttachmentAuthor {
  id: string;
  name: string;
}

export interface PaperAttachment {
  id: string;
  name: string;
  type: PaperAttachmentType;
  url: string;
  fileSize?: number | undefined;
  author?: PaperAttachmentAuthor | undefined;
  styleId: string;
  iconId: string;
}

/**
 * 获取附件列表
 * url = /paper/attachments
 * method = GET
 */
export interface GetAttachmentsRequest {
  paperId: string;
}

export interface GetAttachmentsResponse {
  editEnable: boolean;
  maxLength: number;
  attachments: PaperAttachment[];
  maxFileSize: number;
}

/**
 * 添加文件附件
 * url = /paper/attachment/file
 * method = POST
 * 这里前端使用form data，不用json协议
 */
export interface UploadFileAttachmentRequest {
  file: Uint8Array;
  paperId: string;
}

export interface UploadFileAttachmentResponse {
  taskId: string;
}

/**
 * 添加链接附件
 * url = /paper/attachment/link
 * method = POST
 */
export interface UploadLinkAttachmentRequest {
  link: string;
  paperId: string;
  name: string;
}

export interface UploadLinkAttachmentResponse {
  attachment?: PaperAttachment | undefined;
}

/**
 * 附件名称编辑
 * url = /paper/attachment/rename
 * method = PUT
 */
export interface EditAttachmentRequest {
  name: string;
  attachmentId: string;
}

export interface EditAttachmentResponse {
}

/**
 * 附件删除
 * url = /paper/attachment
 * method = DELETE
 */
export interface DeleteAttachmentRequest {
  attachmentId: string;
}

export interface DeleteAttachmentResponse {
}

/**
 * 附件置顶
 * url = /paper/attachment/top
 * method = POST
 */
export interface TopAttachmentRequest {
  attachmentId: string;
}

export interface TopAttachmentResponse {
}

/**
 * 上传状态拉取
 * url = /paper/attachment/status
 * method = GET
 */
export interface GetAttachmentStatusRequest {
  taskId: string;
}

export interface GetAttachmentStatusResponse {
  status: AttachmentStatus;
  /** 仅在status = FAILED时返回 */
  failReason?:
    | string
    | undefined;
  /** 仅在status = FINISH时返回 */
  attachment?: PaperAttachment | undefined;
}

/**
 * 上传状态拉取
 * url = /paper/attachment/task
 * method = DELETE
 */
export interface CancelUploadTaskRequest {
  taskId: string;
}

export interface CancelUploadTaskResponse {
}
