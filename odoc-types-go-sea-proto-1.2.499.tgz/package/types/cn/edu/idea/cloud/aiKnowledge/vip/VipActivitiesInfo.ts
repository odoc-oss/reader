/* eslint-disable */
import type { VipType } from "../../user/VipUserInterface";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.vip";

export enum ActivityStatusEnum {
  WAITING_PUBLISH = 0,
  NOTICING = 1,
  NOTICING_ACTIVITY_IN_EFFECT = 2,
  ACTIVITY_IN_EFFECT = 3,
  WAITING = 4,
  EXPIRED = 5,
  UNRECOGNIZED = -1,
}

export enum ActivityTypeEnum {
  /** DEFAULT_ITEM - 无意义 */
  DEFAULT_ITEM = 0,
  /** UN_LIMIT_POLISH_CARD - 无限润色 */
  UN_LIMIT_POLISH_CARD = 1,
  /** UN_LIMIT_READING_CARD - 无限辅读 */
  UN_LIMIT_READING_CARD = 2,
  /** MAGNIFICATION_AI_BEAN - 3倍AI豆 */
  MAGNIFICATION_AI_BEAN = 3,
  /** HALF_READING_CARD - 半价AI辅读 */
  HALF_READING_CARD = 4,
  /** UN_LIMIT_AI_TRANSLATE - 无限翻译 */
  UN_LIMIT_AI_TRANSLATE = 5,
  UNRECOGNIZED = -1,
}

export enum CapacitySourceType {
  TYPE_FREE = 0,
  TYPE_STANDARD = 1,
  TYPE_PROFESSIONAL = 2,
  TYPE_ENTERPRISE = 3,
  TYPE_RIGHTS_CARD = 4,
  TYPE_OUTSTANDING = 5,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 获取本周累计消费的豆子
 * 	接口url: /vip/activities/getConsumptionBeansOfThisWeek
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetConsumptionBeansOfThisWeekReq {
}

export interface GetConsumptionBeansOfThisWeekResp {
  /** 本周累计消费 */
  consumedBeanCount: number;
  /** 消费和奖励记录 */
  consumeRightsAiBeanInfo: ConsumeRightsAiBeanInfo[];
  /** 发放权益 */
  refundBeanPrivilegeDesc: string[];
  /** 是否展示 */
  isOpen: boolean;
}

export interface ConsumeRightsAiBeanInfo {
  /** 需要消耗的豆子 */
  needConsumeBean: number;
  /** 下一阶梯返回的豆子 */
  rewardBean: number;
}

/**
 * 接口描述: 获无限活动信息(已过时)
 * 	接口url: /vip/activities/getUnlimitedPolishPeriod
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetUnlimitedPolishPeriodReq {
}

export interface GetUnlimitedPolishPeriodResp {
  activites: ActivtiesItem[];
}

/**
 * 接口描述: 获活动信息
 * 	接口url: /vip/activities/getList
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetActivitiesListReq {
}

export interface GetActivitiesListResp {
  activites: ActivtiesItem[];
}

export interface YellowNoticeItem {
  content: string;
  href: string;
}

/**
 * 接口描述: 获小黄条接口
 * 	接口url: /vip/activities/public/getNotices
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetNoticesReq {
}

export interface GetNoticesResp {
  noticeList: YellowNoticeItem[];
}

export interface ActivtiesItem {
  id: string;
  title: string;
  startDate: string;
  endDate: string;
  privilege: string;
  needVipTypes: VipType[];
  description: string;
  /** 活动类型 */
  activityTypeEnum: ActivityTypeEnum;
  /** 是否有效 */
  isValid: boolean;
  /** 是否已领取 */
  isRecivce: boolean;
  /** 是否展示 */
  isOpen: boolean;
  /** 权益卡名称 */
  privilegeCardName: string;
  /** 活动状态 */
  activityStatusEnum: ActivityStatusEnum;
}

/**
 * 接口描述: 领取活动权益
 * 	接口url: /vip/activities/receiveActivityPrivilege
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface ReceiveActivityPrivilegeReq {
  activityId?: string | undefined;
}

export interface ReceiveActivityPrivilegeResp {
}

/**
 * 接口描述: 获取活动权益状态
 * 	接口url: /vip/activities/getActivitiesStatus
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetActivitiesStatusReq {
}

export interface GetActivitiesStatusResp {
  activitiesPrivilegeStatusList: ActivitiesPrivilegeStatus[];
}

export interface ActivitiesPrivilegeStatus {
  activityTypeEnum: ActivityTypeEnum;
  hasActivityPrivilege: boolean;
  privilegeCardName: string;
}

/**
 * 接口描述: 领取无限润色卡（已过时）
 * 	接口url: /vip/activities/receiveUnlimitedPolishCard
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface ReceiveUnlimitedPolishCardReq {
  activityId?: string | undefined;
}

export interface ReceiveUnlimitedPolishCardResp {
}

/**
 * 接口描述: 获取无限润色卡的状态(已过时)
 * 	接口url: /vip/activities/getUnlimitedPolishCardStatus
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetUnlimitedPolishCardStatusReq {
}

export interface GetUnlimitedPolishCardStatusResp {
  hasUnlimitedCard: boolean;
}

/**
 * 接口描述: 文献大咖活动-活跃天数信息
 * 	接口url: /vip/activities/activeDaysInfo
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetActiveDaysInfoReq {
}

export interface GetActiveDaysInfoResp {
  currentWeek?: WeekActiveDaysInfo | undefined;
  lastWeek?:
    | WeekActiveDaysInfo
    | undefined;
  /** 卡容量 */
  rightsCardCapacity: number;
  isDisplay: boolean;
}

export interface WeekActiveDaysInfo {
  /** 累计活跃天数 */
  activeDays: number;
  /** 需要统计的总天数, 目前是5 */
  statDays: number;
  /** 权益卡信息 */
  rightsCardInfos: RightsCardInfo[];
}

export interface RightsCardInfo {
  /** 需要活跃天数 */
  needActiveDays: number;
  /** 是否已领取 */
  isReceived: boolean;
  /** 权益卡id, 未达标时为空 */
  rightsCardId?:
    | string
    | undefined;
  /** 权益天数 */
  days: number;
}

/**
 * 接口描述: 文献大咖活动-领取权益卡
 * 	接口url: /vip/activities/receiveDocRightsCard
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface ReceiveDocRightsCardReq {
  rightsCardId: string;
}

/**
 * 接口描述: 文献大咖活动-文献容量有效期统计
 * 	接口url: /vip/activities/docCapacityValidPeriodStat
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  serviceId: readpaper-pay
 */
export interface GetDocCapacityValidPeriodStatReq {
}

export interface GetDocCapacityValidPeriodStatResp {
  /** 卡容量 */
  rightsCardCapacity: number;
  capacityValidPeriodInfo: DocCapacityValidPeriodInfo[];
}

export interface DocCapacityValidPeriodInfo {
  /** 是否长期有效 */
  isPermanentlyValid: boolean;
  /** 当不是长期有效时才有值 */
  endTime?: string | undefined;
  startTime: string;
  /** 容量组成 */
  capacityComposition: CapacityComposition[];
}

export interface CapacityComposition {
  /** 标准版/权益卡 */
  type: CapacitySourceType;
  /** 容量 */
  capacity: number;
  /** 剩余天数 */
  remainDays: number;
}
