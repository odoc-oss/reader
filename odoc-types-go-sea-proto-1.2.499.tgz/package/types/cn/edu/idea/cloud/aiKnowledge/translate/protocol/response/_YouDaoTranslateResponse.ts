/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate.protocol.response";

/**
 * 接口描述:有道翻译-中文翻译接口出参
 *   接口url:/ts/youdao/zh-cn
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface YouDaoTranslateResponse {
  /** 目标翻译 */
  targetContent: string[];
  /** 网络释义，有道专用，有可能不存在 */
  netWorkContent: YouDaoTranslateNetworkContentResponse[];
}

export interface YouDaoTranslateNetworkContentResponse {
}
