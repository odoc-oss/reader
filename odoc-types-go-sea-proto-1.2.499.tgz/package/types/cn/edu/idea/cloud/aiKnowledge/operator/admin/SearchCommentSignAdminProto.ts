/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.operator.admin.search";

/**
 * 接口描述: 搜索荣誉外显管理-入参
 *   接口url:/admin/operator/searchCommentSign/getById
 *   接口请求方式: POST
 *   参数格式:application/json
 */
export interface SearchCommentSignAdminGetByIdReq {
  id: string;
}

export interface SearchCommentSignAdminGetByIdResp {
  /** 显示标题 */
  title: string;
  /** 显示时长 */
  duration: number;
  /** 跳转链接 */
  targetUrl: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
  /** 发布状态 */
  publishStatus: number;
}

/**
 * 接口描述: 搜索荣誉外显管理-moidfy
 * 	接口url:/admin/operator/searchCommentSign/modify
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SearchCommentSignAdminModifyReq {
  /** id */
  id: string;
  /** 显示标题 */
  title: string;
  /** 显示时长 */
  duration: number;
  /** 跳转url */
  targetUrl: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
}

export interface SearchCommentSignAdminModifyResp {
  /** 数据id */
  id: string;
  /** 显示标题 */
  title: string;
  /** 显示时长 */
  duration: number;
  /** 跳转url */
  targetUrl: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
  /** 发布状态 */
  publishStatus: number;
}

/**
 * 接口描述: 搜索荣誉外显管理-save
 * 	接口url:/admin/operator/searchCommentSign/save
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SearchCommentSignAdminSaveReq {
  /** 显示标题 */
  title: string;
  /** 显示时长 */
  duration: number;
  /** 跳转url */
  targetUrl: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
}

export interface SearchCommentSignAdminSaveResp {
  /** 数据id */
  id: string;
  /** 显示标题 */
  title: string;
  /** 显示时长 */
  duration: number;
  /** 跳转链接 */
  targetUrl: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
  /** 发布状态 */
  publishStatus: number;
}

/**
 * 接口描述: 搜索荣誉外显管理-deleteById
 * 	接口url:/admin/operator/searchCommentSign/deleteById
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SearchCommentSignAdminDeleteByIdReq {
  /** 数据id */
  id: string;
}

export interface SearchCommentSignAdminDeleteByIdResp {
}

/**
 * 接口描述: 搜索荣誉外显管理-list
 * 	接口url:/admin/operator/searchCommentSign/list
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SearchCommentSignAdminListReq {
  /** title */
  title: string;
  publishStatus: number;
  currentPage: number;
  pageSize: number;
}

export interface SearchCommentSignAdminListResp {
  /** total，总页数 */
  total: string;
  /** pageNum，当前页 */
  pageNum: number;
  /** pageSize，每页的数量 */
  pageSize: number;
  /** 列表数据 */
  list: SearchCommentSignItem[];
}

export interface SearchCommentSignItem {
  /** 数据id */
  id: string;
  /** 显示标题 */
  title: string;
  /** 显示时长 */
  duration: number;
  /** 跳转链接 */
  targetUrl: string;
  /** 显示开始时间 */
  startTime: string;
  /** 显示结束时间 */
  endTime: string;
  /** 发布状态 */
  publishStatus: number;
}

/**
 * 接口描述: 搜索荣誉外显管理-sort
 * 	接口url:/admin/operator/searchCommentSign/sort
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SearchCommentSignAdminSortReq {
  /** 数据id */
  id1: string;
  id2: string;
  sort1: number;
  sort2: number;
}

/**
 * 接口描述: 搜索荣誉外显管理-publishAll
 * 	接口url:/admin/operator/searchCommentSign/publishAll
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SearchCommentSignAdminPublishAllReq {
}
