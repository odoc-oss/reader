/* eslint-disable */
import type { TargetResp } from "./IdeaTranslateProto";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate";

/**
 * 接口描述: 查看翻译tab列表
 *  接口url:/aiKnowledge/ts/getTranslateTabList
 *  接口请求方式:get
 *  参数格式:application/json
 *  翻译渠道类型常量: youdao/tencent/idea/baidu/deepl/google
 */
export interface GetTranslateTabListReq {
}

export interface GetTranslateTabListResp {
  /** 翻译渠道类型常量: youdao/tencent/idea/baidu/deepl/google */
  translateType: string[];
}

/**
 * 接口描述:中文翻译接口入参
 *  接口url:/ts/zh-cn
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface TranslateReq {
  /** channel 翻译渠道类型常量, 新增一个渠道: AI翻译="ai" */
  channel: string;
  /** content */
  content: string;
  /** pdfId */
  pdfId?:
    | string
    | undefined;
  /** 是否使用术语库 */
  useGlossary?: boolean | undefined;
}

/**
 * 接口描述:ai翻译-流式接口
 *  接口url:/ts/eureka/completions
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface AiTranslateReq {
  /** content */
  content: string;
  /** pdfId */
  pdfId?:
    | string
    | undefined;
  /** 是否使用术语库 */
  useGlossary?: boolean | undefined;
}

/**
 * 接口描述:ocr-翻译
 *  接口url:/ts/ocr/zh-cn
 *  接口请求方式:POST
 *  参数格式:application/json
 *  响应 TranslateResp
 */
export interface OcrTranslateReq {
  /** 图片base64 */
  picBase64: string;
  /** pdfId */
  pdfId?:
    | string
    | undefined;
  /** channel 翻译渠道类型常量, 新增一个渠道: AI翻译="ai" */
  channel: string;
  /** 是否使用术语库 */
  useGlossary?: boolean | undefined;
}

/**
 * 接口描述:ocr-提取图片文本
 *  接口url:/ts/ocr/extractText
 *  接口请求方式:POST
 *  参数格式:application/json
 *  响应 TranslateResp
 */
export interface OcrExtractTextReq {
  /** 图片base64 */
  picBase64: string;
  /** pdfId */
  pdfId?: string | undefined;
}

/**
 * 接口描述:ocr-剩余次数
 *  接口url:/ts/ocr/remainCount
 *  接口请求方式:POST
 *  参数格式:application/json
 *  响应 TranslateResp
 */
export interface OcrRemainCountReq {
}

export interface OcrRemainCountResponse {
  remainCount: number;
}

export interface OcrExtractTextResponse {
  text: string;
}

export interface TranslateResp {
  /** 目标翻译 */
  targetContent: string[];
  /** requestId */
  requestId?:
    | string
    | undefined;
  /** 英式音标 */
  britishSymbol?:
    | string
    | undefined;
  /** 美式音标 */
  americaSymbol?:
    | string
    | undefined;
  /** 文件格式 */
  britishFormat?:
    | string
    | undefined;
  /** 英式发音 */
  britishPronunciation?:
    | string
    | undefined;
  /** 文件格式 */
  americaFormat?:
    | string
    | undefined;
  /** 美式发音 */
  americaPronunciation?: string | undefined;
  targetResp: TargetResp[];
  /** ocr识别出来的文本 */
  ocrExtractText?:
    | string
    | undefined;
  /** 术语 */
  glossaryList: GlossaryInfo[];
  /** 流式输出数据 */
  sseData?: string | undefined;
}

export interface GlossaryInfo {
  /** 原文 */
  originalText: string;
  /** 译文 */
  translationText: string;
  start: number;
  end: number;
}
