/* eslint-disable */
import type { AnnotateTag, DrawShapeType, Erase, IDEAAnnotateType, Point, ToolType } from "./Common";
import type { AnnotateTextBox } from "./Persistence";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.notev2";

export interface IOSNoteAnnotateContentModel {
  type: IDEAAnnotateType;
  comment?: IOSNoteAnnotateComment | undefined;
  rect?:
    | IOSNoteAnnotateRect
    | undefined;
  /** 当前annotate ID */
  id: string;
  pdfId: string;
  /** annotate page */
  page: string;
  /** 标注创建时间 */
  createDate: string;
  /** 标注所属论文id */
  paperId: string;
  paperTitle: string;
  /** 笔记所属文献名称 */
  docName: string;
  pencil?:
    | IOSNoteAnnotateDraw
    | undefined;
  /** 标签 */
  tags: AnnotateTag[];
  /** 文本框 */
  textBox?:
    | AnnotateTextBox
    | undefined;
  /** 手写笔记，支持增量 */
  draw?:
    | IOSDraw
    | undefined;
  /** 是否为高亮内容 */
  isHighlight?: boolean | undefined;
}

export interface IOSNoteAnnotateComment {
  styleId: number;
  /** markdown string */
  idea: string;
  /** pdf selected text */
  rectStr: string;
  quads: IOSPDFQuad[];
}

export interface IOSNoteAnnotateRect {
  styleId: number;
  /** markdown string */
  idea: string;
  quad?: IOSPDFQuad | undefined;
  picURL: string;
}

export interface IOSNoteAnnotateDraw {
  nsDataUrl: string;
}

export interface IOSPDFQuad {
  ul?: IOSPoint | undefined;
  ll?: IOSPoint | undefined;
  ur?: IOSPoint | undefined;
  lr?:
    | IOSPoint
    | undefined;
  /** 旋转角度 */
  rotation: number;
  pageNumber: number;
}

export interface IOSPoint {
  x: number;
  y: number;
}

/**
 * 获取标签信息
 * url = /pdfMark/v2/ios/saveWithTag
 * method = POST
 */
export interface IOSAddNoteResp {
  markId: string;
  newTags: AnnotateTag[];
  rawContent: string;
}

/**
 * 获取标签信息
 * url = /pdfMark/v2/ios/updateWithTag
 * method = PUT
 */
export interface IOSUpdateNoteResp {
  newTags: AnnotateTag[];
  rawContent: string;
}

/**
 * 根据noteId获取笔记
 * GET /pdfMark/v3/ios/getByNote
 */
export interface IOSNoteAnnotationModelsRequest {
  noteId: string;
}

export interface IOSNoteAnnotationModelsResponse {
  iOSNoteAnnotationModels: IOSNoteAnnotateContentModel[];
}

/**
 * 上传笔触文件
 * POST /pdfMark/v2/ios/note/draw/upload
 */
export interface UploadDrawNote {
  /** 这里实质上是文件类型，pb不好描述 */
  drawNote: string;
}

export interface UploadDrawNoteResponse {
  drawNoteUrl: string;
}

export interface IOSDraw {
  pageNumber: number;
  iosDrawItems: IOSDrawItem[];
}

export interface IOSDrawItem {
  lineHexColor: string;
  lineAlpha: number;
  points: Point[];
  pathTag: number;
  id: string;
  lineWidth: number;
  toolType: ToolType;
  drawShapeType: DrawShapeType;
  erase?: Erase | undefined;
}

export interface IOSDrawItemOfMove {
  id: string;
  points: Point[];
  erase?: Erase | undefined;
}

export interface IOSDrawItemRequest {
  lineHexColor: string;
  lineAlpha: number;
  points: Point[];
  pathTag: number;
  matchId: string;
  lineWidth: number;
  toolType: ToolType;
  drawShapeType: DrawShapeType;
  erase?: Erase | undefined;
}

export interface MatchIdAndDrawId {
  matchId: string;
  id: string;
}

/**
 * 获取标签信息
 * url = /pdfMark/v2/ios/pencil/batch/save
 * method = POST
 */
export interface BatchSaveDrawRequest {
  noteId: string;
  pageNumber: number;
  iosDrawItemRequests: IOSDrawItemRequest[];
}

export interface BatchSaveDrawResponse {
  matchIdAndDrawIds: MatchIdAndDrawId[];
}

/**
 * 获取标签信息
 * url = /pdfMark/v2/ios/pencil/move
 * method = PUT
 * 返回通用状态码
 */
export interface BatchUpdateDrawRequest {
  iosDrawItemsOfMove: IOSDrawItemOfMove[];
}

/**
 * 批量更新id对应的橡皮擦信息
 * url = /pdfMark/v2/ios/pencil/batch/erase
 * method = PUT
 * 返回通用状态码
 */
export interface BatchUpdateEraseRequest {
  idAndErases: IdAndErase[];
}

export interface IdAndErase {
  id: string;
  erase?: Erase | undefined;
}

/**
 * 获取标签信息
 * url = /pdfMark/v2/ios/pencil/batch/delete
 * method = DELETE
 * 返回通用状态码
 */
export interface BatchDeleteDrawRequest {
  id: string[];
}

/**
 * 删除并保存笔画
 * url = /pdfMark/v2/ios/pencil/batch/delete:save
 * method = PUT
 * 返回 BatchSaveDrawResponse
 */
export interface DeleteAndSaveDrawRequest {
  deleteIds: string[];
  batchSaveDrawRequest?: BatchSaveDrawRequest | undefined;
}

/**
 * 查看是否可以禁止展示历史笔记
 * url = /pdfMark/v2/ios/pencil/ifShowHistory
 * method = GET
 */
export interface IfShowBanHistoryDrawButtonRequest {
  noteId: string;
}

export interface IfShowBanHistoryDrawButtonResponse {
  showBanHistoryButton: boolean;
}

/**
 * 禁止展示历史笔记
 * url = /pdfMark/v2/ios/pencil/ifShowHistory
 * method = POST
 * 返回通用的状态码
 */
export interface BanHistoryDrawRequest {
  noteId: string;
}

/**
 * 获取笔触信息
 * url = /pdfMark/v2/ios/pencil/draws
 * method = GET
 * 返回 IOSNoteAnnotateContentModel数组，和/pdfMark/v4/ios/getByNote响应的数据一致，只包括笔触
 * 参数在url上
 */
export interface DrawNoteRequest {
  pageNumbers: number[];
  noteId: string;
  fetchAll: boolean;
}
