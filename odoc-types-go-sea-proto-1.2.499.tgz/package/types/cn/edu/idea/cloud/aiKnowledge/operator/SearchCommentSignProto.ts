/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.operator";

/**
 * 接口描述:搜索荣誉关键字外显-入参
 *   接口url:/aiKnowledge/operator/search/comment/sign
 *   接口请求方式: POST
 *   参数格式:application/json
 */
export interface SearchCommentSignReq {
}

export interface SearchCommentSignResp {
  /** total，总页数 */
  total: string;
  /** pageNum，当前页 */
  pageNum: number;
  /** pageSize，每页的数量 */
  pageSize: number;
  /** 列表数据 */
  list: SearchCommentSignItemResp[];
}

export interface SearchCommentSignItemResp {
  /** 数据id */
  id: string;
  /** 显示标题 */
  title: string;
  /** 显示时长 */
  duration: number;
  /** 跳转url */
  targetUrl: string;
}
