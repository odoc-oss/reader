/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.doc.request";

/**
 * 接口描述:获取用户的文件夹列表
 * 	接口url:/folder/getUserFolderTree
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetUserFolderTreeReq {
}
