/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.operator.admin.msg";

export enum PublishStatusEnum {
  UN_PUBLISHED = 0,
  /** PUBLISHED - 已发布状态的消息，到时间才会被发送 */
  PUBLISHED = 3,
  SENDING = 1,
  SENT_SUCCESS = 2,
  INTERRUPTED = 10,
  UNRECOGNIZED = -1,
}

/** /messageCenter/msgList 新增字段: messageTypeEnum */
export enum MessageTypeEnum {
  UNKNOWN = 0,
  OFFICAL_MESSAGE = 1000,
  SYSTEM_MESSAGE = 2000,
  GROUP_MESSAGE = 3000,
  NONE_GROUP_MESSAGE = 4000,
  ALL_MESSAGE = 5000,
  UNRECOGNIZED = -1,
}

/** 官方消息，目前的样式 */
export enum AllSubMessageTypeEnum {
  /** PLACE_HOLDER - 占位符，为了满足pb协议，无实际业务意义 */
  PLACE_HOLDER = 0,
  OFFICIAL_STYLE_ONE = 4001,
  SYSTEM = 200,
  ACTIVITY = 201,
  TENCENT_QUESTIONNAIRE = 230,
  UNRECOGNIZED = -1,
}

export enum WebsocketSceneName {
  OFFICIAL_MESSAGE = 0,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 运营消息-入参
 *   接口url:/admin/operator/systemMsg/getById
 *   接口请求方式: POST
 *   参数格式:application/json
 */
export interface SystemMsgAdminGetByIdReq {
  id: string;
}

export interface SystemMsgAdminGetByIdResp {
  /** 消息类型  200系统消息，201运营活动消息 230 腾讯问卷 */
  msgType: number;
  /** 标题 */
  title: string;
  /** 描述 */
  description: string;
  /** 链接 */
  msgHref: string;
  /** 号码包地址 */
  msgFileHref: string;
  /** 发布状态  0：待发送，1:发送中，2：发送成功，10：发送中止 */
  publishStatus: PublishStatusEnum;
}

/**
 * 接口描述: 修改运营消息-入参
 *  接口url:/admin/operator/systemMsg/modify
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SystemMsgAdminModifyReq {
  /** id */
  id: string;
  /** 消息类型 */
  msgType: number;
  /** 标题 */
  title: string;
  /** 描述 */
  description: string;
  /** 链接 */
  msgHref: string;
  /** 号码包地址 */
  msgFileHref?: string | undefined;
  startTime?: string | undefined;
  endTime?: string | undefined;
}

export interface SystemMsgAdminModifyResp {
  /** id */
  id: string;
  /** 消息类型 */
  msgType: number;
  /** 标题 */
  title: string;
  /** 描述 */
  description: string;
  /** 号码包地址 */
  msgFileHref: string;
  /** 发布状态  0：待发送，1:发送中，2：发送成功，10：发送中止 */
  publishStatus: PublishStatusEnum;
}

/**
 * 接口描述: 运营消息-save
 * 	接口url:/admin/operator/systemMsg/save
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SystemMsgAdminSaveReq {
  /** 消息类型 */
  msgType: number;
  /** 标题 */
  title: string;
  /** 描述 */
  description: string;
  /** 链接 */
  msgHref: string;
  /** 号码包地址 */
  msgFileHref?: string | undefined;
  startTime?: string | undefined;
  endTime?: string | undefined;
}

export interface SystemMsgAdminSaveResp {
  /** id */
  id: string;
  /** 消息类型 */
  msgType: number;
  /** 显示开始时间 */
  title: string;
  /** 描述 */
  description: string;
  /** 链接 */
  msgHref: string;
  /** 号码包地址 */
  msgFileHref: string;
  /** 发布状态 */
  publishStatus: PublishStatusEnum;
}

/**
 * 接口描述: 运营消息-deleteById
 * 	接口url:/admin/operator/systemMsg/deleteById
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SystemMsgAdminDeleteByIdReq {
  /** 数据id */
  id: string;
}

export interface SystemMsgAdminDeleteByIdResp {
}

/**
 * 接口描述: 运营消息-list
 * 	接口url:/admin/operator/systemMsg/list
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SystemMsgAdminListReq {
  /** title */
  title: string;
  /** publishStatus */
  publishStatus: PublishStatusEnum;
  currentPage: number;
  pageSize: number;
}

export interface SystemMsgAdminListResp {
  /** total，总页数 */
  total: string;
  /** pageNum，当前页 */
  pageNum: number;
  /** pageSize，每页的数量 */
  pageSize: number;
  /** 列表数据 */
  list: SystemMsgItem[];
}

export interface SystemMsgItem {
  /** id */
  id: string;
  /** 消息类型 */
  msgType: number;
  /** 标题 */
  title: string;
  /** 描述 */
  description: string;
  /** 链接 */
  msgHref: string;
  /** 号码包地址 */
  msgFileHref: string;
  /** 发布状态 */
  publishStatus: PublishStatusEnum;
  startTime?: string | undefined;
  endTime?: string | undefined;
}

/**
 * 接口描述: 运营消息-发送
 * 	接口url:/admin/operator/systemMsg/publish
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SystemMsgPublishReq {
  /** id */
  id: string;
}

/**
 * 接口描述: 运营消息-查看发送状态
 * 	接口url:/admin/operator/systemMsg/publishStatus
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SystemMsgPublishStatusReq {
  /** id */
  id: string;
}

export interface SystemMsgPublishStatusResp {
  /** 为true，表示在发送中，为false，表示已发送完成 */
  status: boolean;
}

/**
 * 接口描述: 运营消息-测试发送
 * 	接口url:/admin/operator/systemMsg/testPublish
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SystemMsgTestPublishReq {
  /** id */
  id: string;
  /** 用户ids */
  userIds: string;
}

/**
 * 接口描述: 运营消息-中止
 * 	接口url:/admin/operator/systemMsg/stop
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface SystemMsgStopReq {
  /** id */
  id: string;
}

/** websocket: 官方消息推送 */
export interface PopupMessage {
  /** 使用下面枚举OFFICIAL_MESSAGE字符串名称 */
  scene: string;
  officialMessage?: OfficialMessage | undefined;
}

export interface OfficialMessage {
  description: string;
  link: string;
  messageId: string;
}

/** websocket: 消息数量推送 */
export interface CountOfMessage {
  scene: string;
  content: number;
  detailMessageCounts: DetailMessageCount[];
}

export interface DetailMessageCount {
  messageTypeEnum: MessageTypeEnum;
  count: number;
}

/**
 * 接口描述: 拉取未能成功推送的弹窗
 * 	接口url:/messageCenter/popup/undelivered
 * 	接口请求方式:GET
 *  返回PopupMessage
 */
export interface GetPopupMessageResponse {
  popupMessages: PopupMessage[];
}

/**
 * 接口描述: 标注消息已经弹出
 * 	接口url:/messageCenter/popup/poped
 * 	接口请求方式:PUT
 *  返回通用状态码
 */
export interface MarkMessagePopedRequest {
  messageIds: string[];
}

/**
 * 接口描述: 按类型标记消息为全部已读
 * 	接口url:/messageCenter/mark/all/read
 * 	接口请求方式:PUT
 *  返回通用状态码
 */
export interface MarkMessageReadRequest {
  messageTypeEnum: MessageTypeEnum;
}
