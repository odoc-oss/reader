/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.admin.protocol";

/**
 * 接口描述:作者认证管理端协议-删除
 * 	接口url:/admin/authorAuthentication/deleteById
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface AuthorDeleteByIdRequest {
  /** id */
  id: string;
}

export interface AuthorDeleteByIdResponse {
  /** 数据id */
  id: string;
}
