/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.seo";

/** seo类型 */
export enum SeoPageType {
  /** HOME - 首页 */
  HOME = 0,
  /** SEARCH - 搜索页 */
  SEARCH = 1,
  /** PAPER_DETAIL - 论文详情页 */
  PAPER_DETAIL = 2,
  /** FOS_DETAIL - fos详情页 */
  FOS_DETAIL = 3,
  /** AUTHOR_DETAIL - 作者详情页 */
  AUTHOR_DETAIL = 4,
  /** OPERATOR - 运营页 */
  OPERATOR = 5,
  UNRECOGNIZED = -1,
}

export interface TdkConfig {
  /** 主键 */
  id?:
    | string
    | undefined;
  /** seo页面类型 */
  seoType: SeoPageType;
  /** 标题模板 */
  titleTemplate: string;
  /** keywords模板 */
  keywordsTemplate: string;
  /** desciprtion模板 */
  descriptionTemplate: string;
  /** 发布状态 0表示未发布，1表示已发布，4表示已下架 */
  publishStatus: number;
}
