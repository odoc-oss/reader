/* eslint-disable */
import type { ShapeAnnotation } from "./Common";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.notev2";

/**
 * 接口描述: 保存
 * 	接口url:/noteShape/save
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface SaveShapeReq {
  noteId: string;
  shapeAnnotation?: ShapeAnnotation | undefined;
}

export interface SaveShapeResponse {
  shapeId: string;
}

/**
 * 接口描述: 更新
 * 	接口url:/noteShape/update
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface UpdateShapeReq {
  annotations: ShapeAnnotation[];
}

/**
 * 接口描述: 删除
 * 	接口url:/noteShape/delete
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface DeleteShapeReq {
  shapeIds: string[];
}

/**
 * 接口描述: 列表
 * 	接口url:/noteShape/getList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetShapeListReq {
  noteId: string;
}

export interface GetShapeListResponse {
  list: ShapeAnnotation[];
}
