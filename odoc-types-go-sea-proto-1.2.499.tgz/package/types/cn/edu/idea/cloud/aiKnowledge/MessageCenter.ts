/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/**
 * 是否展示VIP调整内容
 *  url: /isDisplayVipAdjustContent
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface IsDisplayVipAdjustContentReq {
}

export interface IsDisplayVipAdjustContentResponse {
  /** true= 展示 */
  isDisplay: boolean;
}
