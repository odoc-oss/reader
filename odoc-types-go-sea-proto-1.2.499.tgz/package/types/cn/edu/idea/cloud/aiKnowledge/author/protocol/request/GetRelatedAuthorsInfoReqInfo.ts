/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.protocol.request";

/**
 * 接口描述:获取相关的作者期刊信息
 * 	接口url:/aiKnowledge/author/getRelatedAuthorsAndVenuesInfo
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetRelatedAuthorsAndVenuesInfoReq {
  /** 作者id */
  authorId: string;
}

export interface GetRelatedAuthorsAndVenuesInfoResponse {
  /** 作者信息 */
  authorInfos: AuthorInfo[];
  /** 会议期刊 */
  venuesInfos: VenuesInfo[];
}

export interface VenuesInfo {
  /** id */
  id: string;
  /** 名称 */
  name: string;
}

export interface AuthorInfo {
  /** id */
  id: string;
  /** 名称 */
  name: string;
}
