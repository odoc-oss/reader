/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.doc";

export interface DocFolder {
  id: string;
  path: string;
}
