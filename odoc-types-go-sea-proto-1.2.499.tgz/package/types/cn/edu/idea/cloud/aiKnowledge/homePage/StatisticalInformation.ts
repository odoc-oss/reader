/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.homePage";

/**
 * 接口描述: 获取我的统计信息-登录后获取
 * 	接口url: /personal/userCenter/getMyStatistical
 * 	接口请求方式: GET
 */
export interface GetMyStatisticalReq {
}

export interface GetMyStatisticalReps {
  /** 最近阅读 */
  myLatestRead?:
    | MyLatestRead
    | undefined;
  /** 我的收藏数量 */
  myCollectionCount: number;
  /** 我的笔记数量 */
  myNoteCount: number;
  /** 我的小组数量 */
  myGroupCount: number;
  /** 我的活跃天数 */
  myActiveDays: number;
  /** 我的小组列表 */
  myGroupList: MyGroup[];
}

export interface MyLatestRead {
  paperId: string;
  docName: string;
  pdfId: string;
}

export interface MyGroup {
  goupId: string;
  groupName: string;
}
