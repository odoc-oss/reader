/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/** 0=web活动banner,1=小程序活动banner */
export enum BannerType {
  /** WEB - web活动banner */
  WEB = 0,
  /** MINI_APP - 小程序活动banner */
  MINI_APP = 1,
  UNRECOGNIZED = -1,
}

/**
 * console管理后台-获取banner列表
 * url: /microService-app-aiKnowledge/activityBannerManage/list
 */
export interface AdminListReq {
  /** banner类型 */
  type?:
    | BannerType
    | undefined;
  /** banner标题 */
  title?: string | undefined;
}

export interface AdminListResponse {
  total: string;
  bannerInfos: BannerInfo[];
}

export interface BannerInfo {
  /** banner标题 */
  title: string;
  /** banner图片url */
  picUrl: string;
  /** 跳转链接 */
  jumpUrl: string;
  /** banner 主题色 */
  themeColor: string;
  /** 活动开始时间 */
  startTime: string;
  /** 结束时间 */
  endTime: string;
  /** 排序 */
  sort: number;
  /** banner id */
  id: string;
}

/**
 * web/小程序-获取banner列表
 * url: /microService-app-aiKnowledge/aiKnowledge/banner/list
 */
export interface BannerListReq {
  /** banner类型 */
  type?: BannerType | undefined;
  currentPage: number;
  pageSize: number;
}

export interface BannerListResponse {
  total: string;
  list: BannerInfo[];
}

/**
 * 全量发布活动banner
 * url: /microService-app-aiKnowledge/activityBannerManage/publishAll
 */
export interface PublishAllBannerReq {
  /** bannerId */
  type?: BannerType | undefined;
}

/**
 * 活动banner上移下移
 * url: /microService-app-aiKnowledge/activityBannerManage/changeSort
 */
export interface BannerChangeSortReq {
  id1: string;
  sort1: number;
  id2: string;
  sort2: string;
}

/**
 * 删除活动banner
 * url: /microService-app-aiKnowledge/activityBannerManage/delete
 */
export interface DeleteBannerReq {
  /** bannerId */
  bannerId: string;
}

/**
 * 保存活动banner
 * url: /microService-app-aiKnowledge/activityBannerManage/save
 */
export interface SaveBannerReq {
  /** banner标题 */
  title: string;
  /** banner图片url */
  picUrl: string;
  /** 跳转链接 */
  jumpUrl: string;
  /** banner 主题色 */
  themeColor: string;
  /** 活动开始时间 */
  startTime: string;
  /** 结束时间 */
  endTime: string;
  /** 排序 */
  sort: number;
  /** banner 类型 */
  type: BannerType;
}

/**
 * 更新活动banner
 * url: /microService-app-aiKnowledge/activityBannerManage/update
 */
export interface UpdateBannerReq {
  /** banner标题 */
  title: string;
  /** banner图片url */
  picUrl: string;
  /** 跳转链接 */
  jumpUrl: string;
  /** banner 主题色 */
  themeColor: string;
  /** 活动开始时间 */
  startTime: string;
  /** 结束时间 */
  endTime: string;
  /** 排序 */
  sort: number;
  /** banner id */
  id: string;
}
