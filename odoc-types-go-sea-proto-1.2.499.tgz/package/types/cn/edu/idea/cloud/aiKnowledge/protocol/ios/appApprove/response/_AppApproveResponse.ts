/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.protocol.ios.appApprove.response";

/**
 * 接口描述:保存ios app审核配置
 * 	接口url:/aiKnowledge/ipad/getStatusByVersion
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface AppApproveResponse {
  /** id */
  id: string;
  /** 版本信息 */
  version: string;
  /** app store 审核状态 */
  appStoreStatus: string;
}

/**
 * 接口描述:通过版本获取IpadJsContent
 * 	接口url:/aiKnowledge/ipad/getJsContentByVersion?version=
 * 	接口请求方式:GET
 */
export interface GetJsContentByVersionResponse {
  status: number;
  /** JsContent */
  data: string;
}
