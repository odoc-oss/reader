/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/**
 * 接口描述: 获取阅读时长统计
 * 	接口url: /reading/time/statistics
 * 	接口请求方式: get
 * 	参数格式:application/json
 *  serviceId:aiKnowledge
 */
export interface ReadingTimeResponse {
  readingTimeStatisticsList: ReadingTimeStatistics[];
}

export interface ReadingTimeStatistics {
  year: number;
  readingTimeByMonthList: ReadingTimeStatisticsMonth[];
}

export interface ReadingTimeStatisticsMonth {
  /** 1 - 12 */
  month: number;
  readingTimeStatisticsUnitList: ReadingTimeStatisticsUnit[];
}

export interface ReadingTimeStatisticsUnit {
  /** 1 - 31 */
  dayOfMonth: number;
  readingTimeByMinutes: number;
}

/**
 * 接口描述: 获取海报
 * 	接口url: /reading/last/week/summary/poster
 * 	接口请求方式: get
 * 	参数格式:application/json,返回图片的base64格式
 *  serviceId:aiKnowledge
 */
export interface LastWeekReadingSummaryPosterResponse {
  poster: string;
}
