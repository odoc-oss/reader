/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.admin.protocol";

/**
 * 接口描述:作者认证管理端协议-list-paging
 * 	接口url:/admin/authorAuthentication/list
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface AuthorPageRequest {
  /** userId */
  userId: string;
  /** authorId */
  authorId: string;
  /** authorName */
  authorName: string;
  /** description */
  description: string;
  /** publishStatus */
  publishStatus: number;
  currentPage: number;
  pageSize: number;
}

export interface AuthorPageResponse {
  /** 数据id */
  id: string;
  /** userId */
  userId: string;
  /** authorId */
  authorId: string;
  /** authorName */
  authorName: string;
  /** description */
  description: string;
}
