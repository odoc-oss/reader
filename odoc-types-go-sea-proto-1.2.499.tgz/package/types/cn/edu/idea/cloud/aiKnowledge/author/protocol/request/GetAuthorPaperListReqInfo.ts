/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.protocol.request";

/**
 * 接口描述:获取作者的论文数据
 * 	接口url:/aiKnowledge/author/getPaperList
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface GetAuthorPaperListReq {
  /** 开始年份 */
  startYear?:
    | number
    | undefined;
  /** 结束年份 */
  endYear?:
    | number
    | undefined;
  /** 会议期刊id */
  venues: string[];
  /** 作者id */
  authors: string[];
  /** 排序方式,最近=newest、最早=earliest、引用最多=maxcc */
  sortType: string;
  currentPage: number;
  pageSize: number;
  /** 作者id */
  authorId: string;
}

export interface GetAuthorPaperListResponse {
  /** 论文列表 */
  paperList: AuthorPaperListInfo[];
}

export interface AuthorPaperListInfo {
  /** 论文id */
  paperId: string;
  /** 论文标题 */
  title: string;
  /** 发布时间 */
  publishDate: string;
  /** 原文摘要 */
  originalAbstract: string;
  /** 引用数 */
  referenceCount: number;
  /** 被引用数 */
  citationCount: number;
  primaryVenue: string;
  /** 笔记数 */
  noteCount: number;
  /** 收藏数 */
  collectCount: number;
  /** 是否有pdf */
  hasPdf: boolean;
  authorList: PaperAuthorInfo[];
}

export interface PaperAuthorInfo {
  id: string;
  name: string;
}
