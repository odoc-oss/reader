/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.admin.protocol";

/**
 * 接口描述:作者认证管理端协议-moidfy
 * 	接口url:/admin/authorAuthentication/modify
 * 	接口请求方式:POST
 * 	参数格式:application/json
 */
export interface AuthorModifyRequest {
  /** id */
  id: string;
  /** userId */
  userId: string;
  /** authorId */
  authorId: string;
  /** description */
  description: string;
}

export interface AuthorModifyResponse {
  /** 数据id */
  id: string;
  /** userId */
  userId: string;
  /** authorId */
  authorId: string;
  /** authorName */
  authorName: string;
  /** description */
  description: string;
  /** publishStatus */
  publishStatus: number;
}
