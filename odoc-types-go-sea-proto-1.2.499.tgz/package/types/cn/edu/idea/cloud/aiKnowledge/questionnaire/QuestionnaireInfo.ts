/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.questionnaire";

/**
 * 接口描述:获取来源列表
 * 	接口url:/aiKnowledge/questionnaire/getQuestionnaireSourceListReq
 * 	接口请求方式: GET
 * 	参数格式:application/json
 *  serviceId: microService-app-aiKnowledge
 */
export interface GetQuestionnaireSourceListReq {
}

export interface GetQuestionnaireSourceListResp {
  /** 本次调查问卷的赠送vip天数 */
  vipDays: number;
  /** 填写来源 */
  sourceList: string[];
}

/**
 * 接口描述:点击来源，报送信息
 * 	接口url:/aiKnowledge/questionnaire/addQuestionnaireSource
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  serviceId: microService-app-aiKnowledge
 */
export interface AddQuestionnaireSourceReq {
  /** 用户id->questionnaireUserId */
  uid: string;
  /** 来源 */
  source: string;
  /** token->questionnaireToken */
  token: string;
}

export interface AddQuestionnaireSourceResp {
}
