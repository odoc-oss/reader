/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.author.admin.protocol";
