/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge";

/**
 * 删除活动
 * url: /pastClassicActivityManage/delete
 */
export interface DeletePastClassicActivityReq {
  activityId: string;
}
