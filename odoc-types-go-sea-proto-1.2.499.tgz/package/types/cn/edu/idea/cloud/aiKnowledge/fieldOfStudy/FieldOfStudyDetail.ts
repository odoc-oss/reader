/* eslint-disable */
import type { PlatformRoleEnum } from "../../common/Role";
import type { SceneEnum } from "../comment/Comment";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.fieldOfStudy";

export enum AdministratorEnum {
  SUBSJECT_REPRESENTATIVE = 0,
  MAINTAINER = 1,
  COMMON_USER = 3,
  UNRECOGNIZED = -1,
}

export enum MaintainerStatusEnum {
  NORMAL = 0,
  AUTO_DISMISSING = 1,
  DISMISSING = 2,
  UNRECOGNIZED = -1,
}

export enum RelatedPaperSortType {
  DEFAULT_SORT_TYPE = 0,
  PUBLISH_TIME_ASEC = 1,
  PUBLISH_TIME_DESC = 2,
  CITATION_COUNT_DESC = 3,
  UNRECOGNIZED = -1,
}

/**
 * url: /fos/aggregation
 *  method: GET
 */
export interface FetchFOSDetailRequest {
  fosId: string;
}

export interface FetchFOSDetailResponse {
  fosDetail?: FOSDetail | undefined;
  importantScholars: ImportantScholar[];
  fosAdministrators: FOSAdministrator[];
}

export interface FOSDetail {
  fosTitle: string;
  relatedFOS: FOS[];
  description: string;
  isSubscribed: boolean;
  subscribedCount: number;
}

export interface FOS {
  fosTitle: string;
  id: string;
}

export interface ImportantScholar {
  name: string;
  publishedPaperCount: number;
  referencedCount: string;
  id: string;
  isSettledAuthor: boolean;
  userId?: string | undefined;
}

export interface FOSAdministrator {
  id: string;
  nickName: string;
  avatarUrl: string;
  isFollowed: boolean;
  role: AdministratorEnum;
  lastLoginTimeByDay: number;
}

/**
 * url: /fos/role
 *  method: GET
 */
export interface FOSRoleRequest {
  fosId: string;
}

export interface FOSRoleRespnse {
  role: AdministratorEnum;
  platformRoles: PlatformRoleEnum[];
}

/**
 * url: /fos/subscribe
 *  method: POST
 *  返回通用的状态码
 */
export interface FOSSubscribeRequest {
  fosId: string;
}

/**
 * url: /fos/unsubscribe
 *  method: PUT
 *  返回通用的状态码
 */
export interface FOSUnsubscribeRequest {
  fosId: string;
}

/**
 * url: /fos/maintainer:add
 *  method: POST
 *  返回通用的状态码
 */
export interface FOSAddMaintainerRequest {
  fosId: string;
  userIdToAdd: string;
}

/**
 * url: /fos/maintainer:cancel
 *  method: PUT
 *  返回通用的状态码
 */
export interface FOSCancelMaintainerRequest {
  fosId: string;
  userIdToCancel: string;
}

/**
 * url: /admin/resource/maintainer:add
 *  method: POST
 *  返回通用的状态码
 */
export interface AdminResourceAddRoleRequest {
  resourceId: string;
  userIdToAdd: string;
  role: AdministratorEnum;
  sceneEnum: SceneEnum;
}

/**
 * url: /admin/resource/maintainer:cancel
 *  method: PUT
 *  返回通用的状态码
 */
export interface AdminResourceCancelRoleRequest {
  resourceId: string;
  userIdToCancel: string;
  role: AdministratorEnum;
  sceneEnum: SceneEnum;
}

/**
 * url: /admin/resource/maintainer:reappoint
 *  method: PUT
 *  返回通用的状态码
 */
export interface AdminResourceReappointRoleRequest {
  resourceId: string;
  userIdToReappoint: string;
  role: AdministratorEnum;
  sceneEnum: SceneEnum;
}

/**
 * url: /admin/resource/maintainer:list
 *  method: GET
 */
export interface FetchAdminFOSMaintainersRequest {
  resourceId?: string | undefined;
  userId?: string | undefined;
  pageNumber: number;
  pageSize: number;
}

export interface FetchAdminFOSMaintainersResponse {
  maintainers: Maintainer[];
  totalSize: number;
}

export interface Maintainer {
  userName: string;
  role: AdministratorEnum;
  maintainerStatusEnum: MaintainerStatusEnum;
  resourceId: string;
  sceneEnum: SceneEnum;
  userId: string;
}

/**
 * url: /fos/related/papers
 *  method: GET
 */
export interface FOSRelatedPapersRequest {
  relatedPaperSortType: RelatedPaperSortType;
  pageSize: number;
  pageNumber: number;
  startYear?: number | undefined;
  endYear?: number | undefined;
  fosId: string;
  /** 为空就传空数组 */
  venueId: string[];
}

export interface FOSRelatedPapersResponse {
  /** 空数组表示没有更多数据了 */
  paperDetails: RelatedPaperDetail[];
}

export interface RelatedPaperDetail {
  relatedPaperTitle: string;
  relatedPaperId: string;
  authors: string[];
  /** 主要期刊 */
  primaryVenue: string;
  venueTags: string[];
  /** yyyy-MM-dd */
  publishDate: string;
  citationCount: number;
  collectedCount: number;
  noteCount: number;
  pdfId: string;
  abstracts: string;
}

/**
 * url: /fos/query/queryVenuesByFosId
 *  method: GET
 */
export interface FetchVenuesRequest {
  id: string;
}

export interface FetchVenuesResponse {
  venues: Venue[];
}

export interface Venue {
  id: string;
  name: string;
}
