/* eslint-disable */
import type { SeoPageType } from "./SEOCommon";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.seo";

/**
 * 接口描述: 首页获取信息流-不需要登录
 * 	接口url: /aiKnowledge/seo/getTDK
 * 	接口请求方式: GET
 */
export interface GetTDKReq {
  type: SeoPageType;
}

export interface GetTDKResp {
  /** 标题模板 */
  titleTemplate: string;
  /** keywords模板 */
  keywordsTemplate: string;
  /** desciprtion模板 */
  descriptionTemplate: string;
}
