/* eslint-disable */
import type { UserInfoBean } from "../../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.learntask";

/**
 * 接口描述:置顶翻译
 * 	接口url:/translate/setTop
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface TranslationSetTopReq {
  /** 翻译id */
  translationId: string;
}

/**
 * 接口描述:取消翻译置顶
 * 	接口url:/translate/cancelSetTop
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface CancelTranslationSetTopReq {
  /** 翻译id */
  translationId: string;
}

/**
 * 接口描述:点赞/认同翻译
 * 	接口url:/translate/like
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface TranslationLikeReq {
  /** 翻译id */
  translationId: string;
}

/**
 * 接口描述:取消翻译点赞/认同
 * 	接口url:/translate/cancelLike
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface CancelTranslationLikeReq {
  /** 翻译id */
  translationId: string;
}

/**
 * 接口描述:翻译list
 * 	接口url:/aiKnowledge/translate/list
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface TranslationListReq {
  /** paperId */
  paperId: string;
  /** 排序方式,0=默认排序,1=最受认同,2=最新 */
  sortType: number;
  pageSize: number;
  currentPage: number;
}

export interface TranslationListResponse {
  /** 论文标题 */
  paperTitle: string;
  /** 论文摘要 */
  paperAbstract: string;
  /** 翻译总数 */
  total: number;
  /** 翻译列表 */
  translationList: TranslationInfo[];
  /** 我的翻译信息 */
  myTranslationInfo?: TranslationInfo | undefined;
}

export interface TranslationInfo {
  /** 翻译者信息 */
  ownerInfo?:
    | UserInfoBean
    | undefined;
  /** 是否已经点赞/认同 */
  likeFlag: boolean;
  /** 翻译时间 */
  createDate: string;
  /** 翻译内容 */
  translation: string;
  /** 是否已经置顶 */
  topFlag: boolean;
  translationId: string;
  /** 点赞/认同数 */
  likeCount: number;
}
