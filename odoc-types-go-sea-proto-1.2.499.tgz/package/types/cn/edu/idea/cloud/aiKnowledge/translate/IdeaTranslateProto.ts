/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate";

/**
 * 接口描述:idea渠道-中文翻译接口入参
 *   接口url:/ts/idea/zh-cn
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface IdeaTranslateReq {
  /** content */
  content: string;
  /** pdfId */
  pdfId?: string | undefined;
}

export interface IdeaTranslateResp {
  /** targetContent */
  targetContent?:
    | string
    | undefined;
  /** requestId */
  requestId: string;
  /** 英式音标 */
  britishSymbol?:
    | string
    | undefined;
  /** 美式音标 */
  americaSymbol?:
    | string
    | undefined;
  /** 英式发音 */
  britishPronunciation?:
    | string
    | undefined;
  /** 美式发音 */
  americaPronunciation?: string | undefined;
  targetResp: TargetResp[];
}

export interface TargetResp {
  /** 词性 */
  part: string;
  /** 译文 */
  targetContent: string[];
}
