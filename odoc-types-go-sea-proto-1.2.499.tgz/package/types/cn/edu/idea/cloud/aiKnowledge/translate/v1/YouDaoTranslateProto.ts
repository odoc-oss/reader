/* eslint-disable */
import type { TargetResp } from "../IdeaTranslateProto";

export const protobufPackage = "cn.edu.idea.cloud.aiKnowledge.translate.v1";

/**
 * 接口描述:中文翻译接口入参
 *   接口url:/ts/v1/youdao/zh-cn
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface YoudaoTranslateReq {
  /** content */
  content: string;
  /** pdfId */
  pdfId?:
    | string
    | undefined;
  /** 是否使用术语库 */
  useGlossary?: boolean | undefined;
}

export interface YouDaoTranslateResp {
  /** 目标翻译 */
  targetContent: string[];
  /** 网络释义，有道专用，有可能不存在 */
  netWorkContent: YouDaoTranslateNetworkContentResp[];
  /** 英式音标 */
  britishSymbol?:
    | string
    | undefined;
  /** 美式音标 */
  americaSymbol?:
    | string
    | undefined;
  /** 文件格式 */
  britishFormat?:
    | string
    | undefined;
  /** 英式发音 */
  britishPronunciation?:
    | string
    | undefined;
  /** 文件格式 */
  americaFormat?:
    | string
    | undefined;
  /** 美式发音 */
  americaPronunciation?: string | undefined;
  targetResp: TargetResp[];
  /** requestId */
  requestId: string;
}

export interface YouDaoTranslateNetworkContentResp {
  list: string[];
}
