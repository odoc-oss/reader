/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.oss";

export enum QiNiuUploadBizScene {
  /** CND - cdn */
  CND = 0,
  /** QN_PDF - 七牛PDF */
  QN_PDF = 1,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 获取上传到七牛OSS所需的上传凭证
 * 	接口url:/microservice-oss/public/oss/qiNiu/upload/getSimpleUploadToken
 * 	接口请求方式: POST
 */
export interface GetSimpleUploadTokenReq {
  scene: QiNiuUploadBizScene;
  fileName: string;
}

export interface GetSimpleUploadTokenResponse {
  uploadToken: string;
}
