/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.oss";

export enum UploadBizScene {
  /** PERSONAL_INFO - 个人信息 */
  PERSONAL_INFO = 0,
  /** PDF - PDF */
  PDF = 1,
  /** DOC_ATTACHMENT - 文件附件 */
  DOC_ATTACHMENT = 2,
  /** AI_POLISH - ai-polish的上传目录 */
  AI_POLISH = 3,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 获取上传到阿里云OSS所需的policy和Callback等信息
 * 	接口url:/microservice-oss/oss/upload/acquirePolicyCallbackInfo
 * 	接口请求方式: GET
 */
export interface AcquirePolicyCallbackInfoReq {
  scene?: UploadBizScene | undefined;
  md5?: string | undefined;
}

export interface AcquirePolicyCallbackInfoResponse {
  accessid: string;
  callback: string;
  dir: string;
  expire: string;
  host: string;
  policy: string;
  signature: string;
  /** 是否需要上传,true=需要 */
  isNeedUpload: boolean;
  objectStoreInfo?:
    | ObjectStoreInfo
    | undefined;
  /** 是否需要设置http头Content-Disposition:attachment */
  isNeedAttachmentHeader?: boolean | undefined;
}

export interface ObjectStoreInfo {
  bucketName?: string | undefined;
  objectName?: string | undefined;
}
