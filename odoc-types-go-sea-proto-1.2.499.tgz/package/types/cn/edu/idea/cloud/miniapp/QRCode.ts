/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.miniapp";

/**
 * 接口描述: 获取小程序码
 * 	接口url: /micro-miniapp-base-svr/qrcode
 * 	接口请求方式: GET
 */
export interface GetQRCodeRequest {
  path: string;
  scene: string;
  width: number;
}

export interface GetQRCodeResponse {
  url: string;
}
