/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.miniapp";

/**
 * 接口描述:获取用户已订阅的领域列表
 * 	接口url:/micro-miniapp-base-svr/getUserSubscribedDomainList
 * 	接口请求方式: GET
 */
export interface GetUserSubscribedDomainListReq {
}

export interface GetUserSubscribedDomainListResponse {
  domainList: DomainInfo[];
}

/**
 * 接口描述:获取推荐的Arxiv最新论文列表
 * 	接口url:/micro-miniapp-base-svr/arxiv/getPaperList
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface GetPaperListReq {
  pageSize: number;
  pageIndex?: string | undefined;
}

export interface GetPaperListResponse {
  /** 是否有下一页 */
  hasNextPage: boolean;
  paperList: IndexPaperInfo[];
  nextPageIndex: string;
}

export interface IndexPaperInfo {
  /** 论文id */
  paperId: string;
  /** 论文标题 */
  title: string;
  /** 作者 */
  authorList: PaperAuthorInfo[];
  /** 摘要 */
  abstracts: string;
  /** 论文被记录的时间（unix时间戳） */
  recordDateTimeUnix: string;
}

export interface PaperAuthorInfo {
  id: string;
  name: string;
}

/**
 * 接口描述:订阅领域
 * 	接口url:/micro-miniapp-base-svr/subscribeDomain
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface SubscribeDomainReq {
  /** 领域id列表 */
  ids: string[];
}

/**
 * 接口描述:获取用户订阅数/收藏数等统计信息
 * 	接口url:/micro-miniapp-base-svr/getUserStatInfo
 * 	接口请求方式: GET
 */
export interface GetUserStatInfoReq {
}

export interface GetUserStatInfoResponse {
  /** 订阅数 */
  subscribeCount: number;
  /** 收藏数 */
  collectionCount: number;
}

export interface DomainInfo {
  id: string;
  name: string;
  isSubscribed: boolean;
}
