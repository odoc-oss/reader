/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.miniapp";

export interface NerdQuestion {
  id: string;
  content: string;
  opts: NerdAnswer[];
}

export interface NerdAnswer {
  code: string;
  content: string;
}

export interface NerdTestRecord {
  id: string;
  content: string;
  opts: NerdAnswer[];
  answer?: NerdAnswer | undefined;
  isCorrect: boolean;
}

export interface QuestionList {
  questionListId: string;
  questions: NerdQuestion[];
}

export interface RankerUnit {
  seq: number;
  avatarUrl: string;
  name: string;
  score: number;
  costTime: string;
}

export interface RankerInfo {
  rankerId: string;
  selfUnit?: RankerUnit | undefined;
  allUnits: RankerUnit[];
  score: number;
  costTime: string;
  defeatPercentage: number;
  selfQuestionListId: string;
  isSelfRanker: boolean;
}

/**
 * 接口描述: 获取学霸问卷
 * 	接口url: /micro-miniapp-base-svr/activities/nerd/questions
 * 	接口请求方式: GET
 *  若用户当前已没有答词次数可用，直接返回排行榜信息（questionList非空，ranker为空）
 *  否则反之。
 */
export interface GetNerdQuestionsRequest {
  rankerId?: string | undefined;
  sharerId?: string | undefined;
}

export interface GetNerdQuestionsResponse {
  questionList?:
    | QuestionList
    | undefined;
  /** questionList */
  ranker?: RankerInfo | undefined;
}

/**
 * 接口描述: 提交学霸问卷
 * 	接口url: /micro-miniapp-base-svr/activities/nerd/submit
 * 	接口请求方式: POST
 */
export interface SubmitNerdQuestionsRequest {
  questionListId: string;
  codes: string[];
  /** 答题耗时，单位秒 */
  costTime: string;
}

export interface SubmitNerdQuestionsResponse {
  ranker?: RankerInfo | undefined;
}

/**
 * 接口描述: 获取学霸答题记录
 * 	接口url: /micro-miniapp-base-svr/activities/nerd/record
 * 	接口请求方式: GET
 */
export interface GetNerdRecordRequest {
  rankerId?: string | undefined;
}

export interface GetNerdRecordResponse {
  questionListId: string;
  score: number;
  costTime: string;
  /** 打败用户比例 */
  defeatPercentage: number;
  questions: NerdTestRecord[];
}

/**
 * 接口描述: 分享答题，获取答题次数
 * 	接口url: /micro-miniapp-base-svr/activities/nerd/share
 * 	接口请求方式: PUT
 */
export interface ShareNerdTestRequest {
  questionListId: string;
  originSharerId: string;
}

export interface ShareNerdTestResponse {
}

/**
 * 接口描述: 分享答题，获取答题次数
 * 	接口url: /micro-miniapp-base-svr/activities/nerd/decodeScene
 * 	接口请求方式: GET
 */
export interface DecodeSceneRequest {
  shortScene: string;
}

export interface DecodeSceneResponse {
  originScene: string;
}

/**
 * 接口描述: 分享答题，获取答题次数
 * 	接口url: /micro-miniapp-base-svr/activities/nerd/globalRanker
 * 	接口请求方式: GET
 */
export interface GetGlobalRankerRequest {
  /** 翻页字段，传入上一次回包中的lastSeq，或者其中globalRanker.allUnits最后一个元素的seq。 */
  offset?: number | undefined;
}

export interface GetGlobalRankerResponse {
  globalRanker?: RankerInfo | undefined;
  hasNextPage: boolean;
  lastSeq: number;
}
