/* eslint-disable */
import type { RectOptions } from "../aiKnowledge/AiAssistReading";

export const protobufPackage = "cn.edu.idea.cloud.gpt";

/**
 * 接口描述: 对笔记选区内容提问
 * 	接口url:/select_text
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface SelectTextRequest {
  pdfur: string;
  paperid: string;
  boundingbox: RectOptions[];
  text: string;
  pageNum: number;
  traceId: string;
  uin: string;
  question: string;
  /** 参考LangType，填写：CHINESE、ENGLISH */
  lang: string;
  answerId: string;
  pdfid: string;
  chatModel: string;
}

export interface SelectTextResponse {
  answer: string;
}
