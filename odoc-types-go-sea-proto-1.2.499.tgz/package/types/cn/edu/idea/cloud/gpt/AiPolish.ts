/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.gpt";

/**
 * path: /start/task
 * method:POST
 */
export interface StartTaskRequest {
  pdfUrl: string;
  messageId: string;
  abstractPolishId: string;
  introductionPolishId: string;
}

export interface PostResponse {
  success: boolean;
}

/**
 * http request: 重新生成摘要
 * path:/abstract/repolish
 */
export interface AbstractRebolishRequest {
  pdfUrl: string;
  messageId: string;
  tags: string[];
  id: string;
  problems: string[];
}

/**
 * http request: 获取摘要标签
 * path:/abstract/tags
 * method:POST
 */
export interface AbstractTagsResponse {
  tags: string[];
}

/**
 * http request: 重新生成引言
 * path:/introduction/repolish
 */
export interface IntroductionRepolishRequest {
  pdfUrl: string;
  messageId: string;
  tags: string[];
  id: string;
  problems: string[];
}

/**
 * http request: 获取引言标签
 * path:/introduction/tags
 * method:POST
 */
export interface IntroductionTagsResponse {
  tags: string[];
}
