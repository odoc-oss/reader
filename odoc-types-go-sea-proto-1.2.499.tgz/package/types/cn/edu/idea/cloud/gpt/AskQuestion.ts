/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.gpt";

/**
 * 接口描述: 以对话形式进行提问
 *  接口url: /ask_question
 *  接口请求方式: POST
 *  参数格式:application/json
 */
export interface AskQuestionRequest {
  pdfur: string;
  paperid: string;
  question: string;
  context: AskQuestionContext[];
  traceid: string;
  uin: string;
  /** 参考LangType，填写：CHINESE、ENGLISH */
  lang: string;
  answerId: string;
  pdfid: string;
  isfirst: boolean;
  chatModel: string;
}

export interface AskQuestionResponse {
  answer: string;
}

export interface AskQuestionContext {
  question: string;
  answer: string;
}

/**
 * 接口描述: Demo中以对话形式进行提问
 *  接口url: /try_origin
 *  接口请求方式: POST
 *  参数格式:application/json
 */
export interface DemoAskQuestionRequest {
  question: string;
  contextQa: AskQuestionContext[];
  context: string;
  traceId: string;
  uin: string;
}
