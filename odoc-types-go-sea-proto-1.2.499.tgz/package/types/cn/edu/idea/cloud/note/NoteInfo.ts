/* eslint-disable */
import type { UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.note";

export interface LatestReadInfo {
  paperId?: string | undefined;
  docName: string;
  pdfId?: string | undefined;
  latestReadTime: string;
}

/**
 * 接口描述: 获取最近阅读列表
 * 	接口url: microService-app-aiKnowledge/paperNote/getLatestReadList
 * 	接口请求方式: POST
 */
export interface GetLatestReadListReq {
}

export interface GetLatestReadListResponse {
  latestReadList: LatestReadInfo[];
}

/** /pdfMark/delete */
export interface DeleteMarkReq {
  markId: string;
}

/**
 * POST /paperNote/getPaperNoteBaseInfoById
 * 根据noteId获取笔记基础信息
 */
export interface GetPaperNoteBaseInfoByIdReq {
  noteId: string;
}

/**
 * POST /paperNote/getOwnerPaperNoteBaseInfo
 * 获取自己的笔记基础信息
 */
export interface GetOwnerPaperNoteBaseInfoReq {
  pdfId: string;
  groupId?: string | undefined;
}

export interface PaperNoteBaseInfoResponse {
  pdfId: string;
  noteId: string;
  paperId: string;
  /** pdf上传者 */
  pdfContributor: string;
  /** 笔记条数 */
  paperNoteCount: number;
  /** 当前文献是否被收藏 */
  isCollected: boolean;
  /** 标记是否是用户上传 */
  isUserUpload: boolean;
  /** 当有paperId时会返回该字段,表示是否禁止公开论文,true=禁止公开 */
  isPrivatePaper?:
    | boolean
    | undefined;
  /**  */
  showAnnotation: boolean;
  paperTitle: string;
  /** 来源标签展示内容（用户名或爬取地址域名） */
  sourceMark: string;
  /** 爬取URL */
  crawlUrl: string;
  /** 上传用户ID */
  uploadUserId: string;
  licenceType: string;
  docName: string;
  noteSummary: string;
  pdfUrl: string;
  modifyDate: string;
  /** 笔记创建者信息 */
  userInfo?:
    | UserInfoBean
    | undefined;
  /**
   * 以下字段推测已经可以弃用了(目前仍然返回)
   * 和isCollected字段重复了,后面保留isCollected弃用isPaperCollected
   */
  isPaperCollected: boolean;
  /** 是否点赞,应该是没有这个功能了 */
  isLike: boolean;
  /** 点赞数 */
  likeCount: number;
  isGptWhite: boolean;
  gptGrayTip: string;
  userDocId: string;
  accessToAiAssistantReading: boolean;
}

/** /pdfMark/getPdfMarkByNoteId */
export interface GetPdfMarkByNoteIdReq {
  noteId: string;
}

/** /aiKnowledge/note/getNoteInfoByPaperId */
export interface GetNoteInfoByPaperIdReq {
  /** 论文id */
  paperId: string;
  currentPage: number;
  pageSize: number;
}

export interface GetNoteInfoByPaperIdResponse {
  writeNoteUserCount: number;
  userInfos: UserInfoBean[];
  paperTitle: string;
  pdfId: string;
  hasPublicPdf: boolean;
  hasPrivatePdf: boolean;
}
