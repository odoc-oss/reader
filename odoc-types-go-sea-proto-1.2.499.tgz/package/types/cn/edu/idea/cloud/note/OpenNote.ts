/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.note";

export enum UserStatusEnum {
  /** TOURIST - 游客态 */
  TOURIST = 0,
  /** GUEST - 客人态 */
  GUEST = 1,
  /** OWNER - 主人态 */
  OWNER = 2,
  UNRECOGNIZED = -1,
}

export enum PdfAuthStatusEnum {
  /** UNAUTHORIZED - 未认证 */
  UNAUTHORIZED = 0,
  /** AUTHORIZED - 已认证 */
  AUTHORIZED = 1,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述:开放笔记接口
 * 	接口url:/paperNote/openAccess
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface OpenAccessReq {
  /** 笔记id */
  noteId: string;
}

export interface OpenAccessResponse {
  status: number;
  message: string;
}

/**
 * 接口描述:关闭笔记分享接口
 * 	接口url:/paperNote/closeAccess
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface CloseAccessReq {
  /** 笔记id */
  noteId: string;
}

export interface CloseAccessResponse {
  status: number;
  message: string;
}

/**
 * 接口描述:获取pdf&笔记相关权限信息
 * 	接口url:/aiKnowledge/pdf/getPdfStatusInfo/v2
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetPdfStatusInfoReq {
  /** 笔记id */
  noteId: string;
  pdfId: string;
}

export interface GetPdfStatusInfoResponse {
  /** 当前用户是否有pdf权限,true=有权限,false=无权限 */
  hasPdfAccessFlag: boolean;
  /** 文献名称 */
  docName: string;
  /** 认证公开的pdfId,当有官方pdf时该字段有值, 当无官方pdf时不返回该字段 */
  authPdfId?:
    | string
    | undefined;
  /** 笔记用户状态 */
  noteUserStatus: UserStatusEnum;
  /** paperId,当论文已入库时该字段有值, 当论文未入库则不返回该字段 */
  paperId?:
    | string
    | undefined;
  /** paperTitle,当论文已入库时该字段有值, 当论文未入库则不返回该字段 */
  paperTitle: string;
  /** pdfUrl */
  pdfUrl: string;
  /** pdf用户状态 */
  pdfUserStatus: UserStatusEnum;
  /** 笔记是否公开,true=公开,false=非公开 */
  noteOpenAccessFlag: boolean;
}
