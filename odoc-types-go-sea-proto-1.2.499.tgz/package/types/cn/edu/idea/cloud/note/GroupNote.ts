/* eslint-disable */
import type { CommentatorInfoView } from "../aiKnowledge/notev2/Common";
import type { WebNoteAnnotationModel } from "../aiKnowledge/notev2/Web";

export const protobufPackage = "cn.edu.idea.cloud.note";

/** 操作类型 */
export enum OperationType {
  Delete = 0,
  Update = 1,
  Create = 2,
  UNRECOGNIZED = -1,
}

export enum CommentTarget {
  /** PdfMark - 评论的是笔记 */
  PdfMark = 0,
  /** PaperComment - 评论的是评论 */
  PaperComment = 1,
  UNRECOGNIZED = -1,
}

/** /paperNote/group/note */
export interface GroupNoteReq {
  paperId: string;
  pdfId: string;
  groupId: string;
}

export interface GroupNoteRsp {
  groupNoteId: string;
  pdfVersionSwitched: boolean;
  /** 该小组用户是否有论文，没有的话需要执行将论文加入小组的操作 */
  hasPaperInGroup: boolean;
  pdfUrl: string;
  groupPdfId: string;
  sourceMark: string;
  crawlUrl: string;
  licenceType: string;
  pdfAuthStatus: string;
  uploadUserId: string;
  isUserUpload: boolean;
}

/** /paperNote/group/addPaperToGroup */
export interface GroupDocReq {
  paperId: string;
  pdfId: string;
  groupId: string;
  paperTitle: string;
}

export interface GroupDocRsp {
}

/**
 * /paperNote/group/comment
 * POST
 * 创建评论
 */
export interface GroupNoteCommentCreateReq {
  /** uuid表示笔记id，描述绑定关系 */
  uuid: string;
  /** 评论的具体内容 */
  commentContent: string;
  /** 被评论的评论id, 为0表示评论的对象是笔记 */
  commentId: string;
  /** groupId */
  groupId: string;
}

export interface GroupNoteCommentCreateRsp {
  commentId: string;
}

/**
 * /paperNote/group/comment
 * PUT
 * 更新评论
 * 返回通用的状态码
 */
export interface GroupNoteCommentUpdateReq {
  commentId: string;
  commentContent: string;
}

/**
 * /paperNote/group/comment
 * DELETE
 * 删除评论
 * 返回通用的状态码
 */
export interface GroupNoteCommentDeleteReq {
  commentId: string;
}

export interface GroupComment {
  /** 评论内容 */
  comment: string;
  commentId: string;
  /** 评论人信息 */
  commentatorInfoView?:
    | CommentatorInfoView
    | undefined;
  /** 被评论人姓名 */
  commentedUserName: string;
  /** 当前用户是否拥有删除权限 */
  deleteAuthority: boolean;
  /** 评论的对象 */
  commentTarget: CommentTarget;
}

/**
 * /paperNote/group/comment/fetch/incremental
 * 群组评论增量更新
 */
export interface IncrementalGroupCommentReq {
  markIds: string[];
  commentModifiedTime: string;
  operationTypes: OperationType[];
  /** 群组笔记Id,groupNoteId存在将根据GroupNoteId获取 */
  groupNoteId: string;
}

export interface IncrementalGroupCommentRsp {
  commentModifiedTime: string;
  incrementalGroupComments: IncrementalGroupComment[];
}

export interface IncrementalGroupComment {
  operationType: OperationType;
  markId: string;
  groupComments: GroupComment[];
}

/**
 * /pdfMark/v2/web/group/fetch/incremental
 * 群组笔记增量更新
 */
export interface IncrementalGroupNoteReq {
  noteId: string;
  noteModifiedTime: string;
  operationTypes: OperationType[];
}

export interface IncrementalGroupNoteRsp {
  groupNoteModifiedTime: string;
  incrementalGroupNote: IncrementalGroupNote[];
}

export interface IncrementalGroupNote {
  operationType: OperationType;
  webNoteAnnotationModels: WebNoteAnnotationModel[];
}
