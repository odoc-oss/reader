/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.note";

/**
 * 改变笔记的排序
 * url: /pdfMark/changeSort
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/987
 */
export interface ChangeNoteSortRequest {
  /** 论文id */
  id1: string;
  sort1: number;
  id2: string;
  sort2: string;
}
