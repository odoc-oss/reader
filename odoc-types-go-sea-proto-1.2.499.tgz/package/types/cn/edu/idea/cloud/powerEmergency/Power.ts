/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.powerEmergency";

/** 文件类型 */
export enum FileTypeEnum {
  /** SCENARIOS - 预案 */
  SCENARIOS = 0,
  /** FILE - 普通文件 */
  FILE = 1,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述:新增场景
 * 	接口url:/power/addScene
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface AddSceneReq {
  /** 场景名称 */
  name: string;
}

/**
 * 接口描述:修改场景
 * 	接口url:/power/updateScene
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface UpdateSceneReq {
  /** 场景id */
  taskId: string;
  /** 场景名称 */
  name: string;
}

/**
 * 接口描述:删除场景
 * 	接口url:/power/delScene
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface DelSceneReq {
  /** 场景id */
  taskId: string;
}

/**
 * 接口描述:查询场景列表
 * 	接口url:/power/getSceneList
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface SceneListReq {
  /** 每页显示条数 */
  pageSize: number;
  /** 当前页 */
  currentPage: number;
  /** 查询条件 */
  name: string;
}

export interface SceneListResp {
  /** 总页数 */
  total: number;
  /** 场景数据内容 */
  sceneList: Scene[];
}

export interface Scene {
  /** 场景id */
  id: string;
  /** 场景名称 */
  name: string;
}

/**
 * 接口描述:新增标签
 * 	接口url:/power/addTag
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface AddTagReq {
  /** 标签名称 */
  name: string;
  /** 场景id */
  sceneId: string;
}

/**
 * 接口描述:修改标签
 * 	接口url:/power/updateTag
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface UpdateTagReq {
  /** 标签id */
  taskId: string;
  /** 标签名称 */
  name: string;
}

/**
 * 接口描述:删除标签
 * 	接口url:/power/delTag
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface DelTagReq {
  /** 标签id */
  taskId: string;
}

/**
 * 接口描述:查询场景标签库列表
 * 	接口url:/power/getSceneTagList
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface SceneTagListReq {
  /** 每页显示条数 */
  pageSize: number;
  /** 当前页 */
  currentPage: number;
  /** 查询条件 */
  name: string;
}

export interface SceneTagListResp {
  /** 总页数 */
  total: number;
  /** 场景标签数据内容 */
  sceneTags: SceneTags[];
}

export interface SceneTags {
  /** 场景数据 */
  scene?:
    | Scene
    | undefined;
  /** 标签列表 */
  tags: Tag[];
}

export interface Tag {
  /** 标签id */
  id: string;
  /** 标签名称 */
  name: string;
}

/**
 * 接口描述: 查询场景库对应的标签
 * 	接口url:/power/getTagsByScene
 *  serverId: microservice-ai-reading
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface GetTagsBySceneReq {
  /** 场景id */
  taskId: string;
}

export interface GetTagsBySceneResp {
  /** 标签列表数据 */
  tags: Tag[];
}

/**
 * 接口描述: 获取上传token
 * 	接口url:/power/getUploadToken
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetPowerUploadTokenReq {
  /** 文件的md5码 */
  md5: string;
  /** 文件名称 */
  fileName: string;
  /**  */
  fileType: FileTypeEnum;
}

export interface GetPowerUploadTokenResponse {
  fileName: string;
  /** 是否需要上传,true=需要 */
  isNeedUpload: boolean;
  /** 上传token */
  UploadToken: string;
  /** 上传文件id */
  uploadFileId: string;
}

export interface ObjectStoreInfo {
  bucketName?: string | undefined;
  objectName?: string | undefined;
}

/**
 * 接口描述:查询上传结果
 * 	接口url:/power/getUploadStatus
 *  serverId: microservice-ai-reading
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface GetUploadStatusReq {
  uploadFileId: string;
}

export interface GetUploadStatusResp {
  /** 用来上传文件的token */
  uploadFileId: string;
  /** 上传状态  上传中   上传失败   上传成功 */
  updateStatus: number;
}

/**
 * 接口描述: 预案列表查询
 * 	接口url:/power/getReservePlanList
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetReservePlanListReq {
  /** 每页显示条数 */
  pageSize: number;
  /** 当前页 */
  currentPage: number;
  /** 搜索条件 */
  text: string;
}

export interface GetReservePlanListResp {
  /** 总页数 */
  total: number;
  /** 预案对象列表 */
  ReservePlanList: PowerReservePlan[];
}

/** 预案对象 */
export interface PowerReservePlan {
  /** id */
  id: string;
  /** pdf文件名称 */
  fileName: string;
  /** 文件类型 */
  fileType: FileTypeEnum;
  /** 所属单位 */
  department?:
    | Department
    | undefined;
  /**  */
  summary: string;
  /** 场景 */
  scene?:
    | Scene
    | undefined;
  /** 标签列表 */
  tags: Tag[];
}

/**
 * 接口描述: 删除预案
 * 	接口url:/power/delReservePlan
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface DelReservePlanReq {
  /** 预案id */
  taskId: string;
}

/**
 * 接口描述: 修改预案
 * 	接口url:/power/updateReservePlan
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface UpdateReservePlanReq {
  /** 预案id */
  taskId: string;
  /** 场景id */
  sceneId: string;
  /** 部门id */
  depId: string;
  /** 文件类型 */
  fileType: FileTypeEnum;
  /** 标签列表 */
  tags: Tag[];
}

/**
 * 接口描述: 获取语音识别内容
 * 	接口url:/power/voiceToText
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface VoiceToTextReq {
  /** 上传token */
  file: Uint8Array;
}

export interface VoiceToTextResp {
  text: string;
}

/**
 * 接口描述: 查找文件列表
 * 	接口url:/power/findPdfByText
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface FindPdfByTextReq {
  text: string;
}

export interface FindPdfByTextResp {
  /** 文件列表 */
  ReservePlanList: PowerReservePlan[];
}

export interface SendQuestionReq {
  /** 文件id */
  taskId: string;
  /** 提问文本 */
  text: string;
  /** 参考LangType，填写：CHINESE、ENGLISH */
  lang: string;
}

/**
 * 接口描述: 获取问题答案
 * 	接口url:/power/getQuestionAsk
 *  serverId: microservice-ai-reading
 * 	接口请求方式: GET
 * 	参数格式:application/json
 *  响应: AiAssistReading.GetAiAnswerByIdResp
 */
export interface GetQuestionAskReq {
  /** 问题id */
  taskId: string;
}

export interface GetQuestionAskResp {
  /** 问题答案内容 */
  text: string;
  /** 是否回答完毕   0：等待回答/回答中    1：已完成   2 失败 */
  askStatus: boolean;
}

/**
 * 接口描述: 获取部门数据
 * 	接口url:/power/getDepList
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetDepResp {
  depList: Department[];
}

export interface Department {
  /** 标签id */
  id: string;
  /** 标签名称 */
  name: string;
}

export interface GetDegreeResp {
  degreeList: string[];
}

export interface GetCmdResp {
  cmdList: string[];
}

/**
 * 接口描述: 获取pdf链接
 * 	接口url:/power/getPdfUrl
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetPdfUrlReq {
  taskId: string;
}

export interface GetPdfUrlResp {
  pdfUrl: string;
}

/**
 * 接口描述: 根据场景和单位和类型找到对应的预案文件
 * 	接口url:/power/getFileBySceneAndDepAndType
 *  serverId: microservice-ai-reading
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface getFileBySceneAndDepAndTypeReq {
  /** 场景id */
  sceneId: string;
  /** 单位id */
  depId: string;
  /**  */
  fileType: FileTypeEnum;
}

export interface getFileBySceneAndDepAndTypeResp {
  /** 文件对象列表 */
  fileList: PowerFileObj[];
}

/** 文件对象 */
export interface PowerFileObj {
  /** id */
  fileId: string;
  /** pdf文件名称 */
  fileName: string;
  /** 所属单位信息 */
  department?:
    | Department
    | undefined;
  /** 总结 */
  summary: string;
}
