/* eslint-disable */
import type { AcquirePolicyCallbackInfoResponse } from "../oss/AliOSS";

export const protobufPackage = "cn.edu.idea.cloud.chatScholar";

export enum AnswerStatus {
  /** ASKING - 获取结果中 */
  ASKING = 0,
  /** FINISHED - 回答已完成 */
  FINISHED = 1,
  /** FAIL - 获取结果失败 */
  FAIL = 2,
  UNRECOGNIZED = -1,
}

export enum StrategyEnum {
  /** HYBRIDBEST - hybridbest */
  HYBRIDBEST = 0,
  /** HYBRIDIDEA - hybrididea */
  HYBRIDIDEA = 1,
  /** ONLYIDEA - onlyidea */
  ONLYIDEA = 2,
  UNRECOGNIZED = -1,
}

export enum StyleEnum {
  /** PROFESSIONAL - 专业 */
  PROFESSIONAL = 0,
  /** BALANCE - 平衡 */
  BALANCE = 1,
  /** POPULAR_SCIENCE - 科普 */
  POPULAR_SCIENCE = 2,
  UNRECOGNIZED = -1,
}

export enum ScopeEnum {
  /** NO_LIMIT - 不限定 */
  NO_LIMIT = 0,
  /** SINGLE_DOC - 单文献 */
  SINGLE_DOC = 1,
  /** MULTI_DOC - 多文献 */
  MULTI_DOC = 2,
  /** DOMAIN - 领域行业 */
  DOMAIN = 3,
  /** DOC_LIBRARY - 文献库 */
  DOC_LIBRARY = 4,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 提问
 * 	接口url: microservice-chat-scholar/chatScholar/askQuestion
 * 	接口请求方式: POST
 */
export interface AskQuestionReq {
  /** 会话id */
  chatId?:
    | string
    | undefined;
  /** 问题 */
  question: string;
  /** domain信息 */
  domainList: string[];
  /** 风格 */
  style?:
    | StyleEnum
    | undefined;
  /** 策略 */
  strategy?:
    | StrategyEnum
    | undefined;
  /** 指定范围 */
  scope?:
    | ScopeEnum
    | undefined;
  /** PdfId信息 */
  pdfIdList: string[];
  /** Pdf信息List，仅用于多文献 */
  pdfInfoList: PdfInfo[];
  userId?: string | undefined;
  lang?: string | undefined;
}

export interface AskQuestionResponse {
  question?: QuestionInfo | undefined;
  answer?: AnswerInfo | undefined;
  chatId: string;
}

/**
 * 接口描述: 获取回答
 * 	接口url: microservice-chat-scholar/chatScholar/getAnswer
 * 	接口请求方式: POST
 */
export interface GetAnswerReq {
  answerId: string;
}

export interface GetAnswerResponse {
  answer?: AnswerInfo | undefined;
}

/**
 * 接口描述: 获取会话内容
 * 	接口url: microservice-chat-scholar/getChatInfo
 * 	接口请求方式: POST
 */
export interface GetChatInfoReq {
  /** 会话id */
  chatId: string;
}

export interface GetChatInfoResponse {
  /** 当前会话的问答列表 */
  questionAnswerList: QuestionAnswerInfo[];
  /** 当前会话的风格 */
  style: StyleEnum;
  /** 当前会话的策略 */
  strategy: StrategyEnum;
  /** 当前会话的指定范围 */
  scope: ScopeEnum;
  /** pdf信息 */
  docPdfInfoList: PdfInfo[];
  /** domain信息 */
  domainList: string[];
}

/**
 * 接口描述: 获取会话列表
 * 	接口url: microservice-chat-scholar/chatScholar/getChatList
 * 	接口请求方式: POST
 */
export interface GetChatListReq {
}

export interface GetChatListResponse {
  chatList: ChatInfo[];
}

/**
 * 接口描述: 删除会话
 * 	接口url: microservice-chat-scholar/chatScholar/deleteChat
 * 	接口请求方式: POST
 */
export interface DeleteChatReq {
  /** 会话id */
  chatId: string;
}

/**
 * 接口描述: 获取上传到阿里云OSS所需的token
 * 	接口url: microservice-chat-scholar/chatScholar/getUploadToken
 * 	接口请求方式: POST
 */
export interface GetUploadTokenReq {
  md5?: string | undefined;
}

export interface GetUploadTokenResponse {
  /** isNeedUpload为true时即要上传文件到阿里云,为false不用上传到阿里云,后端添加数据 */
  tokenInfo?:
    | AcquirePolicyCallbackInfoResponse
    | undefined;
  /** 当tokenInfo中的isNeedUpload为false时,该字段才有值 */
  pdfInfo?: PdfInfo | undefined;
}

/**
 * 接口描述: 获取领域列表
 * 	接口url: microservice-chat-scholar/chatScholar/getDomainList
 * 	接口请求方式: POST
 */
export interface GetDomainListReq {
  searchContent?: string | undefined;
  index?: number | undefined;
}

export interface GetDomainListResponse {
  latestIndex: number;
  fosItems: FosInfo[];
}

/**
 * 接口描述: 保存Pdf信息
 * 	接口url: microservice-chat-scholar/chatScholar/savePdfInfo
 * 	接口请求方式: POST
 */
export interface SavePdfInfoReq {
  ossObjectName: string;
  md5: string;
}

export interface SavePdfInfoResponse {
  pdfInfo?: PdfInfo | undefined;
}

/**
 * 接口描述: 更改会话标题
 * 	接口url: microservice-chat-scholar/chatScholar/renameChat
 * 	接口请求方式: POST
 */
export interface RenameChatReq {
  chatId: string;
  chatTitle: string;
}

export interface FosInfo {
  id: string;
  name: string;
  parentName?: string | undefined;
  grandParentName?: string | undefined;
}

export interface PdfInfo {
  pdfId: string;
  title: string;
  url: string;
}

export interface QuestionAnswerInfo {
  question?: QuestionInfo | undefined;
  answer?: AnswerInfo | undefined;
}

export interface ChatInfo {
  chatId: string;
  chatTitle: string;
}

export interface DocInfo {
  chatId: string;
  docId: string;
  docTitle: string;
}

export interface QuestionInfo {
  questionId: string;
  text: string;
}

export interface AnswerInfo {
  status: AnswerStatus;
  text: string;
  answerId: string;
}
