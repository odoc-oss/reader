/* eslint-disable */
import type { Type } from "./Base";
import type { CommentOption } from "./Comment";
import type { RectAnnotate } from "./Rect";

export const protobufPackage = "cn.edu.idea.cloud.pdfAnnotate";

/**
 * Created Date: November 26th 2021, 3:01:58 pm
 * Author: zhoupengcheng
 * -----
 * Last Modified: November 26th 2021, 3:25:54 pm
 */

export interface ContentOption {
  type: Type;
  comment?: CommentOption | undefined;
  rect?: RectAnnotate | undefined;
}
