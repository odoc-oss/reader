/* eslint-disable */
import type { Rectangle, RectOption, Type } from "./Base";

export const protobufPackage = "cn.edu.idea.cloud.pdfAnnotate";

/**
 * Created Date: November 26th 2021, 11:13:58 am
 * Author: zhoupengcheng
 * -----
 * Last Modified: November 26th 2021, 11:59:45 am
 */

export interface CommentOption {
  type: Type;
  rectangles: Rectangle[];
  fill: string;
  idea: string;
  rects: RectOption[];
  rectStr: string;
  page: number;
}
