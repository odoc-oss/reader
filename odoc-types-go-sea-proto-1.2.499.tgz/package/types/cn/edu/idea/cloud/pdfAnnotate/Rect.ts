/* eslint-disable */
import type { Rectangle, Type } from "./Base";

export const protobufPackage = "cn.edu.idea.cloud.pdfAnnotate";

/**
 * Created Date: November 25th 2021, 4:30:59 pm
 * Author: zhoupengcheng
 * -----
 * Last Modified: November 26th 2021, 3:25:54 pm
 */

export interface RectAnnotate {
  type: Type;
  color: string;
  fill: string;
  fillOpacity: number;
  lineColor: string;
  page: number;
  rectangles: Rectangle[];
  strokeDasharray: string;
  idea: string;
  rectStr: string;
}
