/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.pdfAnnotate";

/**
 * Created Date: November 26th 2021, 11:14:53 am
 * Author: zhoupengcheng
 * -----
 * Last Modified: November 26th 2021, 12:00:28 pm
 */

export enum Type {
  COMMENT = 0,
  Rect = 1,
  UNRECOGNIZED = -1,
}

export interface Rectangle {
  y: number;
  x: number;
  width: number;
  height: number;
}

export interface RectOption {
  top: number;
  left: number;
  width: number;
  height: number;
}
