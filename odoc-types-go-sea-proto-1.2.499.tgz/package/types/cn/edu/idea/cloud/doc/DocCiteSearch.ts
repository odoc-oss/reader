/* eslint-disable */
import type { DocMetaInfoSimpleVo } from "./CSL";

export const protobufPackage = "cn.edu.idea.cloud.doc";

/**
 * 接口描述: 英文检索(DOI/标题)
 * 	接口url: microservice-readpaper-doc/userDoc/citeSearch/en
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface EnDocCiteSearchReq {
  searchContent: string;
}

export interface EnDocCiteSearchResponse {
  result: DocMetaInfoSimpleVo[];
}

/**
 * 接口描述: 中文检索
 * 	接口url: microservice-readpaper-doc/userDoc/citeSearch/zh
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ZhDocCiteSearchReq {
  searchContent: string;
}

export interface ZhDocCiteSearchResponse {
  result: DocMetaInfoSimpleVo[];
}
