/* eslint-disable */
import type { AcquirePolicyCallbackInfoResponse } from "../oss/AliOSS";

export const protobufPackage = "cn.edu.idea.cloud.doc";

/**
 * 接口描述: 获取上传到阿里云OSS所需的token
 * 	接口url: microservice-readpaper-doc/userDoc/attachment/getUploadToken
 * 	接口请求方式: POST
 */
export interface GetUploadTokenReq {
  md5?: string | undefined;
  docId: string;
  /** 单位B */
  size: number;
  /** 文件名称 */
  fileName: string;
  contentType: string;
  userId?: string | undefined;
}

export interface GetUploadTokenResponse {
  /** isNeedUpload为true时即要上传文件到阿里云,为false不用上传到阿里云,后端添加附件数据 */
  data?:
    | AcquirePolicyCallbackInfoResponse
    | undefined;
  /** status为0时,即有报错信息(即message有值),(附件内存过大，上传失败  OR 附件总空间已满，请删除部分附件后再重新上传) */
  status: number;
  message: string;
}

/**
 * 接口描述: 获取文献的附件列表
 * 	接口url: microservice-readpaper-doc/userDoc/attachment/getAttachmentList
 * 	接口请求方式: POST
 */
export interface GetAttachmentListReq {
  docId: string;
}

export interface GetAttachmentListResponse {
  list: AttachmentInfo[];
  /** 已经使用的储存空间,单位B */
  usedSpaceUsed: number;
  /** 总空间,单位B */
  totalSpace: number;
  /** 附件数量上限 */
  amountLimit: number;
  /** 单文件大小限制 */
  sizeLimit: number;
}

export interface AttachmentInfo {
  /** 文件大小,单位B */
  size: number;
  /** 文件名称 */
  name: string;
  /** 文件url */
  url: string;
  /** 文件contentType */
  contentType: string;
  /** 附件id */
  id: string;
  /** 是否为可预览的附件 */
  isPreview: boolean;
}

/**
 * 接口描述: 删除附件
 * 	接口url: microservice-readpaper-doc/userDoc/attachment/delete
 * 	接口请求方式: POST
 */
export interface DeleteAttachmentReq {
  attachmentId: string;
}

/**
 * 接口描述: 保存附件
 * 	接口url: microservice-readpaper-doc/userDoc/attachment/save
 * 	接口请求方式: POST
 */
export interface SaveAttachmentReq {
  docId: string;
  ossObjectName: string;
  fileName: string;
  /** 单位B */
  size: number;
  /** 对应阿里云上传接口返回的mimeType */
  contentType: string;
  userId?: string | undefined;
}
