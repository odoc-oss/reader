/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.doc";

/**
 * 接口描述: 获取文献类型列表
 * 	接口url: microservice-readpaper-doc/docPublic/docMetaInfo/getDocTypeList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetDocTypeListReq {
}

export interface GetDocTypeListResponse {
  status: number;
  message: string;
  data: DocTypeInfo[];
}

export interface DocTypeInfo {
  code: string;
  name: string;
}

/**
 * 接口描述: 获取meta数据
 * 	接口url: microservice-readpaper-doc/docPublic/docMetaInfo/getDocMetaInfo
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetDocMetaInfoReq {
  paperId?: string | undefined;
  pdfId?: string | undefined;
  docId?: string | undefined;
}

export interface GetDocMetaInfoResponse {
  status: number;
  message: string;
  data?: DocMetaInfoSimpleVo | undefined;
}

export interface DocMetaInfoSimpleVo {
  /** 发布时间,毫秒值时间戳 */
  publishTimestamp: string;
  /** 文献名称 */
  title: string;
  /** 收录情况 */
  containerTitle: string[];
  /** 页码 */
  page?:
    | string
    | undefined;
  /** 作者信息 */
  authorList: AuthorInfo[];
  /** 文献类型 */
  docType: string;
  eventTitle?: string | undefined;
  eventPlace?: string | undefined;
  eventDate: string[];
  /** doi */
  doi?:
    | string
    | undefined;
  /** 卷次 */
  volume?:
    | string
    | undefined;
  /** 期号 */
  issue?: string | undefined;
  url?: string | undefined;
  language?:
    | string
    | undefined;
  /** 与 publishTimestamp 对应 */
  publishDateStr?:
    | string
    | undefined;
  /** 分区信息 */
  partition?:
    | string
    | undefined;
  /** 文献类型显示名称 */
  docTypeName?: string | undefined;
}

export interface AuthorInfo {
  given?: string | undefined;
  family?: string | undefined;
  literal: string;
  id?: string | undefined;
  isAuthentication: boolean;
}

/**
 * 接口描述: 引用默认格式列表
 * 	接口url: microservice-readpaper-doc/docPublic/csl/getDefaultCslList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface CetDefaultCslListReq {
}

export interface CetDefaultCslListResponse {
  total: number;
  list: CslItem[];
}

/**
 * 接口描述: 引用格式列表
 * 	接口url: microservice-readpaper-doc/csl/list
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetCslListReq {
  pageSize: number;
  currentPage: number;
  /** 搜索词 */
  searchContent: string;
}

export interface GetCslListResponse {
  total: number;
  list: CslItem[];
}

export interface CslItem {
  id: string;
  title: string;
  /** 时间信息 */
  updated: string;
  /** csl文件的cdn地址 */
  fileUrl: string;
  /** 是否添加 */
  addedFlag: boolean;
  shortTitle?: string | undefined;
  customDefineTitle?: string | undefined;
  lang?: string | undefined;
}

/**
 * 接口描述: 我已添加的引用格式列表
 * 	接口url: microservice-readpaper-doc/csl/myCslList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetMyCslListReq {
}

export interface GetMyCslListResponse {
  total: number;
  list: MyCslItem[];
}

export interface MyCslItem {
  id: string;
  title: string;
  shortTitle?:
    | string
    | undefined;
  /** csl文件的cdn地址 */
  fileUrl: string;
  customDefineTitle?: string | undefined;
  lang?: string | undefined;
}

/**
 * 接口描述: 添加格式
 * 	接口url: microservice-readpaper-doc/csl/addCsl
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应:MyCslItem
 */
export interface AddCslReq {
  cslId: string;
}

/**
 * 接口描述: 删除格式
 * 	接口url: microservice-readpaper-doc/csl/deleteCsl
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface DeleteCslReq {
  cslId: string;
}

/**
 * 接口描述: 排序
 * 	接口url: microservice-readpaper-doc/csl/sortCsl
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface SortCslReq {
  /** 排序后的格式id列表 */
  cslIds: string[];
}
