/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.doc.bibtex";

/**
 * 接口描述: 通过ids导出数据
 * 	接口url: microservice-readpaper-doc/doc/bibtex/exportByIds
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ExportByIdsReq {
  docIds: string[];
}

/** 文件 */
export interface GetDocMetaInfoResp {
}

/**
 * 接口描述: 通过folderId导出数据
 * 	接口url: microservice-readpaper-doc/doc/bibtex/exportByFolderId
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ExportByFolderIdReq {
  folderId: string;
}

/** 文件 */
export interface ExportByFolderIdResp {
}
