/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.doc";

export enum DocReadingStatus {
  /** UNREAD - 未读 */
  UNREAD = 0,
  /** READING - 正在读 */
  READING = 1,
  /** READ - 已读 */
  READ = 2,
  UNRECOGNIZED = -1,
}

export enum PaperRepositoryStatus {
  /** IN_REPOSITORY - 这是一篇论文, IAG中也存在这边论文的信息 */
  IN_REPOSITORY = 0,
  /** NOT_IN_REPOSITORY - 这不是一篇论文, 或者IAG没有论文的相关信息 */
  NOT_IN_REPOSITORY = 1,
  UNRECOGNIZED = -1,
}

export enum UserDocListSortType {
  DEFAULT = 0,
  /** LAST_READ - 最近阅读 */
  LAST_READ = 1,
  /** LAST_ADD - 最近添加 */
  LAST_ADD = 2,
  /** DOC_NAME - 文献名 */
  DOC_NAME = 3,
  /** PUBLISH_DATE - 发布日期 */
  PUBLISH_DATE = 4,
  /** CUSTOM_SORT - 自定义排序 */
  CUSTOM_SORT = 5,
  /** IMPORTANCE_SCORE - 按重要性打分 */
  IMPORTANCE_SCORE = 6,
  /** IMPACT_OF_FACTOR - 按影响因子排序 */
  IMPACT_OF_FACTOR = 7,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 手动更新文献引用信息
 * 	接口url: microservice-readpaper-doc/userDoc/manualUpdateDocCiteInfo
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface ManualUpdateDocCiteInfoReq {
  /** paperId和pdfId不能全为空 */
  paperId?:
    | string
    | undefined;
  /** paperId和pdfId不能全为空 */
  pdfId?:
    | string
    | undefined;
  /** 文献标题 */
  docName?:
    | string
    | undefined;
  /** 作者(新增的作者名称传入literal字段) */
  authorList: UserDocAuthorInfo[];
  /** doi */
  doi?:
    | string
    | undefined;
  /** 发布时间,yyyy-MM-dd */
  publishDate?:
    | string
    | undefined;
  /** 收录情况 */
  venue?:
    | string
    | undefined;
  /** 分区信息 */
  partition?:
    | string
    | undefined;
  /** 文献类型 */
  docType?:
    | string
    | undefined;
  /** 卷次 */
  volume?:
    | string
    | undefined;
  /** 期号 */
  issue?:
    | string
    | undefined;
  /** 页码 */
  page?: string | undefined;
  userId?: string | undefined;
}

/**
 * 接口描述: 检索更新文献引用信息
 * 	接口url: microservice-readpaper-doc/userDoc/searchUpdateDocCiteInfo
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface SearchUpdateDocCiteInfoReq {
  /** paperId和pdfId不能全为空 */
  paperId?:
    | string
    | undefined;
  /** paperId和pdfId不能全为空 */
  pdfId?:
    | string
    | undefined;
  /** 文献标题 */
  docName?:
    | string
    | undefined;
  /** 作者(新增的作者名称传入literal字段) */
  authorList: UserDocAuthorInfo[];
  /** doi */
  doi?:
    | string
    | undefined;
  /** 发布时间,yyyy-MM-dd */
  publishDate?:
    | string
    | undefined;
  /** 收录情况 */
  venue?:
    | string
    | undefined;
  /** 分区信息 */
  partition?:
    | string
    | undefined;
  /** 文献类型 */
  docType?:
    | string
    | undefined;
  /** 卷次 */
  volume?:
    | string
    | undefined;
  /** 期号 */
  issue?:
    | string
    | undefined;
  /** 页码 */
  page?: string | undefined;
  userId?: string | undefined;
}

export interface UpdateDocCiteInfoResponse {
  status: number;
  message: string;
  data: string;
}

/**
 * 接口描述: 获取用户文献相关的作者列表
 * 	接口url: microservice-readpaper-doc/userDoc/getDocRelatedAuthorList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetDocRelatedAuthorListReq {
  /** 文件夹id */
  folderId?: string | undefined;
  userId?: string | undefined;
}

export interface GetDocRelatedAuthorListResponse {
  total: number;
  authorInfos: string[];
}

/**
 * 接口描述: 获取用户文献相关的标签列表
 * 	接口url: microservice-readpaper-doc/userDoc/getDocRelatedClassifyList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetDocRelatedClassifyListReq {
  /** 文件夹id */
  folderId?: string | undefined;
  userId?: string | undefined;
}

export interface GetDocRelatedClassifyListResponse {
  total: number;
  classifyInfos: UserDocClassifyInfo[];
}

/**
 * 接口描述: 获取用户文献相关的收录情况列表
 * 	接口url: microservice-readpaper-doc/userDoc/getDocRelatedVenueList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetDocRelatedVenueListReq {
  /** 文件夹id */
  folderId?: string | undefined;
  userId?: string | undefined;
}

export interface GetDocRelatedVenueListResponse {
  total: number;
  venueInfos: string[];
}

/**
 * 接口描述: 获取用户文献数量
 * 	接口url: microservice-readpaper-doc/userDoc/getDocCount
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetDocCountReq {
}

export interface GetDocCountResponse {
  count: number;
}

/**
 * 接口描述: 获取用户单个文献详细信息
 * 	接口url: microservice-readpaper-doc/userDoc/getSingleDocInfo
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  返回UserDocManage.UserDocInfo
 */
export interface GetSingleDocInfoReq {
  /** 文献id */
  docId: string;
  userId?: string | undefined;
}

export interface GetSingleDocInfoResponse {
  status: number;
  message: string;
  data?: UserDocInfo | undefined;
}

/**
 * 接口描述: 获取用户文献列表
 * 	接口url: microservice-readpaper-doc/userDoc/getDocList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetDocListReq {
  sortType?:
    | UserDocListSortType
    | undefined;
  /** 是否升序 */
  ascSort?:
    | boolean
    | undefined;
  /** 标签id */
  classifyIds: string[];
  /** 筛选的作者信息 */
  authorInfos: string[];
  /** 筛选的收录情况 */
  venueInfos: string[];
  pageSize?: number | undefined;
  currentPage?: number | undefined;
  userId?: string | undefined;
  folderId?: string | undefined;
  searchContent?: string | undefined;
  extMeta?: boolean | undefined;
  jcrPartions: string[];
  impactOfFactorRange: number[];
  onlyShowDocsWithImpactOfFactor: boolean;
  /** 只看有pdf的数据 */
  onlyPdf?: boolean | undefined;
}

export interface GetDocListResponse {
  total: number;
  docList: UserDocInfo[];
}

/**
 * 文献列表左侧-获取文件夹列表和文献列表
 * url: microservice-readpaper-doc/userDoc/getDocIndex
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetDocIndexReq {
  userId?: string | undefined;
}

export interface GetDocIndexResponse {
  totalDocCount: number;
  folderInfos: UserDocFolderInfo[];
  unclassifiedDocInfos: SimpleUserDocInfo[];
}

export interface UserDocFolderInfo {
  /** 文件夹名 */
  name: string;
  /** 文献数 */
  docCount: number;
  /** 父文件夹id */
  parentId: string;
  /** 文件夹id */
  folderId: string;
  /** 文件夹层级 */
  level: number;
  /** 文件夹排序 */
  sort: number;
  /** 子文件夹 */
  childrenFolders: UserDocFolderInfo[];
  /** 文献信息 */
  docInfos: SimpleUserDocInfo[];
}

export interface SimpleUserDocInfo {
  /** 排序 */
  sort: number;
  /** 文献名 */
  docName: string;
  /** 文献id */
  docId: string;
  pdfId: string;
  paperId: string;
  noteId: string;
}

export interface UserDocInfo {
  docId: string;
  docName: string;
  sort: number;
  paperId: string;
  pdfId?: string | undefined;
  remark?: string | undefined;
  createDate: string;
  lastReadTime?: string | undefined;
  isLatestRead: boolean;
  noteId?: string | undefined;
  newPaper: boolean;
  classifyInfos: UserDocClassifyInfo[];
  paperRepositoryStatus: PaperRepositoryStatus;
  displayAuthor?: UserDocDisplayAuthor | undefined;
  displayVenue?: UserDocDisplayVenue | undefined;
  displayPublishDate?:
    | UserDocDisplayPublishDate
    | undefined;
  /** meta信息 */
  displayPage?: UserDocDisplayPage | undefined;
  displayDocType?:
    | UserDocDisplayDocType
    | undefined;
  /** 会议 */
  displayEventInfo?: UserDocDisplayEventInfo | undefined;
  displayUrl?: UserDocDisplayUrl | undefined;
  displayLanguage?: UserDocDisplayLanguage | undefined;
  displayDoi?: UserDocDisplayDoi | undefined;
  displayVolume?: UserDocDisplayVolume | undefined;
  displayIssue?: UserDocDisplayIssue | undefined;
  displayPartition?: UserDocDisplayPartition | undefined;
  searchResult?:
    | DocSearchResult
    | undefined;
  /** 是否有附件 */
  hasAttachment: boolean;
  jcrVenuePartion?: UserDocDisplayJcrVenuePartion | undefined;
  importantanceScore: number;
  impactOfFactor?: UserDocDisplayJcrImpactFactor | undefined;
  docReadingStatus: DocReadingStatus;
  progress?: number | undefined;
  fillExtMeta: boolean;
}

export interface UserDocDisplayJcrVenuePartion {
  jcrVenuePartion?:
    | string
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originJcrVenuePartion?: string | undefined;
}

export interface UserDocDisplayJcrImpactFactor {
  impactOfFactor?:
    | number
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originImpactOfFactor?: number | undefined;
}

export interface DocSearchResult {
  /** 搜索命中的文献名称 */
  hitDocName?:
    | string
    | undefined;
  /** 搜索命中的笔记内容 */
  hitNote?:
    | string
    | undefined;
  /** //搜索命中的文献备注 */
  hitRemark?: string | undefined;
}

export interface UserDocClassifyInfo {
  classifyId: string;
  classifyName: string;
}

export interface UserDocDisplayVolume {
  volume?:
    | string
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originVolume?: string | undefined;
}

export interface UserDocDisplayIssue {
  issue?:
    | string
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originIssue?: string | undefined;
}

export interface UserDocDisplayPartition {
  partition?:
    | string
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originPartition?: string | undefined;
}

export interface UserDocDisplayDoi {
  doi?:
    | string
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originDoi?: string | undefined;
}

export interface UserDocDisplayUrl {
  url?:
    | string
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originUrl?: string | undefined;
}

export interface UserDocDisplayLanguage {
  language?:
    | string
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originLanguage?: string | undefined;
}

export interface UserDocDisplayEventInfo {
  eventInfo?:
    | EventInfo
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originEventInfo?: EventInfo | undefined;
}

export interface EventInfo {
  eventTitle?: string | undefined;
  eventPlace?: string | undefined;
  eventDate: string[];
}

export interface UserDocDisplayPage {
  page?:
    | string
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originPage?: string | undefined;
}

export interface UserDocDisplayDocType {
  docType?:
    | string
    | undefined;
  /** 用户是否编辑过 */
  userEdited?: boolean | undefined;
  originDocType?: string | undefined;
}

export interface UserDocDisplayVenue {
  venueInfos: string[];
  /** 用户是否编辑过 */
  userEdited: boolean;
  originVenueInfos: string[];
}

export interface UserDocDisplayAuthor {
  authorInfos: UserDocAuthorInfo[];
  userEdited: boolean;
  originAuthorInfos: UserDocAuthorInfo[];
}

export interface UserDocAuthorInfo {
  id?: string | undefined;
  given?: string | undefined;
  family?:
    | string
    | undefined;
  /** 作者名(全称) */
  literal: string;
  isAuthentication: boolean;
}

export interface UserDocDisplayPublishDate {
  publishDate: string;
  userEdited: boolean;
  originPublishDate: string;
}

/**
 * 接口描述: 标记已读
 * 	接口url: microservice-readpaper-doc/userDoc/mark/finish
 * 	接口请求方式: PUT
 * 	参数格式:application/json
 *  返回通用的状态码
 */
export interface MarkFinishReq {
  paperId?: string | undefined;
  pdfId: string;
}

/**
 * 接口描述: 按重要性打分
 * 	接口url: microservice-readpaper-doc/userDoc/importance/score
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  返回通用的状态码
 */
export interface ImportanceScoreReq {
  docId: string;
  score: number;
}

/**
 * 接口描述: 获取当前目录下的所有jcr分区
 * 	接口url: microservice-readpaper-doc/userDoc/jcr/partions
 * 	接口请求方式: GET
 * 	参数格式:application/json
 *  返回通用的状态码
 */
export interface JcrPartionsReq {
  folderId: string;
}

export interface JcrPartionsResponse {
  jcrPartions: string[];
}

/**
 * 接口描述: 修改影响因子
 * 	接口url: microservice-readpaper-doc/userDoc/impact/factor
 * 	接口请求方式: PUT
 * 	参数格式:application/json
 *  返回通用的状态码
 */
export interface ImpactFactorReq {
  docId: string;
  impactOfFactor?: number | undefined;
}

export interface ImpactFactorResponse {
  originalImpactOfFactor: number;
  rollbackEnable: boolean;
  currentImpactOfFactor: number;
}

/**
 * 接口描述: 修改jcr分区
 * 	接口url: microservice-readpaper-doc/userDoc/jcr/partion
 * 	接口请求方式: PUT
 * 	参数格式:application/json
 *  返回通用的状态码
 */
export interface JcrPartionUpdateReq {
  docId: string;
  jcrPartion: string;
}

export interface JcrPartionUpdateResponse {
  originalJcrPartion: string;
  rollbackEnable: boolean;
  currentJcrPartion: string;
}

/**
 * 接口描述: 更新阅读状态
 * 	接口url: /userDoc/updateReadStatus
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  返回通用的状态码
 */
export interface UpdateReadStatusRequest {
  paperId?: string | undefined;
  pdfId: string;
  status?: DocReadingStatus | undefined;
  progress?: number | undefined;
}
