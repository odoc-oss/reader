/* eslint-disable */
import type { PageRequest, PageResponse } from "../common/Base";

export const protobufPackage = "cn.edu.idea.cloud.pdf";

/**
 * 【PDF解析】提取参考信息
 * url: /pdfApi/parser/getReference
 * method: POST
 */
export enum ReferenceSortType {
  DEFAULT = 0,
  CITATION = 1,
  PUBLISH_DATE = 2,
  UNRECOGNIZED = -1,
}

export enum ParseStatus {
  PARSE_UNKNOW = 0,
  PARSE_RUNNING = 1,
  PARSE_FINISH = 2,
  UNRECOGNIZED = -1,
}

/** 用来描述PDF元素的位置 */
export interface PdfBBox {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
  originHeight: number;
  originWidth: number;
}

/**
 * 【PDF解析】提取取图表信息
 * url: /pdfApi/parser/getFiguresAndTables
 * method: POST
 */
export interface GetFiguresAndTablesListRequest {
  pageReq?: PageRequest | undefined;
  pdfId: string;
}

/** 请求 */
export interface GetFiguresAndTablesRequest {
  pageReq?: PageRequest | undefined;
  pdfId: string;
  paperId: string;
}

/**
 * message GetFiguresAndTablesListRequest { // 请求
 *    common.PageRequest pageReq = 1;
 *    uint64 pdfId = 2[(common.notNull) = false];
 *    uint64 paperId = 3[(common.notNull) = false];
 * }
 */
export interface PdfFigureAndTableInfo {
  pageNum: number;
  desc: string;
  url: string;
  bbox?: PdfBBox | undefined;
  refIdx: string;
}

/** 响应 */
export interface GetFiguresAndTablesListResponse {
  pageResp?: PageResponse | undefined;
  figureAndTableList: PdfFigureAndTableInfo[];
  /** 提示重试 */
  needFetch: boolean;
}

/** 请求 */
export interface GetReferenceRequest {
  pageReq?: PageRequest | undefined;
  pdfId: string;
  sortType: ReferenceSortType;
  paperId: string;
  filterNoTitle?: boolean | undefined;
}

export interface ReferenceInfo {
  paperId: string;
  title: string;
  pageNum: number;
  bbox?: PdfBBox | undefined;
  refIdx: string;
  citationCount: number;
  publishDate: string;
  searchKey: string;
  paperMetaExtend?: PaperMetaExtend | undefined;
}

/** 响应 */
export interface GetReferenceResponse {
  pageResp?: PageResponse | undefined;
  referenceInfoList: ReferenceInfo[];
  referenceCount: number;
  citationCount: number;
  /** 提示重试 */
  needFetch: boolean;
}

export interface PaperMetaExtend {
  /** 没有就是0 */
  pdfId: string;
  authorList: Author[];
  venueTags: string[];
  publishDate: string;
  venues: string[];
  noteCount: number;
  citationCount: number;
  summary: string;
  title: string;
  paperId: string;
}

export interface Author {
  name: string;
}

/**
 * 【PDF解析】提取被引用信息
 * url: /pdfApi/parser/getCitation
 * method: POST
 */
export interface GetCitationRequest {
  pageReq?: PageRequest | undefined;
  paperId: string;
  sortType: ReferenceSortType;
}

export interface CitationInfo {
  paperId: string;
  title: string;
  citaIdx: string;
  citationCount: number;
  publishDate: string;
  paperMetaExtend?: PaperMetaExtend | undefined;
}

/** 响应 */
export interface GetCitationResponse {
  pageResp?: PageResponse | undefined;
  citationInfoList: CitationInfo[];
  referenceCount: number;
  citationCount: number;
  /** 提示重试 */
  needFetch: boolean;
}

/**
 * 【PDF解析】提取参考标签
 * url: /pdfApi/parser/getReferenceMarkers
 * method: POST
 */
export interface GetReferenceMarkersRequest {
  pdfId: string;
}

export interface ReferenceMarker {
  refIdx: string;
  bbox?: PdfBBox | undefined;
  paperId: string;
  refContent: string;
  pageNum: number;
  refRaw: string;
}

export interface FigureAndTableReferenceMarker {
  bbox?: PdfBBox | undefined;
  pageNum: number;
  refContent: string;
  refIdx: string;
}

/** 响应 */
export interface GetReferenceMarkersResponse {
  markers: ReferenceMarker[];
  /** 提示重试 */
  needFetch: boolean;
  figureAndTableMarkers: FigureAndTableReferenceMarker[];
}

/** cv解析PDF */
export interface AsyncPdfCvParseRequest {
  url: string;
  md5: string;
  fulltext: boolean;
}

/** 响应 */
export interface AsyncPdfCvParseResponse {
  code: string;
  data: PdfFigureAndTableInfo[];
  procStatus: ParseStatus;
}

/**
 * 【PDF解析】提取参考信息
 * url: /pdfApi/parser/getCatalogue
 * method: POST
 */
export interface GetCatalogueRequest {
  pdfId: string;
}

export interface PdfCatalogueInfo {
  title: string;
  pageNum: number;
  child: PdfCatalogueInfo[];
  bbox?: PdfBBox | undefined;
}

export interface GetCatalogueResponse {
  needFetch: boolean;
  pdfCatalogue?: PdfCatalogueInfo | undefined;
}

export interface PdfRefRematchReq {
  rawStrings: string[];
}

export interface PdfRefRematchResp {
  statusCode: number;
  errMsg: string;
  paperids: string[];
}
