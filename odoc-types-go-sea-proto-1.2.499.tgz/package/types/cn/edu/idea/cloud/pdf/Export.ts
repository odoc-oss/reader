/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.pdf";

/**
 * 获取PDF导出功能开关
 * url: /pdfApi/export/enable
 * method: GET
 */
export interface ExportPdfEnableRequest {
}

export interface ExportPdfEnableResponse {
  enable: boolean;
}

/**
 * 获取PDF导出连接
 * url: /micrgo-pdf/export
 * method: GET
 */
export interface ExportPdfRequest {
  noteId: string;
}

export interface ExportPdfResponse {
  needFetch: boolean;
  url?: string | undefined;
}

/**
 * PDF导出限频计数
 * url: /micrgo-pdf/export/countIncr
 * method: POST
 */
export interface ExportCountIncrRequest {
}

/** empty */
export interface ExportCountIncrResponse {
}
