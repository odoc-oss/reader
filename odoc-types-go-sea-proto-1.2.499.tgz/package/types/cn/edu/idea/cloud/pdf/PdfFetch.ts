/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.pdf";

export enum FetchPdfTaskStatus {
  NO_TASK = 0,
  WAITING = 1,
  RUNNING = 2,
  FINISH = 3,
  ERROR = 4,
  UNRECOGNIZED = -1,
}

export interface PdfFetchTask {
  paperId: string;
  pdfId: string;
  paperTitle: string;
  paperAbstract: string;
  status: FetchPdfTaskStatus;
  failReason: string;
}

/**
 * 【PDF外部拉取】 从arxiv上下载PDF
 * url: /pdfApi/fetch/fetchFromArxiv
 * method: POST
 */
export interface FetchPdfFromArxivRequest {
  paperId: string;
}

/** 响应 */
export interface FetchPdfFromArxivResponse {
  taskStatus: FetchPdfTaskStatus;
  pdfId: string;
  failReason: string;
}
