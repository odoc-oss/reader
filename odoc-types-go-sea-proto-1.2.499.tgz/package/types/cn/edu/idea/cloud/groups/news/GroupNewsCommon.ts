/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.groups.news";

export enum GroupNewsType {
  /** GROUP_ADD_NOTE - 小组-添加笔记 */
  GROUP_ADD_NOTE = 0,
  /** GROUP_REPLY_NOTE - 小组-回复笔记 */
  GROUP_REPLY_NOTE = 1,
  /** GROUP_ADD_QUSTION - 小组-提问 */
  GROUP_ADD_QUSTION = 2,
  /** GROUP_ADD_ANSWER - 小组-回答 */
  GROUP_ADD_ANSWER = 3,
  /** GROUP_SHARE_PAPER - 小组-分享笔记 */
  GROUP_SHARE_PAPER = 4,
  /** GROUP_UPDATE_PAPER_VERSION - 小组-更新版本 */
  GROUP_UPDATE_PAPER_VERSION = 5,
  /** GROUP_JOIN - 小组-加入小组 */
  GROUP_JOIN = 6,
  /** GROUP_QUIT - 小组-退出小组 */
  GROUP_QUIT = 7,
  /** GROUP_UPDATE_NOTICE - 小组-更新公告 */
  GROUP_UPDATE_NOTICE = 8,
  UNRECOGNIZED = -1,
}

/** 小组动态数据流字段 */
export interface BaseNews {
  /** 用户ID */
  userId: string;
  /** 用户昵称 */
  nickName: string;
  /** 用户头像 */
  avatarUrl: string;
  /** 用户标签 */
  tags: string;
  /** 动态产生时间 */
  newsCreateDate: string;
  /** 推荐类型 */
  newsType: GroupNewsType;
  /** 组内角色 */
  groupAuth: number;
}

export interface GroupNote {
  /** 论文ID */
  paperId: string;
  /** 论文标题 */
  paperTitle: string;
  /** pdfId */
  pdfId: string;
  /** 笔记内容 */
  noteContent: string;
  /** markId */
  markId: string;
}

export interface GroupAddNote {
  addNote?: GroupNote | undefined;
}

export interface GroupReplyNote {
  /** 回复笔记 */
  replyNote?:
    | GroupNote
    | undefined;
  /** 被回复的笔记id */
  replyId: string;
  /** 回复内容 */
  replyContent: string;
}

export interface GroupQuestion {
  questionId: string;
  questionTitle: string;
}

export interface GroupAddQuestion {
  question?: GroupQuestion | undefined;
  paperId: string;
  paperTitle: string;
}

export interface GroupAddAnswer {
  question?: GroupQuestion | undefined;
  answerId: string;
  answerContent: string;
}

export interface GroupSharePaper {
  /** 论文ID */
  paperId: string;
  /** 论文标题 */
  paperTitle: string;
  /** pdfId */
  pdfId: string;
}

export interface GroupUpdatePaperVersion {
  /** 论文ID */
  paperId: string;
  /** 论文标题 */
  paperTitle: string;
  /** pdfId */
  pdfId: string;
}

export interface GroupJoin {
  /** 为true时，表示有数据 */
  isJoin: boolean;
}

export interface GroupQuit {
  /** 为true时，表示有数据 */
  isQuit: boolean;
}

export interface GroupUpdateNotice {
  /** 更新公告内容 */
  noticeContent: string;
}
