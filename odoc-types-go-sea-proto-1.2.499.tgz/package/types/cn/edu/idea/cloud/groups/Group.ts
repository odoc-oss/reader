/* eslint-disable */
import type { UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.groups";

/** /personal/userCenter/getFollowSomeoneFlag */
export interface GetFollowSomeoneFlagRequest {
  relationId: string;
}

export interface GetFollowSomeoneFlagResponse {
  status: number;
  message: string;
  /** 是否关注 */
  data: boolean;
}

/**
 * 获取入群申请待审批数量
 * url: /groupJoinApply/getUnApprovalJoinGroupApplyCountByGroupId
 */
export interface GetUnApprovalJoinGroupApplyCountByGroupIdRequest {
  groupId: string;
}

export interface GetUnApprovalJoinGroupApplyCountByGroupIdResponse {
  status: number;
  message: string;
  data: number;
}

/**
 * 获取待审批的入群申请列表
 * url: /groupJoinApply/getUnApprovalJoinGroupApplyListByGroupId
 */
export interface GetUnApprovalJoinGroupApplyListByGroupIdRequest {
  groupId: string;
  currentPage: number;
  pageSize: number;
}

export interface GetUnApprovalJoinGroupApplyListByGroupIdResponse {
  total: number;
  list: JoinGroupApplyBaseInfo[];
}

export interface JoinGroupApplyBaseInfo {
  groupId: string;
  inviterId: string;
  applicantInfo?: UserInfoBean | undefined;
  inviterInfo?: UserInfoBean | undefined;
  groupName: string;
  reason: string;
}

/**
 * 获取问题列表
 * url: /groupDiscuss/getAnswerListByQuestionId
 */
export interface GetAnswerListByQuestionIdRequest {
  questionId: string;
}

export interface GetAnswerListByQuestionIdResponse {
  status: number;
  message: string;
  data: AnswerListItem[];
}

export interface AnswerListItem {
  answerId: string;
  content: string;
  createDate: string;
  answerAuthor?: UserInfoBean | undefined;
}
