/* eslint-disable */
import type { UserInfoBean } from "../../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.groups.question";

/**
 * 根据questionId获取问题
 * URL:/groupDiscuss/getQuestionById
 * method: GET
 * content-type: application/json
 */
export interface GetQuestionByIdReq {
  questionId: string;
}

export interface GetQuestionByIdResp {
  groupId: string;
  paperId: string;
  content: string;
  paperTitle: string;
  replyCount: string;
  userInfo?: UserInfoBean | undefined;
  createDate: string;
}
