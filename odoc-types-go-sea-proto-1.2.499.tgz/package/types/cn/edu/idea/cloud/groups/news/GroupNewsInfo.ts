/* eslint-disable */
import type {
  BaseNews,
  GroupAddAnswer,
  GroupAddNote,
  GroupAddQuestion,
  GroupJoin,
  GroupQuit,
  GroupReplyNote,
  GroupSharePaper,
  GroupUpdateNotice,
  GroupUpdatePaperVersion,
} from "./GroupNewsCommon";

export const protobufPackage = "cn.edu.idea.cloud.groups.news";

/**
 * 获取动态列表
 * URL:/group/news/list
 * method: GET
 * content-type: application/json
 */
export interface GetGroupNewsListReq {
  groupId: string;
  currentPage: number;
}

export interface GetGroupNewsListResp {
  feed: Feed[];
  /** 是否已到底 */
  isEnd: boolean;
}

export interface Feed {
  baseNews?: BaseNews | undefined;
  groupAddNote?: GroupAddNote | undefined;
  groupReplyNote?: GroupReplyNote | undefined;
  groupAddQuestion?: GroupAddQuestion | undefined;
  groupAddAnswer?: GroupAddAnswer | undefined;
  groupSharePaper?: GroupSharePaper | undefined;
  groupUpdatePaperVersion?: GroupUpdatePaperVersion | undefined;
  groupJoin?: GroupJoin | undefined;
  groupQuit?: GroupQuit | undefined;
  groupUpdateNotice?: GroupUpdateNotice | undefined;
}

/**
 * 是否有新通知
 * URL:/group/news/hasNotice
 * method: GET
 * content-type: application/json
 */
export interface GetHasNewsReq {
  groupId: string;
}

export interface GetHasNewsResp {
  /** 通知数量 */
  noticeAmount: number;
}

/**
 * 清除通知
 * URL:/group/news/clearNotice
 * method: POST
 * content-type: application/json
 */
export interface ClearNoticeReq {
  groupId: string;
}

export interface ClearNoticeResp {
}
