/* eslint-disable */
import type { UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.groups";

/**
 * 新增文献
 * url: /groupDoc/addGroupDoc
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1219
 */
export interface AddGroupDocRequest {
  /** 论文id */
  paperId: string;
  groupId: string;
}

/**
 * 删除文献
 * url: /groupDoc/deleteGroupDoc
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1223
 */
export interface DeleteGroupDocRequest {
  docIdList: string[];
}

/**
 * 小组文献分类列表
 * url: /groupDoc/getGroupDocClassifyList
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1275
 */
export interface GetGroupDocClassifyListRequest {
  groupId: string;
}

export interface GetGroupDocClassifyListResponse {
  status: number;
  message: string;
  data: DocClassifyInfo[];
}

export interface DocClassifyInfo {
  classifyId: string;
  classifyName: string;
}

/**
 * 小组文献列表
 * url: /groupDoc/getGroupDocClassifyList
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1275
 */
export interface GetGroupDocListRequest {
  groupId: string;
  currentPage: number;
  pageSize: number;
}

export interface GetGroupDocListResponse {
  total: number;
  list: GroupDocInfo[];
}

export interface GroupDocInfo {
  docId: string;
  paperId: string;
  collectCount: number;
  noteCount: number;
  qaCount: number;
  contributorInfo?: UserInfoBean | undefined;
  remark: string;
  docName: string;
  authorList: AuthorInfo[];
  /** 当前用户能看到的pdfId */
  pdfId: string;
  /** 是否存在公开pdf */
  hasPublicPdf: boolean;
  /** 是否存在私密pdf */
  hasPrivatePdf: boolean;
  groupId: string;
  classifyId: string;
  paperRepositoryStatus: string;
  /** 群组讨论数 */
  groupDiscussCount: string;
  groupPdfId?: string | undefined;
}

export interface AuthorInfo {
  id: string;
  name: string;
}

/**
 * 保存分类
 * url: /groupDoc/addGroupDocClassify
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1235
 */
export interface AddGroupDocClassifyRequest {
  groupId: string;
  classifyName: string;
}

/**
 * 更新分类
 * url: /groupDoc/updateGroupDocClassify
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1239
 */
export interface UpdateGroupDocClassifyRequest {
  classifyId: string;
  classifyName: string;
}

/**
 * 删除分类
 * url: /groupDoc/deleteGroupDocClassify
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1243
 */
export interface DeleteGroupDocClassifyRequest {
  classifyId: string;
}

/**
 * 更新文献备注
 * url: /groupDoc/updateGroupDocRemark
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1231
 */
export interface UpdateGroupDocRemarkRequest {
  docId: string;
  remark: string;
}

/**
 * 文献关联分类
 * url: /groupDoc/attachGroupDocToClassify
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1247
 */
export interface AttachGroupDocToClassifyRequest {
  docIdList: string[];
  groupId: string;
  classifyIds: string[];
}

/**
 * 论文或Pdf关联分类
 * url: /groupDoc/attachPaperOrPdfToClassify
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1255
 */
export interface AttachPaperOrPdfToClassifyRequest {
  paperId: string;
  pdfId: string;
  groupId: string;
  classifyId: string;
}

/**
 * 删除文献的分类
 * url: /groupDoc/removeGroupDocFromClassify
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1259
 */
export interface RemoveGroupDocFromClassifyRequest {
  docIdList: string[];
  groupId: string;
  classifyId: string;
}

/**
 * 已分类的文献标签详情页
 * url: /groupDoc/getGroupDocListByClassifyId
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1251
 */
export interface GetGroupDocListByClassifyIdRequest {
  classifyId: string;
  groupId: string;
  currentPage: number;
  pageSize: number;
}

export interface GetGroupDocListByClassifyIdResponse {
  total: number;
  list: GroupDocInfo[];
}

/**
 * 获取问题列表
 * url: /groupDiscuss/getQuestionList
 */
export interface GetQuestionListRequest {
  groupId: string;
  currentPage: number;
  pageSize: number;
}

export interface GetQuestionListResponse {
  total: number;
  list: QuestionInfo[];
}

export interface QuestionInfo {
  questionId: string;
  paperId: string;
  questionTitle: string;
  paperTitle: string;
  replyCount: number;
  createDate: string;
  userInfo?: UserInfoBean | undefined;
}

/**
 * 新增提问
 * url: /groupDiscuss/addQuestion
 */
export interface AddQuestionRequest {
  /** 论文id */
  paperId: string;
  groupId: string;
  content: string;
}

/**
 * 删除提问
 * url: /groupDiscuss/deleteQuestion
 */
export interface DeleteQuestionRequest {
  questionId: string;
}

/**
 * 新增回答
 * url: /groupDiscuss/addAnswer
 */
export interface AddAnswerRequest {
  questionId: string;
  groupId: string;
  content: string;
}

/**
 * 删除回答
 * url: /groupDiscuss/deleteAnswer
 */
export interface DeleteAnswerRequest {
  answerId: string;
}

/**
 * 记录阅读上传协议状态
 * url: /groupDoc/recordReadUploadProtocolStatus
 */
export interface RecordReadUploadProtocolStatusRequest {
}

/**
 * 获取阅读上传协议状态
 * url: /groupDoc/getReadUploadProtocolStatus
 */
export interface GetReadUploadProtocolStatusRequest {
}

export interface GetReadUploadProtocolStatusResponse {
  status: number;
  message: string;
  data: boolean;
}
