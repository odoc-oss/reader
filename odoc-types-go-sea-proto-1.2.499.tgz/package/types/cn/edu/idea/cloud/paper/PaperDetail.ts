/* eslint-disable */
import type { BaseAuthorInfo } from "../author/AuthorInfo";
import type { UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.paper";

export enum ReadStatusEnum {
  READABLE_PUBLIC = 0,
  READABLE_PRIVATE = 1,
  UNREADABLE = 2,
  UNRECOGNIZED = -1,
}

export enum TranslationSourceEnum {
  /** MANUAL - 人工翻译 */
  MANUAL = 0,
  /** YOUDAO - 有道翻译 */
  YOUDAO = 1,
  UNRECOGNIZED = -1,
}

/**
 * 论文详情页-获取论文信息
 * url: /aiKnowledge/paper/getPaperDetailInfo
 */
export interface GetPaperDetailInfoRequest {
  /** 论文id */
  paperId: string;
}

export interface GetPaperDetailInfoResponse {
  paperId: string;
  title: string;
  /** 发布日期 */
  publishDate: string;
  /** 原文摘要 */
  originalAbstract: string;
  /** 引用数(参考文献数) */
  referenceCount: number;
  /** 被引用数 */
  citationCount: number;
  /** 笔记数 */
  noteCount: number;
  /** 问答数 */
  questionAnswerCount: number;
  pdfId: string;
  /** 是否已经收藏了该论文 */
  isCollected: boolean;
  /** 作者信息 */
  authorList: BaseAuthorInfo[];
  /** 论文标签 */
  paperTagList: PaperTagInfo[];
  /** 摘要信息 */
  abstractTranslationInfo?:
    | AbstractTranslationInfo
    | undefined;
  /** 论文精读 */
  paperResources: PaperResourceInfo[];
  /** 相关url列表 */
  relatedUrls: string[];
  /** 是否展示论文详情页 */
  showPaperDetail: boolean;
  /** 论文DOI */
  doi: string;
  /** 期刊会议(新) */
  venues: string[];
  primaryVenue: string;
  paperUrlList: PaperUrlsBean[];
  readStatus: ReadStatusEnum;
  venueTags: string[];
  machineTranslationInfo?: MachineTranslationInfo | undefined;
  userDocId: string;
  showMachineTranslationButton: boolean;
}

export interface MachineTranslationInfo {
  translationSource: TranslationSourceEnum;
  translation: string;
}

export interface PaperUrlsBean {
  url: string;
  publishDate: string;
  venue: string;
}

/**
 * 论文详情页-获取速读十问信息
 * url: /aiKnowledge/paper/getFastReadingQuestionInfo
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/963
 */
export interface GetFastReadingQuestionInfoRequest {
  /** 论文id */
  paperId: string;
}

export interface GetFastReadingQuestionInfoResponse {
  /** 该十问回答者信息 */
  userInfo?:
    | UserInfoBean
    | undefined;
  /** 该十问回答对应的noteId */
  noteId: string;
  /** 是否有十问的回答 */
  hasAnswerFlag: boolean;
  /** 十问信息 */
  fastReadingQuestionInfo: FastReadingQuestionInfo[];
}

/**
 * 论文详情页-获取我的学习任务信息
 * url: /aiKnowledge/paper/getMyLearningTaskInfo
 */
export interface GetMyLearningTaskInfoRequest {
  /** 论文id */
  paperId: string;
}

export interface GetMyLearningTaskInfoResponse {
  /** 十问信息 */
  qaInfo: FastReadingQuestionInfo[];
  translationInfo?: BaseTranslationInfo | undefined;
}

/** 论文标签 */
export interface PaperTagInfo {
  id: string;
  name: string;
}

/** 详情页摘要翻译信息 */
export interface AbstractTranslationInfo {
  /** 该翻译的作者信息 */
  bestAbsAuthor?:
    | UserInfoBean
    | undefined;
  /** 翻译内容 */
  bestAbsContent: string;
  /** 该论文摘要翻译总数 */
  totalCount: number;
  /** 该翻译对应的笔记id */
  noteId: string;
}

/** 详情页摘要翻译信息 */
export interface BaseTranslationInfo {
  translationId: string;
  translation: string;
  originalAbstract: string;
}

/** 速读十问信息 */
export interface FastReadingQuestionInfo {
  /** 问题id */
  questionId: string;
  /** questionTitle */
  questionTitle: string;
  /** questionContent */
  questionContent: string;
  /** answer */
  answer: string;
  /** htmlAnswer */
  htmlAnswer: string;
  /** 回答id */
  answerId: string;
  /** 回答数 */
  answerCount: number;
}

/** 论文精读Resource */
export interface PaperResourceInfo {
  resourceUrl: string;
  resourceTitle: string;
}
