/* eslint-disable */
import type { UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.paper";

/**
 * 新增推荐论文集
 * url: /admin/recommendedPaperCollection/addRecommendedPaperCollection
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1119
 */
export interface AddRecommendedPaperCollectionRequest {
  /** 论文集id */
  classifyId: string;
  /** 栏目名称 */
  columnName: string;
}

/**
 * 更新推荐的论文集
 * url: /admin/recommendedPaperCollection/updateRecommendedPaperCollection
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1123
 */
export interface UpdateRecommendedPaperCollectionRequest {
  /** 论文集id */
  classifyId: string;
  /** 栏目名称 */
  columnName: string;
  /** 需要更新的id */
  id: string;
}

/**
 * 更新推荐的论文集
 * url: /admin/recommendedPaperCollection/removeRecommendedPaperCollection
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1127
 */
export interface RemoveRecommendedPaperCollectionRequest {
  id: string;
}

/**
 * 改变排序
 * url: /admin/recommendedPaperCollection/changeSort
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1131
 */
export interface ChangeNoteSortRequest {
  /** 论文id */
  id1: string;
  sort1: number;
  id2: string;
  sort2: string;
}

/**
 * 管理后台-获取推荐论文集列表
 * url: /admin/recommendedPaperCollection/getRecommendedPaperCollectionList
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1135
 */
export interface GetRecommendedPaperCollectionListRequest {
  /** 论文集id */
  classifyId: string;
  /** 栏目名称 */
  columnName: string;
  currentPage: number;
  pageSize: number;
}

export interface GetRecommendedPaperCollectionListResponse {
  total: number;
  list: RecommendedPaperCollectionItem[];
}

/**
 * 首页-获取推荐论文集
 * url: /aiKnowledge/getRecommendedPaperCollection
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1139
 */
export interface GetRecommendedPaperCollectionRequest {
}

export interface GetRecommendedPaperCollectionResponse {
  status: number;
  message: string;
  data: RecommendedPaperCollectionColumnItem[];
}

export interface RecommendedPaperCollectionColumnItem {
  columnName: string;
  items: RecommendedPaperCollectionItem[];
}

export interface RecommendedPaperCollectionItem {
  classifyName: string;
  classifyId: string;
  count: number;
  ownerInfo?: UserInfoBean | undefined;
  columnName: string;
  sort: number;
}
