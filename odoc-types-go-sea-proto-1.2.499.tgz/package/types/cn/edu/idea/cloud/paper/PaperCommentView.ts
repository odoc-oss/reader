/* eslint-disable */
import type { CommentatorInfoView } from "../aiKnowledge/notev2/Common";

export const protobufPackage = "cn.edu.idea.cloud.paper";

export enum PaperCommentLevel {
  HIGHLY_RECOMMEND = 0,
  RECOMMEND = 1,
  ACCEPT = 2,
  REJECT = 3,
  STRONG_REJECT = 4,
  UNRECOGNIZED = -1,
}

/** 论文评价的维度 */
export enum PaperCommentDimension {
  /** INNOVATION - 创新性 */
  INNOVATION = 0,
  /** CONSCIENTIOUSNESS - 严谨性 */
  CONSCIENTIOUSNESS = 1,
  /** LOGIC - 条理性 */
  LOGIC = 2,
  /** REPRODUCIBILITY - 复现性 */
  REPRODUCIBILITY = 3,
  UNRECOGNIZED = -1,
}

export enum SortType {
  DEFAULT = 0,
  MOST_ACCEPT = 1,
  LASTEST = 2,
  UNRECOGNIZED = -1,
}

export enum ApproveStatus {
  APPROVE = 0,
  CANCEL_APPROVE = 1,
  UNRECOGNIZED = -1,
}

/**
 * /paper/comment
 * POST
 */
export interface PaperCommentCreateReq {
  paperCommentLevel: PaperCommentLevel;
  paperCommentContent: string;
  /** 是否匿名 */
  anonymous: boolean;
  paperCommentDimensions: PaperCommentDimensionWithScore[];
  paperId: string;
}

export interface PaperCommentCreateRsp {
  paperCommentId: string;
}

/**
 * /paper/comment
 * PUT
 * 返回通用的状态码
 */
export interface PaperCommentUpdateReq {
  paperCommentLevel: PaperCommentLevel;
  paperCommentContent: string;
  /** 是否匿名 */
  anonymous: boolean;
  paperCommentDimensions: PaperCommentDimensionWithScore[];
  paperId: string;
  paperCommentId: string;
}

/**
 * /paper/comment
 * DELETE
 * 返回通用的状态码
 */
export interface PaperCommentDeleteReq {
  paperCommentId: string;
}

/**
 * /paper/comment/approve
 * POST
 * 赞同
 * 返回通用的状态码
 */
export interface PaperCommentApproveReq {
  paperCommentId: string;
}

/**
 * /paper/comment/approve/cancel
 * POST
 * 取消赞同
 * 返回通用的状态码
 */
export interface PaperCommentCancelApproveReq {
  paperCommentId: string;
}

/**
 * /admin/flag
 * GET
 */
export interface AdminStatusRsp {
  isAdmin: boolean;
}

/**
 * /authority/paper/comment
 * DELETE
 * 返回通用的状态码
 */
export interface AdminPaperCommentDeleteReq {
  paperCommentId: string;
  userId: string;
}

/**
 * /authority/paper/comment
 * PUT
 * 返回通用的状态码
 * 置顶 sort =100 ，取消置顶 sort=0
 */
export interface AdminPaperCommentUpdateReq {
  paperCommentId: string;
  userId: string;
  sort: number;
}

/**
 * /aiKnowledge/paper/comment/aggregation
 * GET
 */
export interface PaperCommentAggregationReq {
  paperId: string;
}

export interface PaperCommentAggregationRsp {
  paperCommentDistributions: PaperCommentLevelDistribution[];
  paperCommentDimensionAverageScores: PaperCommentDimensionWithScore[];
  myPaperComment?:
    | PaperCommentContent
    | undefined;
  /** 多维评论数 */
  paperCommentDimensionCount: string;
}

/**
 * /aiKnowledge/paper/comments
 * 参数paperId , pageNumber, size , SortType
 * 仅支持GET
 */
export interface PaperCommentsReq {
  paperId: string;
  pageNumber: number;
  size: number;
  sortType: SortType;
}

export interface PaperCommentsRsp {
  paperCommentContents: PaperCommentContent[];
  /** 返回总量 */
  totalSize: number;
}

/**
 * /aiKnowledge/paper/getPaperDetailInfo
 * 论文详情页
 */
export interface PaperDetaiRsp {
  /** 被同行评论的数量 */
  paperCommentedCount: number;
}

/** /messageCenter/msgList */
export interface PaperCommentMessage {
  paperCommentContent?: PaperCommentContent | undefined;
  paperTitle: string;
  /** type =100 */
  type: number;
}

export interface PaperCommentContent {
  paperCommentId: string;
  commentContent: string;
  commentatorInfoView?: CommentatorInfoView | undefined;
  commentApprovedCount: number;
  approvedByMe: boolean;
  paperCommentLevel: PaperCommentLevel;
  paperCommentDimensionScore: PaperCommentDimensionWithScore[];
  /** 是否匿名 */
  anonymous: boolean;
  /** 人工干预的排序顺序 */
  sort: number;
  /** 时间戳 */
  timestap: string;
}

export interface PaperCommentLevelDistribution {
  paperCommentLevel: PaperCommentLevel;
  counts: number;
}

export interface PaperCommentDimensionWithScore {
  paperCommentDimension: PaperCommentDimension;
  /** -1表示是无效值 */
  score: number;
}
