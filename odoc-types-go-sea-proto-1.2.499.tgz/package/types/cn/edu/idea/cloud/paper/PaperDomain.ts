/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.paper";

/** 论文领域错误码，范围：10001-19999 */
export enum ErrorCode {
  SUCCESS = 0,
  /** ADD_QUESTION_NOT_SAFE - 提问内容无法通过文本检查 */
  ADD_QUESTION_NOT_SAFE = 10001,
  /** QUESTION_SAVE_FAIL - 提问保存失败 */
  QUESTION_SAVE_FAIL = 10002,
  /** ERR_UNKNOW - ErrorCode end, do not edit below area */
  ERR_UNKNOW = 20000,
  UNRECOGNIZED = -1,
}
