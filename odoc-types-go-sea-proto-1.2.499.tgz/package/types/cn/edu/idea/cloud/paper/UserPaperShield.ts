/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.paper";

/**
 * 新增屏蔽论文
 * url: /userPaperShield/addUserPaperShield
 */
export interface AddUserPaperShieldRequest {
  /** 论文id */
  paperId: string;
}

/**
 * 删除屏蔽论文
 * url: /userPaperShield/deleteUserPaperShield
 */
export interface DeleteUserPaperShieldRequest {
  paperId: string;
}

/**
 * 获取屏蔽论文列表
 * url: /userPaperShield/getUserPaperShieldList
 */
export interface GetUserPaperShieldListRequest {
  pageSize: number;
  currentPage: number;
}

export interface GetUserPaperShieldListResponse {
  total: number;
  list: UserPaperShieldInfo[];
}

export interface UserPaperShieldInfo {
  paperId: string;
  paperTitle: string;
}
