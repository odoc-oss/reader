/* eslint-disable */
import type { CommonUserInfo, UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.paper";

/** 添加论文提问 url=/aiKnowledge/paper/qa/addQuestion */
export interface AddPaperQuestionRequest {
  paperId: string;
  pdfId: string;
  content: string;
}

export interface AddPaperQuestionResponse {
}

/** 获取提问列表 url=/aiKnowledge/paper/qa/queryPaperQuestion */
export interface PaperQuestion {
  questionId: string;
  title: string;
  userInfo?: CommonUserInfo | undefined;
  viewCount: number;
  replyCount: number;
  createDate: string;
  answerList: PaperAnswer[];
}

export interface QueryPaperQuestionRequest {
  paperId: string;
}

export interface QueryPaperQuestionResponse {
  questions: PaperQuestion[];
}

/** 删除提问 url=/aiKnowledge/paper/qa/deleteQuestion */
export interface DeletePaperQuestionRequest {
  questionId: string;
}

export interface DeletePaperQuestionResponse {
}

/** 对问题进行回答 url=/aiKnowledge/paper/qa/addAnswer */
export interface AddPaperAnswerRequest {
  questionId: string;
  content: string;
  replyAnswerId: string;
}

export interface AddPaperAnswerResponse {
}

/** 获取回答列表 url=/aiKnowledge/paper/qa/queryPaperAnswer */
export interface PaperAnswer {
  answerId: string;
  answerAuthor?: UserInfoBean | undefined;
  replyUser?: UserInfoBean | undefined;
  content: string;
  createDate: string;
}

export interface QueryPaperAnswerRequest {
  questionId: string;
}

export interface QueryPaperAnswerResponse {
  answers: PaperAnswer[];
  total: number;
}

/** 删除回答 url=/aiKnowledge/paper/qa/deleteAnswer */
export interface DeletePaperAnswerRequest {
  answerId: string;
}

export interface DeletePaperAnswerResponse {
}

/** /aiKnowledge/paper/qa/getUserQuestion */
export interface GetUserQuestionRequest {
  ownerId: string;
  currentPage: number;
  pageSize: number;
}

export interface GetUserQuestionResponse {
  total: number;
  items: UserQuestionItem[];
  ownerInfo?: UserInfoBean | undefined;
}

export interface UserQuestionItem {
  questionId: string;
  paperId: string;
  answerCount: string;
  paperTitle: string;
  questionContent: string;
}

/** /aiKnowledge/paper/qa/getUserAnswer */
export interface GetUserAnswerRequest {
  ownerId: string;
  currentPage: number;
  pageSize: number;
}

export interface GetUserAnswerResponse {
  total: number;
  items: UserAnswerItem[];
  ownerInfo?: UserInfoBean | undefined;
}

export interface UserAnswerItem {
  paperId: string;
  questionId: string;
  answerId: string;
  questionContent: string;
  answerContent: string;
}
