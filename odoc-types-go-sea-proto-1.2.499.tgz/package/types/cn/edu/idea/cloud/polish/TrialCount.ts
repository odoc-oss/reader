/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.polish";

export enum TrialFeature {
  POLISH_REWRITE = 0,
  ZH_TO_EN_TRANSLATION = 1,
  ZH_POLISH_REWRITE = 2,
  AI_TRANSLATE = 3,
  UNRECOGNIZED = -1,
}

/**
 * 获取试用功能及次数
 * url: /trial/count/
 * method: GET
 * server-id: microService-aiPolish
 */
export interface TrialCountResponse {
  trialFeatureAndCounts: TrailFeatureAndCount[];
}

/**
 * 获取试用功能是否开启
 * url: /trial/isEnabled
 * method: GET
 * server-id: microService-aiPolish
 */
export interface TrialIsEnabledReq {
  feature: TrialFeature;
}

export interface TrialIsEnabledResponse {
  enabled: boolean;
}

export interface TrailFeatureAndCount {
  feature: TrialFeature;
  trialCount: number;
}
