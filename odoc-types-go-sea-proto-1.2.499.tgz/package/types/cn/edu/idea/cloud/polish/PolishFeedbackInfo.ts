/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.polish";

export enum BizType {
  /** AI_POLISH - 润色改写、ai改写 */
  AI_POLISH = 0,
  /** AI_REVIEW - 30豆 */
  AI_REVIEW = 1,
  TITLE_GENERATION = 2,
  ABSTRACT_GENERATION = 3,
  ABSTRACT_TRUING_FRAMEWORK = 4,
  ABSTRACT_REWRITE = 5,
  /** ZH_TRANSLATION - 中译英 */
  ZH_TRANSLATION = 6,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: polish信用退豆
 * 	接口url: /refund/aibean
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  service-id: microService-aiPolish
 */
export interface RefundAiBeanReq {
  /** 理由 */
  reason: string[];
  /** 补充说明 */
  supplementaryExplanation?:
    | string
    | undefined;
  /** 截图 */
  screenshotUrl?:
    | string
    | undefined;
  /** 任务id */
  taskId: string;
  /** 退豆类型 */
  bizType: BizType;
}

export interface RefundAiBeanResp {
}
