/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.user";

/** 工作流认证状态 */
export enum VerifyWorkFlowStatus {
  /** IS_COMPLETED - 已完成认证 */
  IS_COMPLETED = 0,
  /** NO_VERIFY - 未完成认证 */
  NO_VERIFY = 1,
  /** IS_APPROVING - 审批中 */
  IS_APPROVING = 2,
  UNRECOGNIZED = -1,
}

/** 工作流流程步骤 */
export enum VerifyWorkFlowStepEnum {
  WORKFLOW_STEP_AUTH_NOTIFICATION = 0,
  WORKFLOW_STEP_COMPLETION = 1,
  WORKFLOW_STEP_VERIFY = 2,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 获取所有的场景
 * 	接口url:/personalVerifyConfig/getAllScene
 * 	接口请求方式: get
 */
export interface GetAllSceneReq {
}

export interface GetAllSceneResp {
  scene: VerifyScene[];
}

export interface VerifyScene {
  sceneId: string;
  sceneName: string;
}

/**
 * 接口描述: 获取场景Id获取流程步骤信息/表单信息
 * 	接口url:/personalVerifyConfig/getBySceneId
 * 	接口请求方式: get
 */
export interface GetBySceneIdReq {
  sceneId: string;
}

export interface GetBySceneIdResp {
  scene?: VerifyScene | undefined;
  verifyWorkFlowStep: VerifyWorkFlowStep[];
}

/** 认证流程步骤 */
export interface VerifyWorkFlowStep {
  stepId: string;
  name: string;
  VerifyScene: VerifyWorkFlowStatus;
  formItemConfig: FormItemConfig[];
}

/** 表单配置 */
export interface FormItemConfig {
  formId: string;
  name: string;
  attributeName: string;
  required: boolean;
  placeholder: string;
  validRule: string;
  formType: string;
  selectItems: FormSelectItem[];
  value: string;
}

/** 表单选项 */
export interface FormSelectItem {
  idName: string;
  name: string;
}
