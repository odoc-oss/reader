/* eslint-disable */
import type { ExtUserInfo } from "../aiKnowledge/ModifyUserInfo";
import type { UploadBizScene } from "../oss/AliOSS";
import type { AuthMaterialStatus } from "./PersonalInfoAuthEnum";

export const protobufPackage = "cn.edu.idea.cloud.user";

/**
 * 个人资料补齐
 * /personalInfoAuth/addExtUserInfoReq
 * service: microService-app-aiKnowledge
 * POST
 */
export interface AddExtUserInfoReq {
  /** 手机【通过RSA加密传输】 */
  mobile: string;
  /** 验证码 */
  valiCode: string;
  /** 用户扩展信息 */
  extUserInfo?:
    | ExtUserInfo
    | undefined;
  /** 场景，每个场景所需要的表单都不一样 */
  sceneId: string;
}

export interface AddExtUserInfoResp {
}

/**
 * 接口描述: 获取上传到阿里云OSS所需的policy和Callback等信息
 * 	接口url:/microservice-oss/oss/upload/acquirePolicyCallbackInfo
 * 	接口请求方式: GET
 */
export interface AcquirePolicyCallbackInfoReq {
  scene?: UploadBizScene | undefined;
}

export interface AcquirePolicyCallbackInfoResponse {
  accessid: string;
  callback: string;
  dir: string;
  expire: string;
  host: string;
  policy: string;
  signature: string;
}

/** 上传完成返回的结构,需要将此信息传给业务系统 */
export interface UploadResult {
  isSuccess: boolean;
  fileName?: string | undefined;
  bucketName?: string | undefined;
  mimeType?: string | undefined;
}

/**
 * 接口描述: 提交个人信息认证材料
 * 	接口url:/microService-app-aiKnowledge/personalInfoAuth/submitPersonalInfoAuthMaterial
 * 	接口请求方式: POST
 */
export interface SubmitPersonalInfoAuthMaterialReq {
  bucketName: string;
  fileName: string;
  mimeType: string;
  materialSourcePageUrl?: string | undefined;
}

export interface SubmitPersonalInfoAuthMaterialResponse {
  data: string;
  status: number;
  message: string;
}

/**
 * 接口描述: 给教育邮箱发送验证码
 * 	接口url:/microService-app-aiKnowledge/personalInfoAuth/sendEduEmailVerificationCode
 * 	接口请求方式: POST
 */
export interface SendEduEmailVerificationCodeReq {
  eduMail: string;
}

export interface SendEduEmailVerificationCodeResponse {
}

/**
 * 接口描述: 验证教育邮箱验证码
 * 	接口url:/microService-app-aiKnowledge/personalInfoAuth/verifyEduEmailVerificationCode
 * 	接口请求方式: POST
 */
export interface VerifyEduEmailVerificationCodeReq {
  verificationCode: string;
  eduMail: string;
}

export interface VerifyEduEmailVerificationCodeResponse {
  /** 验证是否通过 */
  data: boolean;
  status: number;
  message: string;
}

/**
 * 接口描述: 个人信息认证材料列表
 * 	接口url:/microService-app-aiKnowledge/personalInfoAuth/personalInfoAuthMaterialList
 * 	接口请求方式: POST
 */
export interface PersonalInfoAuthMaterialListReq {
  uin: string;
  unit: string;
  pageSize: number;
  currentPage: number;
}

export interface PersonalInfoAuthMaterialListResponse {
  total: number;
  list: AuthMaterialInfo[];
}

export interface AuthMaterialInfo {
  createDate: string;
  userId: string;
  unit?: string | undefined;
  authMaterialUrl?: string | undefined;
  authMaterialFileName?: string | undefined;
  authMaterialStatus?: AuthMaterialStatus | undefined;
  authMaterialPassTime?: string | undefined;
  mimeType?: string | undefined;
}

/**
 * 接口描述: 通过认证材料
 * 	接口url:/microService-app-aiKnowledge/personalInfoAuth/passAuthMaterial
 * 	接口请求方式: POST
 */
export interface PassAuthMaterialReq {
  userId: string;
}

/**
 * 接口描述: 驳回认证材料
 * 	接口url:/microService-app-aiKnowledge/personalInfoAuth/rejectAuthMaterial
 * 	接口请求方式: POST
 */
export interface RejectAuthMaterialReq {
  userId: string;
}
