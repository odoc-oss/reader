/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.user.cancel";

/**
 * 接口描述: 通过邮件注销账户，第一步：发送验证邮件
 *  接口url: /personal/user/setting/sendCancelMailValiCode
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface EmailCancelReq {
}

export interface EmailCancelResp {
}

/**
 * 接口描述: 通过邮件注销账户，第二步：验证验证码
 *  接口url: /personal/user/setting/checkCancelMail
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface EmailCheckCancelReq {
  /** vali code */
  valiCode: string;
}

export interface EmailCheckCancelResp {
}

/**
 * 接口描述: 通过邮件注销账户，第三步：验证后完成注销
 *  接口url: /personal/user/setting/cancelMail
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface CancelMailReq {
  /** 用户id */
  userId: string;
  /** valiCode验证 */
  valiCode: string;
}

export interface CancelMailResp {
}

/**
 * 接口描述: 通过手机号码注销账户，第一步：发送验证邮件
 *  接口url: /personal/user/setting/sendCancelSmsValiCode
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface SmsCancelReq {
}

export interface SmsCancelResp {
}

/**
 * 接口描述: 通过手机号码注销账户，第二步：验证验证码
 *  接口url: /personal/user/setting/checkCancelSms
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface SmsCheckCancelReq {
  /** vali code */
  valiCode: string;
}

export interface SmsCheckCancelResp {
}

/**
 * 接口描述: 通过手机号码注销账户，第三步：验证后完成注销
 *  接口url: /personal/user/setting/cancelSms
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface CancelSmsReq {
  /** 用户id */
  userId: string;
  /** valiCode验证 */
  valiCode: string;
}

export interface CancelSmsResp {
}

/**
 * 接口描述: 通过微信扫码注销账户，第一步：获取微信注销二维码
 *  接口url: /personal/user/setting/getWXCancelValiCode
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface GetWXCancelValiCodeReq {
}

export interface GetWXCancelValiCodeResp {
  /** 图片，base64 */
  qrCode: string;
  ticket: string;
  requestCancelId: string;
  /** 二维码过期时间 */
  expiresSecond: number;
}

/**
 * 接口描述: 通过微信扫码注销账户，第二步：验证微信公众号注销（轮询）
 *  接口url: /personal/user/setting/checkCancelWxPublic
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface CheckCancelWxPublicReq {
  /** requestCancelId */
  requestCancelId: string;
}

export interface CheckCancelWxPublicResp {
}

/**
 * 接口描述: 通过微信扫码注销账户，第三步：注销微信公众号
 *  接口url: /personal/user/setting/cancelWxPublic
 *  接口请求方式:POST
 *  参数格式:application/json
 */
export interface cancelWxPublicReq {
  /** requestCancelId */
  requestCancelId: string;
}

export interface cancelWxPublicResp {
}
