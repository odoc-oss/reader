/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.user";

export enum AuthWay {
  /** MATERIAL - 实名材料认证 */
  MATERIAL = 0,
  /** EDU_MAIL - 教育邮箱认证 */
  EDU_MAIL = 1,
  UNRECOGNIZED = -1,
}

export enum AuthMaterialStatus {
  /** UN_UPLOAD - 未上传 */
  UN_UPLOAD = 0,
  /** SUBMITTED - 已提交 */
  SUBMITTED = 1,
  /** UN_APPROVED - 未通过 */
  UN_APPROVED = 2,
  /** APPROVED - 已通过 */
  APPROVED = 3,
  UNRECOGNIZED = -1,
}

export enum VerifyStatus {
  /** NOT_VERIFY - 未认证 */
  NOT_VERIFY = 0,
  /** APPROVING - 审批中 */
  APPROVING = 1,
  /** IS_VERIFY - 已认证 */
  IS_VERIFY = 2,
  UNRECOGNIZED = -1,
}
