/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.user";

/** vip类型，顺序：OUTSTANDING>PROFESSIONAL>STANDARD,ENTERPRISE另算 */
export enum VipType {
  FREE = 0,
  STANDARD = 1,
  PROFESSIONAL = 2,
  ENTERPRISE = 3,
  OUTSTANDING = 4,
  UNRECOGNIZED = -1,
}

/**
 * url: /vip/profile
 * http method: GET
 */
export interface VipProfileResponse {
  vipPrivilege?: VipPrivilege | undefined;
  vipTasks: VipTask[];
  taskFinishRecords: TaskFinishRecord[];
  vipUserDescription?: VipUserDescription | undefined;
  invitationCodeOpen: boolean;
  /** 第一个vip类型为当前正在使用的vip,从大到小，依次排序 */
  vipRoles: VipRole[];
}

export interface VipRole {
  vipType: VipType;
  vipLeftDays: number;
  vipPrivilege?: VipPrivilege | undefined;
}

export interface VipUserDescription {
  isVip: boolean;
  vipLeftDays: number;
  tempVipType?: VipType | undefined;
}

export interface VipPrivilege {
  /** 文献数量上限 */
  documentCountLimit: number;
  /** 单个文献大小 */
  singleDocumentSizeLimit: number;
  /** 全文翻译每周次数 */
  fullTextTranslationCountLimit: number;
  /** 论文查重次数，已废弃 */
  duplicatePaperCheckingCountLimit: number;
  /** 创建小组数量 */
  groupCreateCountLimit: number;
  /** 加入小组数量 */
  groupJoinCountLimit: number;
  /** 文献附件总空间,单位B */
  docAttachmentTotalSpace: number;
  /** 小组上传文献数量 */
  groupDocumentCountLimit: number;
  /** 小组笔记 */
  groupDocumentNoteCountLimit: number;
  /** 划词翻译每周数量 */
  wordSelectionTranslateCountLimit: number;
  /** 是否支持导出功能 */
  exportEnable: boolean;
  /** 全文翻译单次限制页数 */
  fullTextTranslatePageCountLimit: number;
  /** OCR翻译每周次数 */
  ocrTranslateCountLimit: number;
  /** aireading最高支持论文页数 */
  aiReadingDocumentPageCountLimit: number;
  /** 每周下发的ai豆 */
  aiBeanCountLimit: number;
  /** 是否开启辅读 */
  readingEnable: boolean;
  /** 是否开启润色 */
  polishEnable: boolean;
  /** 付款内容 */
  paySubject: string;
  /** 付款金额 */
  payTotalAmount: string;
  /** vip类型 */
  vipType: VipType;
  /** 付款原价 */
  originalPayTotalAmount: string;
  /** 优惠标签资源链接 */
  costLabelUrl: string;
  /** 学习统计功能 */
  learningStatisticsEnable: boolean;
  /** 新功能优先内测 */
  newFeatureEnable: boolean;
  /** 未生效，仅用于界面展示，小组成员数量 */
  groupMemberCountLimit: number;
  /** 宣传文案(已过时) */
  disseminateText: string;
  /** 优惠文案 */
  costLabelTip: string;
  /** 扣豆相关 */
  polishZH: number;
  /** 原：polish,扣豆2 */
  polishEN: number;
  /** 原：polish,扣豆2 */
  polishZh2En: number;
  /** 原：title-generate,扣豆8 */
  polishTitleGenerate: number;
  /** 原：title-generate,扣豆8 */
  polishAbstractGenerate: number;
  /** 原：ai-reading-question,扣豆8 */
  readingAskQuestion: number;
  /** 原：abstract-rewrite,扣豆8 */
  polishAbstractRewrite: number;
  /** 原：abstract-truing-framework,扣豆8 */
  polishAbstractTruingFramework: number;
  /** 原：review,扣豆30 */
  polishReviewAll: number;
  /** 宣传文案 */
  disseminateTextes: string[];
  /** ai翻译扣1豆 */
  aiTranslateConsumeBeanCount: number;
  aiTranslateEnable: boolean;
  /** 当前版本团购价格，单位：分 */
  groupBuyPayTotalAmount: string;
  /** 折扣率,例如：8/85/99，用于显示，实际价格看groupBuyPayTotalAmount，已计算好 */
  discount: string;
}

export interface VipTask {
  name: string;
  vipDaysDescription: string;
  iconUrl: string;
}

export interface TaskFinishRecord {
  finishTimestamp: string;
  description: string;
  vipDaysGained: number;
}

/**
 * url: /vip/pdf/export/config
 * http method: GET
 */
export interface PdfExportToastAndUrlResponse {
  toast: string;
  url: string;
}
