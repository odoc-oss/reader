/* eslint-disable */
import type { VipType } from "./VipUserInterface";

export const protobufPackage = "cn.edu.idea.cloud.user";

export enum GrantStatus {
  /** UN_GRANT - 未发放 */
  UN_GRANT = 0,
  /** FINISHED - 已发放 */
  FINISHED = 1,
  /** FAIL - 发放失败 */
  FAIL = 2,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: VIP发放历史列表
 * 	接口url: admin/grantVip/historyList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GrantVipHistoryListReq {
  pageSize: number;
  currentPage: number;
  userId: string;
  /** 发放人 */
  operator: string;
  /** 备注 */
  remark: string;
}

export interface GrantVipHistoryListResponse {
  total: number;
  list: GrantVipHistoryListItem[];
}

export interface GrantVipHistoryListItem {
  userId: string;
  nickName: string;
  createDate: string;
  days: number;
  /** 当前记录id */
  recordId: string;
  /** 发放人 */
  operator: string;
  remark: string;
  /** 发放状态 */
  grantStatus: GrantStatus;
  grantDate?: string | undefined;
  vipType: VipType;
}

/**
 * 接口描述: 新增VIP发放记录
 * 	接口url: admin/grantVip/addRecord
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应 : GrantVipHistoryListItem
 */
export interface AddGrantVipRecordReq {
  userId: string;
  days: number;
  /** 发放人 */
  operator: string;
  /** 备注 */
  remark: string;
  /** vip类型 */
  vipType: VipType;
}

/**
 * 接口描述: 编辑VIP发放记录
 * 	接口url: admin/grantVip/updateRecord
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应 : GrantVipHistoryListItem
 */
export interface UpdateGrantVipRecordReq {
  userId: string;
  days: number;
  /** 发放人 */
  operator: string;
  /** 备注 */
  remark: string;
  /** 当前记录id */
  recordId: string;
  /** vipType */
  vipType: VipType;
}

/**
 * 接口描述: 发放vip
 * 	接口url: admin/grantVip/grant
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: GrantStatus
 */
export interface GrantVipReq {
  recordId: string;
}

/**
 * 接口描述: 删除未发放的记录
 * 	接口url: admin/grantVip/deleteRecord
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface DeleteRecordReq {
  recordId: string;
}

/**
 * 接口描述: 重试
 * 	接口url: admin/grantVip/retryGrant
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: GrantStatus
 */
export interface RetryGrantReq {
  recordId: string;
}
