/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.user";

export interface BaseUserInfo {
  userId: string;
  /** @Deprecated 2021年已讨论将realName统一为nickName，请在业务实现中统一使用nickName */
  realName: string;
}

/** 在此扩展其他用户信息 */
export interface CommonUserInfo {
  userInfo?: BaseUserInfo | undefined;
  avatarUrl: string;
  description: string;
  authorId: string;
  authorName: string;
  isAuthentication: boolean;
  isPaperAuthor: boolean;
}

/** 对应 cn.edu.idea.cloud.aiKnowledge.bean.AuthorBean */
export interface UserInfoBean {
  id: string;
  nickName: string;
  self: boolean;
  showName: string;
  avatarUrl: string;
  tags: string;
  description: string;
  authorId: string;
  authorName: string;
  isAuthentication: boolean;
  isPaperAuthor: boolean;
}
