/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.user";

export enum NeedEmailVerify {
  OLD_USER_NOT_NEED = 0,
  NEW_USER_NEED = 1,
  NEW_USER_NOT_NEED = 2,
  NOT_TERM_BEGIN_SCENE = 3,
  UNRECOGNIZED = -1,
}
