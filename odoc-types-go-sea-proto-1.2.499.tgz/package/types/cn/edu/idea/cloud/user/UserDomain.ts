/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.user";

/** 论文领域错误码，范围：20001-29999 */
export enum ErrorCode {
  SUCCESS = 0,
  /** ERR_UNKNOW - ErrorCode end, do not edit below area */
  ERR_UNKNOW = 30000,
  UNRECOGNIZED = -1,
}
