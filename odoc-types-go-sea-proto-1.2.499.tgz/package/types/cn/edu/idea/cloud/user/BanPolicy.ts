/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.user";

export enum BanStrategyType {
  DAYS_7 = 0,
  DAYS_30 = 1,
  FOREVER = 2,
  UNRECOGNIZED = -1,
}

export enum BanReason {
  /** PORNOGRAPHIC - 色情 */
  PORNOGRAPHIC = 0,
  /** NONCOMPLIANT - 违规 */
  NONCOMPLIANT = 1,
  /** ILLEGAL - 违法 */
  ILLEGAL = 2,
  /** INFRINGING - 侵权 */
  INFRINGING = 3,
  /** OTHERS - 其他 */
  OTHERS = 4,
  UNRECOGNIZED = -1,
}

export enum PolicyStatus {
  UNPUBLISHED = 0,
  PUBLISHED = 1,
  UNRECOGNIZED = -1,
}

export interface BanPolicyItem {
  policyId: string;
  uin: string;
  userName: string;
  banStrategyType: BanStrategyType;
  banReason: number;
  remark: string;
  beginTime: string;
  endTime: string;
  processorName: string;
  status: PolicyStatus;
}

/**
 * url: /admin/ban/policy
 * http method: POST
 * 添加封禁用户策略
 */
export interface AddBanPolicyRequest {
  /** 用户ID */
  uin: string;
  /** 同BanStrategyType */
  banStrategyType: number;
  /** 同BanReason */
  banReason: number;
  /** 备注 */
  remark: string;
}

export interface AddBanPolicyResponse {
  /** 添加封禁用户策略ID */
  policyId: string;
}

/**
 * url: /admin/ban/policy
 * http method: PUT
 * 修改封禁用户策略
 */
export interface SaveBanPolicyRequest {
  /** 策略ID */
  policyId: string;
  /** 同BanStrategyType */
  banStrategyType: number;
  /** 同BanReason */
  banReason: number;
  /** 备注 */
  remark: string;
}

export interface SaveBanPolicyResponse {
}

/**
 * url: /admin/ban/policy
 * http method: DELETE
 * 删除封禁用户策略
 */
export interface DeleteBanPolicyRequest {
  /** 策略ID */
  policyId: string;
}

export interface DeleteBanPolicyResponse {
}

/**
 * url: /admin/ban/policy/publish
 * http method: PUT
 * 发布封禁用户策略
 */
export interface PublishBanPolicyRequest {
  /** 策略ID */
  policyId: string;
}

export interface PublishBanPolicyResponse {
}

/**
 * url: /admin/ban/policies
 * http method: GET
 * 获取封禁用户策略, uin非空根据uin查找，uin为空则根据时间排序获取
 */
export interface GetBanPoliciesRequest {
  /** 用户ID */
  uin?:
    | string
    | undefined;
  /** 页码 */
  pageNum?:
    | number
    | undefined;
  /** 每页数量 */
  pageSize?: number | undefined;
}

export interface GetBanPoliciesResponse {
  /** 列表总长度 */
  total: number;
  /** 偏移量 */
  offset: number;
  /** 每页数量 */
  pageSize: number;
  /** 策略列表 */
  banPolicies: BanPolicyItem[];
}
