/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.user";

export interface AuthorizationLoginRequest {
  authorizationCode: string;
  redirectUrl: string;
}
