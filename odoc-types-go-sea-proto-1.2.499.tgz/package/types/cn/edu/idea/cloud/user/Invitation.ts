/* eslint-disable */
import type { CommonUserInfo } from "./UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.user";

export enum InvitationCodeRegisterStatus {
  /** NEW_USER_ACCEPT - 新用户接口邀请 */
  NEW_USER_ACCEPT = 0,
  /** REGISTERED_USER_HAS_BEEN_BINDED - 注册用户-已接受了别人的邀请 */
  REGISTERED_USER_HAS_BEEN_BINDED = 1,
  /** REGISTERED_USER_RECALLABLE_FINSIHED_BINDED - 有召回价值的注册用户-完成了绑定 */
  REGISTERED_USER_RECALLABLE_FINSIHED_BINDED = 2,
  /** REGISTERED_USER_UNRECALLABLE - 无召回价值的注册用户-完成了绑定 */
  REGISTERED_USER_UNRECALLABLE = 3,
  /** USER_HIMSELF_CLICK_INVITATION - 用户本人点击了自己的邀请 */
  USER_HIMSELF_CLICK_INVITATION = 4,
  /** REGISTERED_USER_NOT_BINDED_TO_ANYONE - 已注册用户，但是还没有完成任何绑定 */
  REGISTERED_USER_NOT_BINDED_TO_ANYONE = 5,
  UNRECOGNIZED = -1,
}

/**
 * url: /public/invite/update/logs
 * http method: GET
 */
export interface RecentUpdateLogResponse {
  recentUpdateLogs: RecentUpdateLog[];
}

export interface RecentUpdateLog {
  formatDate: string;
  logs: string[];
}

/**
 * url: /public/invite/code/result
 * http method: GET
 */
export interface AcceptInviteRequest {
  invitationCode: string;
}

export interface AcceptInviteResponse {
  invitationCodeRegisterStatus: InvitationCodeRegisterStatus;
}

/**
 * url: /public/invite/code/binded/user
 * http method: GET
 */
export interface GetBindedUserResponse {
  bindedUser?: CommonUserInfo | undefined;
}

/**
 * url: /public/invite/code/bind
 * http method: POST
 */
export interface BindMyselfToSomeoneByCodeRequest {
  invitationCode: string;
}

export interface BindMyselfToSomeoneByCodeResponse {
  invitationCodeRegisterStatus: InvitationCodeRegisterStatus;
}
