/* eslint-disable */
import type { CommonUserInfo } from "./UserInfo";
import type { TaskFinishRecord } from "./VipUserInterface";

export const protobufPackage = "cn.edu.idea.cloud.user";

/**
 * url: /public/profile/invitation/code
 * http method: GET
 */
export interface MyInvitationCodeResponse {
  invitationCode: string;
  whoInviteMe?: InviterBaseInfo | undefined;
  taskFinishRecords: TaskFinishRecord[];
  urlOfQRCode: string;
  invitationCodeOpen: boolean;
}

/**
 * url: /public/profile/invitation/record
 * http method: GET
 */
export interface MyInvitationRecordResponse {
  invitationRecords: InvitationRecord[];
}

export interface InviterBaseInfo {
  inviter?: CommonUserInfo | undefined;
  invitationCode: string;
}

export interface InvitationRecord {
  accepter?: CommonUserInfo | undefined;
  description: string;
}

/**
 * url: /public/profile/invitation/inviter
 * http method: GET
 */
export interface GetInviterRequest {
  invitationCode: string;
}

export interface GetInviterResponse {
  inviterBaseInfo?: InviterBaseInfo | undefined;
  invitationCodeOpen: boolean;
}

/**
 * url: /public/profile/invitation/code/change
 * http method: PUT
 */
export interface ChangeMyInviterRequest {
  /** 空字符串表示清空邀请人，不允许传Null */
  newInvitationCode: string;
}
