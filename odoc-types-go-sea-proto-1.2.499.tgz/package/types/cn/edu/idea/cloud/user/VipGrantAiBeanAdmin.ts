/* eslint-disable */
import type { GrantStatus } from "./VipGrantAdmin";

export const protobufPackage = "cn.edu.idea.cloud.user";

/**
 * 接口描述: ai bean发放历史列表
 * 	接口url: admin/grantAiBean/historyList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GrantAiBeanHistoryListReq {
  pageSize: number;
  currentPage: number;
  userId: string;
  /** 发放人 */
  operator: string;
  /** 备注 */
  remark: string;
}

export interface GrantAiBeanHistoryListResponse {
  total: number;
  list: GrantAiBeanHistoryListItem[];
}

export interface GrantAiBeanHistoryListItem {
  userId: string;
  nickName: string;
  createDate: string;
  count: number;
  /** 当前记录id */
  recordId: string;
  /** 发放人 */
  operator: string;
  remark: string;
  /** 发放状态 */
  grantStatus: GrantStatus;
  grantDate?: string | undefined;
}

/**
 * 接口描述: 新增ai bean发放记录
 * 	接口url: admin/grantAiBean/addRecord
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应 : GrantAiBeanHistoryListItem
 */
export interface AddGrantAiBeanRecordReq {
  userId: string;
  count: number;
  /** 发放人 */
  operator: string;
  /** 备注 */
  remark: string;
}

/**
 * 接口描述: 编辑ai bean发放记录
 * 	接口url: admin/grantAiBean/updateRecord
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应 : GrantAiBeanHistoryListItem
 */
export interface UpdateGrantAiBeanRecordReq {
  userId: string;
  count: number;
  /** 发放人 */
  operator: string;
  /** 备注 */
  remark: string;
  /** 当前记录id */
  recordId: string;
}

/**
 * 接口描述: 发放ai bean
 * 	接口url: admin/grantAiBean/grant
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: GrantStatus
 */
export interface GrantAiBeanReq {
  recordId: string;
}

/**
 * 接口描述: 删除未发放的记录
 * 	接口url: admin/grantAiBean/deleteRecord
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GrantAiBeanDeleteRecordReq {
  recordId: string;
}

/**
 * 接口描述: 重试
 * 	接口url: admin/grantAiBean/retryGrant
 * 	接口请求方式: POST
 * 	参数格式:application/json
 *  响应: GrantStatus
 */
export interface GrantAiBeanRetryGrantReq {
  recordId: string;
}
