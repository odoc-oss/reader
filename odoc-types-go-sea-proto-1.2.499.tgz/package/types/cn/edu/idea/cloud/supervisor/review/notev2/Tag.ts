/* eslint-disable */
import type { AnnotateTag } from "./Common";

export const protobufPackage = "cn.edu.idea.cloud.supervisor.review.notev2";

/**
 * 获取标签信息
 * url = /paperNote/tags
 * method = GET
 * 服务名：microservice-supervisor-review
 */
export interface GetAnnotateTagsReq {
  onlyUsed: boolean;
}

export interface GetAnnotateTagsResp {
  tags: AnnotateTag[];
}

/**
 * 修改标签信息
 * url = /paperNote/tag
 * method = PUT
 * 服务名：microservice-supervisor-review
 */
export interface RenameAnnotateTagReq {
  tagId: string;
  tagName: string;
}

/** empty */
export interface RenameAnnotateTagResp {
}

/**
 * 删除标签信息
 * url = /paperNote/tag
 * method = DELETE
 */
export interface DeleteAnnotateTagReq {
  tagId: string;
}

/** empty */
export interface DeleteAnnotateTagResp {
}

/**
 * 创建标签信息
 * url = /paperNote/tag
 * method = POST
 * 服务名：microservice-supervisor-review
 */
export interface CreateAnnotateTagReq {
  /** 标签名称 */
  tagName: string;
  /** 笔记id */
  markId: string;
}

export interface CreateAnnotateTagResp {
  tagId: string;
}

/**
 * 给批注添加标签信息
 * url = /paperNote/tag/relation/mark
 * method = POST
 * 返回通用状态码
 * 服务名：microservice-supervisor-review
 */
export interface AddTagToAnnotateReq {
  /** 笔记id */
  markId: string;
  /** 标签id */
  tagIds: string[];
}

/**
 * 删除批注的标签信息
 * url = /paperNote/tag/relation/mark
 * method = DELETE
 * 参数放在url之后
 * 返回通用状态码
 * 服务名：microservice-supervisor-review
 */
export interface DeleteTagToAnnotateReq {
  /** 笔记id */
  markId: string;
  /** 标签id，tagId可能会有重复的，所以传几个就删除几个 */
  tagIds: string[];
}
