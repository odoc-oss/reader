/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.supervisor.review.notev2";

/** 注释类型 */
export enum IDEAAnnotateType {
  /** IDEAAnnotateTypeComment - 注释 */
  IDEAAnnotateTypeComment = 0,
  /** IDEAAnnotateTypeRect - 矩形 */
  IDEAAnnotateTypeRect = 1,
  /** IDEAAnnotateTypeIOSDraw - IOS笔触笔记 */
  IDEAAnnotateTypeIOSDraw = 2,
  /** IDEAAnnotateTypeHotRect - 热门选区 */
  IDEAAnnotateTypeHotRect = 3,
  /** IDEAAnnotateTypeTextBox - 文本框 */
  IDEAAnnotateTypeTextBox = 4,
  UNRECOGNIZED = -1,
}

export interface RectOptions {
  /** 锚点横坐标 */
  x: number;
  /** 锚点纵坐标 */
  y: number;
  /** 选区宽度 */
  width: number;
  /** 选区高度 */
  height: number;
  /** 选区所在页数 */
  pageNumber: number;
  /** 旋转角度 */
  rotation: number;
}

export interface AnnotationPointer {
  id: string;
  /** 群组id */
  groupId: string;
}

export interface AnnotateTag {
  tagId: string;
  tagName: string;
  latestUseTime: string;
}

export interface CommentatorInfoView {
  nickName: string;
  avatarCdnUrl: string;
  userId: string;
}

/**
 * /pdfMark/v2/page/noteCount
 * GET
 */
export interface NoteCountOfPdfPerPageRequest {
  pdfId: string;
}

export interface NoteCountOfPdfPerPageResponse {
  noteCountList: NoteCountOfPdfPerPage[];
}

export interface NoteCountOfPdfPerPage {
  page: number;
  noteCount: number;
}
