/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.supervisor.review.notev2";

export interface AnnotationRawModel {
  type: number;
  rect?: RectRawModel | undefined;
  comment?: CommentRawModel | undefined;
  groupId: string;
  userId: string;
  lastReadTime: string;
  drawNoteRawModel?: DrawNoteRawModel | undefined;
  textBoxModel?:
    | TextBoxModel
    | undefined;
  /** 是否为高亮内容 */
  isHighlight?: boolean | undefined;
}

export interface TextBoxModel {
  annotateTextBox?: AnnotateTextBox | undefined;
  page: number;
  token: string;
  id: string;
}

export interface AnnotateTextBox {
  x: number;
  y: number;
  width: number;
  height: number;
  borderColor: string;
  fonts: Font[];
}

export interface Font {
  content: string;
  fontSize: number;
  color: string;
}

export interface RectRawModel {
  /** 标注ID */
  id: string;
  /** 图片URL */
  picUrl: string;
  /** 是否删除了 */
  isDelete: boolean;
  /** 笔记ID */
  token: string;
  /** 标记类型 */
  type: string;
  lineColor: string;
  strokeDasharray: string;
  fill: string;
  fillOpacity: string;
  color: string;
  rectangles: Rectangle[];
  page: number;
  styleId: number;
  pdfId: string;
  idea: string;
  createDate: string;
  sort: number;
}

export interface CommentRawModel {
  idea: string;
  id: string;
  token: string;
  type: string;
  fill: string;
  rectStr: string;
  rectangles: Rectangle[];
  annotateId: string;
  page: number;
  styleId: number;
  pdfId: string;
  createDate: string;
  sort: number;
}

export interface Rectangle {
  x: number;
  y: number;
  width: number;
  height: number;
  /** 选区所在页数 */
  pageNumber: number;
  /** 旋转角度 */
  rotation: number;
}

export interface DrawNoteRawModel {
  drawNoteFileUrl: string;
  page: number;
  token: string;
  id: string;
}

export interface TextBox {
}
