/* eslint-disable */
import type { AnnotateTag, IDEAAnnotateType } from "./Common";
import type { AnnotateTextBox } from "./Persistence";

export const protobufPackage = "cn.edu.idea.cloud.supervisor.review.notev2";

export interface IOSNoteAnnotateContentModel {
  type: IDEAAnnotateType;
  comment?: IOSNoteAnnotateComment | undefined;
  rect?:
    | IOSNoteAnnotateRect
    | undefined;
  /** 当前annotate ID */
  id: string;
  token: string;
  /** annotate page */
  page: string;
  /** 标注创建时间 */
  createDate: string;
  /** 标注所属论文id */
  paperId: string;
  paperTitle: string;
  /** 笔记所属文献名称 */
  docName: string;
  pencil?:
    | IOSNoteAnnotateDraw
    | undefined;
  /** 标签 */
  tags: AnnotateTag[];
  /** 文本框 */
  textBox?: AnnotateTextBox | undefined;
}

export interface IOSNoteAnnotateComment {
  styleId: number;
  /** markdown string */
  idea: string;
  /** pdf selected text */
  rectStr: string;
  quads: IOSPDFQuad[];
}

export interface IOSNoteAnnotateRect {
  styleId: number;
  /** markdown string */
  idea: string;
  quad?: IOSPDFQuad | undefined;
  picURL: string;
}

export interface IOSNoteAnnotateDraw {
  nsDataUrl: string;
}

export interface IOSPDFQuad {
  ul?: IOSPoint | undefined;
  ll?: IOSPoint | undefined;
  ur?: IOSPoint | undefined;
  lr?:
    | IOSPoint
    | undefined;
  /** 旋转角度 */
  rotation: number;
  pageNumber: number;
}

export interface IOSPoint {
  x: number;
  y: number;
}

/**
 * 获取标签信息
 * url = /pdfMark/v2/ios/saveWithTag
 * method = POST
 */
export interface IOSAddNoteResp {
  markId: string;
  newTags: AnnotateTag[];
  rawContent: string;
}

/**
 * 获取标签信息
 * url = /pdfMark/v2/ios/updateWithTag
 * method = PUT
 */
export interface IOSUpdateNoteResp {
  newTags: AnnotateTag[];
  rawContent: string;
}

/**
 * 根据token获取笔记
 * GET /pdfMark/v3/ios/getByNote
 */
export interface IOSNoteAnnotationModelsRequest {
  token: string;
}

export interface IOSNoteAnnotationModelsResponse {
  iOSNoteAnnotationModels: IOSNoteAnnotateContentModel[];
}

/**
 * 上传笔触文件
 * POST /pdfMark/v2/ios/note/draw/upload
 */
export interface UploadDrawNote {
  /** 这里实质上是文件类型，pb不好描述 */
  drawNote: string;
}

export interface UploadDrawNoteResponse {
  drawNoteUrl: string;
}
