/* eslint-disable */
import type { AnnotateTag, AnnotationPointer, CommentatorInfoView, IDEAAnnotateType, RectOptions } from "./Common";

export const protobufPackage = "cn.edu.idea.cloud.supervisor.review.notev2";

export enum OperationTypeOfSort {
  /** addToPage - 添加到某一页 */
  addToPage = 0,
  /** exchangeInPage - 在内页交换 */
  exchangeInPage = 1,
  UNRECOGNIZED = -1,
}

/**
 * 更新标注（可选携带标签信息）
 * url = /pdfMark/v2/web/getByToken
 * method = Get
 * 服务名：microservice-supervisor-review
 */
export interface GetByTokenReq {
  token: string;
}

export interface GetByTokenResp {
  annotations: WebNoteAnnotationModel[];
}

export interface WebNoteAnnotationModel {
  /** 标注类型 */
  type: IDEAAnnotateType;
  /** 图片选区标注 */
  rect?:
    | WebNoteRectAnnotation
    | undefined;
  /** 文字选区标注 */
  select?:
    | WebNoteSelectAnnotation
    | undefined;
  /** 标注所在页码 */
  pageNumber: number;
  /** 标注创建时间 */
  createDate: string;
  /** 标注所属论文id */
  token: string;
  /** 标注所属论文标题 */
  paperTitle: string;
  /** 群组id */
  groupId: string;
  commentatorInfoView?:
    | CommentatorInfoView
    | undefined;
  /** 当前用户是否拥有删除权限 */
  deleteAuthority: boolean;
  /** 笔记所属文献名称 */
  docName: string;
  /** 当前的笔记id，用来校验数据是否已过期 */
  markIdsOfCurrentPage: string[];
  /** 新增笔记的排序,position是指在markIdsOfCurrentPage中的位置 */
  position: number;
  /** 标签 */
  tags: AnnotateTag[];
  drawAnnotation?: WebNoteAnnotateDraw | undefined;
}

export interface WebNoteRectAnnotation {
  /** 标注ID */
  uuid: string;
  /** 笔记ID */
  documentId: string;
  /** 样式ID */
  styleId: number;
  /** 选区 */
  rectangle?:
    | RectOptions
    | undefined;
  /** 用户文字标注 */
  idea: string;
  /** 图片链接 */
  picUrl: string;
}

export interface WebNoteSelectAnnotation {
  /** 标注ID */
  uuid: string;
  /** 笔记ID */
  documentId: string;
  /** 选区（多行） */
  rectangle: RectOptions[];
  /** 选中文字 */
  rectStr: string;
  /** 用户文字标注 */
  idea: string;
  /** 样式ID */
  styleId: number;
  /** 同样选中此处的人数 */
  score: number;
}

/**
 * 删除标注
 * url = /pdfMark/v2/web/delete
 * method = Delete
 * 服务名：microservice-supervisor-review
 */
export interface DeleteAnnotationRequest {
  annotationPointer?: AnnotationPointer | undefined;
}

/**
 * 撤销标注
 * url = /pdfMark/v2/web/revokeDelete
 * method = Delete
 * 服务名：microservice-supervisor-review
 */
export interface RevokeDeleteAnnotationRequest {
  annotationPointer?: AnnotationPointer | undefined;
}

/**
 * 添加标注（可选携带标签信息）
 * url = /pdfMark/v2/web/saveWithTag
 * method = POST
 * 服务名：microservice-supervisor-review
 */
export interface AddNoteResp {
  markId: string;
  newTags: AnnotateTag[];
  rawContent: string;
}

/**
 * 更新标注（可选携带标签信息）
 * url = /pdfMark/v2/web/updateWithTag
 * method = PUT
 * 服务名：microservice-supervisor-review
 */
export interface UpdateNoteResp {
  newTags: AnnotateTag[];
  rawContent: string;
}

/**
 * 调整标注排序
 * url = /pdfMark/v2/web/sortAnnotation
 * method = PUT
 * 服务名：microservice-supervisor-review
 */
export interface SortAnnotationRequest {
  markIdsWithSort: SortOfPdfMark[];
  /** pdf token */
  token: string;
  /** 页码 */
  pageNumber: number;
}

export interface SortOfPdfMark {
  markId: string;
  operationTypeOfSort: OperationTypeOfSort;
}

/** empty */
export interface SortAnnotationResponse {
}

export interface WebNoteAnnotateDraw {
  nsDataUrl: string;
}
