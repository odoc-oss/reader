/* eslint-disable */
import type { AcquirePolicyCallbackInfoResponse, UploadBizScene } from "../../oss/AliOSS";

export const protobufPackage = "cn.edu.idea.cloud.supervisor.review";

export enum ReviewStatus {
  /** REVIEW_STATUS_UNSTARTED - 未上传（废弃，改了会导致后面的常量乱掉，注释在这里） */
  REVIEW_STATUS_UNSTARTED = 0,
  /** REVIEW_STATUS_UPLOADING - 上传中（废弃，改了会导致后面的常量乱掉，注释在这里） */
  REVIEW_STATUS_UPLOADING = 1,
  /** REVIEW_STATUS_UPLOADED - 上传完成 */
  REVIEW_STATUS_UPLOADED = 2,
  /** REVIEW_STATUS_REVIEWING - 改稿评审中 */
  REVIEW_STATUS_REVIEWING = 3,
  /** REVIEW_STATUS_COMPLETED - 评审完成 */
  REVIEW_STATUS_COMPLETED = 4,
  UNRECOGNIZED = -1,
}

export enum ReviewRoleStatus {
  /** UPLOADER - 上传人 */
  UPLOADER = 0,
  /** REVIEWER - 改稿评审人 */
  REVIEWER = 1,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 获取上传到阿里云OSS所需的policy和Callback等信息
 * 	接口url: /review/getFileIsNeedUpload
 * 	接口请求方式: POST
 *  服务名：microservice-supervisor-review
 */
export interface GetFileIsNeedUploadReq {
  scene: UploadBizScene;
  md5: string;
}

export interface GetFileIsNeedUploadResponse {
  data?: AcquirePolicyCallbackInfoResponse | undefined;
  status: number;
  message: string;
}

/**
 * 接口描述:根据阿里云私有桶信息生成token并获取可访问url
 *   接口url:/review/generatePdfToken
 *   接口请求方式:POST
 */
export interface PdfUploadBucketRequest {
  bucketName: string;
  objectName: string;
}

export interface PdfUploadBucketResponse {
  pdfEntity?: PdfEntity | undefined;
}

/**
 * 接口描述:根据用户信息获取pdf列表,出参(list)
 *   接口url:/review/getUserPdfs
 *   接口请求方式:GET
 */
export interface UserPdfsRequest {
  role: ReviewRoleStatus;
}

export interface UserPdfsResponse {
  pdfList: PdfEntity[];
}

/**
 * 接口描述:删除用户pdf
 * 接口url:/review/deleteUserPdf
 * 接口请求方式:POST
 * 服务名：microservice-supervisor-review
 */
export interface DeleteUserPdfRequest {
  token: string;
}

/**
 * 接口描述:导师评审，综合建议[添加、修改共用]
 * 接口url:/review/recommendation
 * 接口请求方式:POST
 * 参数格式:application/json
 */
export interface PdfRecommendationRequest {
  /** 综合建议内容 */
  recommendationContent: string;
  /** pdf token */
  token: string;
}

/**
 * 接口描述:导师评审，完成改稿
 * 接口url:/review/completed
 * 接口请求方式:POST
 * 参数格式:application/json
 */
export interface PdfRecommendationCompletedRequest {
  /** pdf token */
  token: string;
}

export interface PdfEntity {
  /** pdf token */
  token: string;
  /** pdf地址 */
  pdfUrl: string;
  /** 文件名称 */
  fileName: string;
  /** 改稿评审状态 */
  reviewStatus: ReviewStatus;
  /** 综合建议内容 */
  recommendationContent?: string | undefined;
}
