/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.ab";

/**
 * 接口描述: 获取分流信息，实验id和策略id，前端直接硬编码
 * 	接口url:/ab/get/traffic
 * 	接口请求方式: GET
 * 	参数格式:application/json
 *  service-id: microService-app-aiKnowledge
 */
export interface GetTrafficReq {
  /** 手动触发时，实验id，做一个可升级的接口 */
  experimentId: string;
}

export interface GetTrafficResp {
  item?: ConfigItem | undefined;
}

/**
 * 接口描述: 获取上报实验信息
 * 	接口url:/ab/get
 * 	接口请求方式: GET
 * 	参数格式:application/json
 *  service-id: microService-app-aiKnowledge
 */
export interface GetExperimentReq {
  /** 为防止在iframe的情况，冗余传递url，当有path时，优先使用path */
  path: string;
}

export interface GetExperimentResp {
  item?: ConfigItem | undefined;
}

export interface ConfigItem {
  /** 实验id */
  experimentId: string;
  /** 策略id */
  strategyId: string;
}
