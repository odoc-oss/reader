/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.client";

/**
 * 保存搜索引擎
 * url: /userClientSearchEngine/save
 */
export interface SaveUserClientSearchEngineReq {
  name: string;
  url: string;
}

export interface SaveUserClientSearchEngineResponse {
  userClientSearchEngineId: string;
}

/**
 * 编辑搜索引擎
 * url: /userClientSearchEngine/edit
 */
export interface EditUserClientSearchEngineReq {
  name: string;
  url: string;
  userClientSearchEngineId: string;
}

/**
 * 删除搜索引擎
 * url: /userClientSearchEngine/delete
 */
export interface DeleteUserClientSearchEngineReq {
  userClientSearchEngineId: string;
}

/**
 * 改变搜索引擎的排序
 * url: /userClientSearchEngine/changeSort
 */
export interface ChangeUserClientSearchEngineSortReq {
  userClientSearchEngineId: string;
  /** 新的排序 */
  sort: number;
}

/**
 * 改变搜索引擎的排序
 * url: /userClientSearchEngine/list
 */
export interface GetUserClientSearchEngineListReq {
}

export interface GetUserClientSearchEngineListResponse {
  total: number;
  userClientSearchEngines: UserClientSearchEngineInfo[];
}

export interface UserClientSearchEngineInfo {
  userClientSearchEngineId: string;
  sort: number;
  name: string;
  url: string;
}
