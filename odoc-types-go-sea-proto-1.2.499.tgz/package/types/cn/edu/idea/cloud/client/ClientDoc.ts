/* eslint-disable */
import type { UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.client";

/**
 * 获取用户的一级文件夹列表
 * url: /client/doc/getTopLevelFolderList
 */
export interface GetTopLevelFolderListReq {
  paperId: string;
}

export interface GetTopLevelFolderListResponse {
  status: number;
  message: string;
  data: SimpleFolderInfo[];
}

/**
 * 将论文添加到文件夹
 * url: /client/doc/attachPaperToFolder
 */
export interface AttachPaperToFolderReq {
  /** 论文id */
  paperId: string;
  /** 文件夹id */
  folderId: string;
}

export interface AttachPaperToFolderResponse {
  status: number;
  message: string;
  data?: UserDocInfo | undefined;
}

export interface UserDocInfo {
  docId: string;
}

/**
 * 将文从文件夹移除
 * url: /client/doc/removeDocFromFolder
 */
export interface RemoveDocFromFolderReq {
  removedDocItems: RemovedDocItem[];
  isHierarchicallyRemove: boolean;
}

export interface RemovedDocItem {
  docId: string;
  folderId: string;
}

/**
 * 迁移文献到另外一个文件夹(并从原文件夹删除)
 * url: /client/doc/moveDocOrFolderToAnotherFolder
 */
export interface MoveDocOrFolderToAnotherFolderReq {
  movedDocItems: MovedDocItem[];
  movedFolderIds: string[];
  targetFolderId: string;
  /** true=将选中的文献从当前文件夹及其子文件夹下迁移出去,false=只将选中的文献从当前文件夹下迁移出去 */
  isHierarchicallyMoveDoc: boolean;
}

export interface MovedDocItem {
  docId: string;
  sourceFolderId: string;
}

/**
 * 复制文献&文件夹到另外一个文件夹
 * url: /client/doc/copyDocOrFolderToAnotherFolder
 */
export interface CopyDocOrFolderToAnotherFolderReq {
  docIds: string[];
  folderIds: string[];
  targetFolderId: string;
}

/**
 * 添加文件夹
 * url: /client/doc/attachDocToFolder
 */
export interface AttachDocToFolderReq {
  /** 文献id */
  docId: string;
  /** 文件夹id */
  folderId: string;
}

/**
 * 重命名文献
 * url: /userDoc/renameUserDoc
 */
export interface RenameUserDocReq {
  docId: string;
  docName: string;
}

/**
 * 添加文件夹
 * url: /client/doc/addFolder
 */
export interface AddFolderReq {
  /** 父文件夹id */
  parentId: string;
  /** 文件夹名称 */
  name: string;
  /** 文件夹层级,从0开始 */
  level: number;
  /** 文件夹排序 */
  sort: number;
  /** 该层级其他文件夹的id及排序 */
  oldFolderItems: ChangeSortItem[];
}

export interface AddFolderResponse {
  status: number;
  message: string;
  data: FolderInfo[];
}

export interface FolderInfo {
  id: string;
  name: string;
  remark: string;
}

/**
 * 删除文件夹
 * url: /client/doc/deleteDoc
 */
export interface DeleteDocReq {
  docIds: string[];
}

/**
 * 删除文件夹
 * url: /client/doc/deleteFolder
 */
export interface DeleteFolderReq {
  folderIds: string[];
}

/**
 * 更新文件夹备注
 * url: /client/doc/updateFolderRemark
 */
export interface UpdateFolderRemarkReq {
  folderId: string;
  remark: string;
}

/**
 * 更新文件夹
 * url: /client/doc/updateFolder
 */
export interface UpdateFolderReq {
  folderId: string;
  name: string;
}

/**
 * 移动文件夹或者文献
 * url: /client/doc/moveFolderOrDoc
 */
export interface MoveFolderOrDocReq {
  /** 类型:0=文献,1=文件夹 */
  type: number;
  /** 起始文件夹 */
  sourceFolderId: string;
  /** 目标文件夹 */
  targetFolderId: string;
  /** 要移动的id列表,文件夹时为文件夹id,文献时则为文献id */
  movedIds: string[];
  /** 目标位置的所有(文献/文件夹)排序 */
  targetFolderItems: ChangeSortItem[];
}

export interface ChangeSortItem {
  id: string;
  sort: number;
}

/**
 * 文集模式打开文件夹
 * url: /aiKnowledge/userDoc/getUserFolderDetailInfo
 */
export interface GetUserFolderDetailInfoReq {
  folderId: string;
}

export interface GetUserFolderDetailInfoResponse {
  ownerInfo?: UserInfoBean | undefined;
  folderInfo?: FolderInfo | undefined;
  docDetailInfos: DocDetailInfo[];
}

/**
 * 根据folderId获取文献列表
 * url: /client/doc/getDocListByFolderId
 */
export interface GetDocListByFolderIdReq {
  folderId: string;
  /** 排序方式,0=最近添加,1=最近阅读,2=自定义排序 */
  sortType: number;
}

export interface GetDocListByFolderIdResponse {
  status: number;
  message: string;
  data: DocDetailInfo[];
}

/**
 * 根据folderId获取文献列表
 * url: /client/doc/getDocListByFolderIdForPage
 */
export interface GetDocListByFolderIdForPageReq {
  folderId: string;
  currentPage: number;
  pageSize: number;
  sortType?: number | undefined;
  tagIds: string[];
}

export interface GetDocListByFolderIdForPageResponse {
  total: number;
  listDocDetailInfo: DocDetailInfo[];
  list: DocDetailInfoForPage[];
}

export interface DocDetailInfoForPage {
  docId: string;
  docName: string;
  sort: number;
  paperId: string;
  pdfId: string;
  remark: string;
  publishDate: string;
  createDate: string;
  lastReadTime: string;
  isLatestRead: boolean;
  classifyInfos: DocClassifyInfo[];
  paperRepositoryStatus: string;
  /** 期刊会议(新) */
  containerTitles: string[];
  page?: string | undefined;
  noteId: string;
  displayVenue?: DisplayVenue | undefined;
  displayAuthor?: DisplayAuthor | undefined;
  displayPublishDate?: DisplayPublishDate | undefined;
  paperTitle: string;
  docType: string;
  authorList: AuthorInfoForPage[];
  eventTitle?: string | undefined;
  eventPlace?: string | undefined;
  eventDate: string[];
  doi?: string | undefined;
  volume?: string | undefined;
  issue?: string | undefined;
  url?: string | undefined;
  language?: string | undefined;
}

export interface AuthorInfoForPage {
  given: string;
  family: string;
  literal: string;
}

export interface DocDetailInfo {
  docId: string;
  docName: string;
  sort: number;
  paperId: string;
  pdfId: string;
  remark: string;
  publishDate: string;
  createDate: string;
  lastReadTime: string;
  isLatestRead: boolean;
  authors: string[];
  classifyInfos: DocClassifyInfo[];
  paperRepositoryStatus: string;
  /** 期刊会议(新) */
  venues: string[];
  primaryVenue: string;
  noteId: string;
  displayVenue?: DisplayVenue | undefined;
  displayAuthor?: DisplayAuthor | undefined;
  displayPublishDate?: DisplayPublishDate | undefined;
  language?: string | undefined;
  newPaper: boolean;
  /** 分区信息 */
  partition?: string | undefined;
}

export interface DocClassifyInfo {
  classifyId: string;
  classifyName: string;
}

export interface DisplayVenue {
  venue: string;
  rollbackEnable: boolean;
  originVenue: string;
}

export interface DisplayAuthor {
  authors: string[];
  rollbackEnable: boolean;
  originAuthors: string[];
}

export interface DisplayPublishDate {
  publishDate: string;
  rollbackEnable: boolean;
  originPublishDate: string;
}

/**
 * 客户端文献首页-获取文件夹列表和文献列表
 * url: /client/doc/getFolderTreeAndSimpleDocInfoList
 */
export interface GetFolderTreeAndSimpleDocInfoListReq {
}

export interface GetFolderTreeAndSimpleDocInfoListResponse {
  status: number;
  message: string;
  data?: IndexFolderAndDocContent | undefined;
}

export interface IndexFolderAndDocContent {
  totalDocCount: number;
  folderInfos: SimpleFolderInfo[];
  unclassifiedDocInfos: SimpleDocInfo[];
}

export interface SimpleFolderInfo {
  /** 文件夹名 */
  name: string;
  /** 文献数 */
  docCount: number;
  /** 父文件夹id */
  parentId: string;
  /** 文件夹id */
  folderId: string;
  /** 文件夹层级 */
  level: number;
  /** 文件夹排序 */
  sort: number;
  /** 子文件夹 */
  childrenFolders: SimpleFolderInfo[];
  /** 文献信息 */
  docInfos: SimpleDocInfo[];
  /**  */
  isContainCurrentPaper: boolean;
  docId: string;
}

export interface SimpleDocInfo {
  /** 排序 */
  sort: number;
  /** 文献名 */
  docName: string;
  /** 文献id */
  docId: string;
  pdfId: string;
  paperId: string;
}
