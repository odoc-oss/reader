/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.review";

export enum TaskStatus {
  /** WAITING_REVIEW - 任务已创建,等待处理 */
  WAITING_REVIEW = 0,
  /** REVIEWING - 处理中 */
  REVIEWING = 1,
  /** SUCCESS - 已完成 */
  SUCCESS = 2,
  /** FAIL - 失败 */
  FAIL = 3,
  /** CANCEL - 取消 */
  CANCEL = 4,
  /** UPLOAD - 文件上传 */
  UPLOAD = 5,
  /** WAITING_PAY - 如果ai豆不够的话,需要进入待付款状态 */
  WAITING_PAY = 6,
  /** CONSUME_BEAN_FAIL - 扣ai豆失败 */
  CONSUME_BEAN_FAIL = 7,
  UNRECOGNIZED = -1,
}

export enum PaperType {
  /** ADULT_EDUCATION_UNDERGRADUATE_THESIS - 成人教育本科毕业论文 */
  ADULT_EDUCATION_UNDERGRADUATE_THESIS = 0,
  /** FULL_TIME_EDUCATION_UNDERGRADUATE_THESIS - 全日制本科毕业论文 */
  FULL_TIME_EDUCATION_UNDERGRADUATE_THESIS = 1,
  /** GRADUATE_THESIS - 研究生毕业论文 */
  GRADUATE_THESIS = 2,
  /** DOCTORAL_THESIS - 博士生毕业论文 */
  DOCTORAL_THESIS = 3,
  UNRECOGNIZED = -1,
}

export enum LangType {
  /** ZH - 中文 */
  ZH = 0,
  /** EN - 英文 */
  EN = 1,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 毕业论文AI审稿-获取相关配置信息
 * 	接口url:/microservice-ai-review/graduationPaperReview/getConfigInfo
 * 	接口请求方式: GET
 */
export interface GetConfigInfoReq {
}

export interface GetConfigInfoResponse {
  /** 示例文档url */
  exampleFileUrl: string;
  /** 示例图片url */
  examplePicUrl: string;
  /** ai豆原价 */
  originalAiBeanPrice: number;
  /** 当前ai豆价格 */
  currentAiBeanPrice: number;
  /** 1元=多少AI豆 */
  aiBeanAmountOneYuan: number;
}

/**
 * 接口描述: 毕业论文AI审稿-上传
 * 	接口url: /microservice-ai-review/graduationPaperReview/upload
 * 这里前端使用form data，不用json协议
 */
export interface UploadReq {
  file: Uint8Array;
}

export interface UploadResponse {
  /** 创建审稿任务的时候带上这个taskId */
  taskId?:
    | string
    | undefined;
  /** 是否上传成功 */
  isSuccess: boolean;
  /** 上传提示信息.isSuccess为false的时候有值 */
  msg?: string | undefined;
}

/**
 * 接口描述: 毕业论文AI审稿-创建审稿任务
 * 	接口url:/microservice-ai-review/graduationPaperReview/saveTask
 * 	接口请求方式: POST
 */
export interface SaveTaskReq {
  /** UploadResponse返回的taskId */
  taskId: string;
  /** 专业 */
  major: string;
  /** 论文类型 */
  paperType: PaperType;
  /** 论文语言类型 */
  langType: LangType;
}

export interface SaveTaskResponse {
  taskId: string;
  reservedResourceId?: string | undefined;
}

/**
 * 接口描述: 毕业论文AI审稿-取消任务(当升级会员时需要取消任务释放占用的ai豆)
 * 	接口url:/microservice-ai-review/graduationPaperReview/cancelTask
 * 	接口请求方式: POST
 */
export interface CancelTaskReq {
  /** UploadResponse返回的taskId */
  taskId: string;
}

/**
 * 接口描述: 毕业论文AI审稿-根据taskId获取任务信息
 * 	接口url:/microservice-ai-review/graduationPaperReview/getTaskInfo
 * 	接口请求方式: GET
 *  返回 TaskInfo
 */
export interface GetTaskInfoReq {
  taskId: string;
}

/**
 * 接口描述: 毕业论文AI审稿-任务列表
 * 	接口url:/microservice-ai-review/graduationPaperReview/getTaskList
 * 	接口请求方式: GET
 */
export interface GetTaskListReq {
}

export interface GetTaskListResponse {
  taskList: TaskInfo[];
}

export interface TaskInfo {
  id: string;
  /** 提交时间 */
  createDate: string;
  /** 文件名 */
  fileName: string;
  /** 专业 */
  major: string;
  /** 论文类型 */
  paperType: PaperType;
  /** 论文语言类型 */
  langType: LangType;
  /** 任务状态 */
  taskStatus: TaskStatus;
  /** 审稿结果文件url */
  resultFileUrl?:
    | string
    | undefined;
  /** 原文件url */
  originalFileUrl?:
    | string
    | undefined;
  /** 锁豆数量 */
  lockedBeanAmount?: number | undefined;
  reservedResourceId?: string | undefined;
}
