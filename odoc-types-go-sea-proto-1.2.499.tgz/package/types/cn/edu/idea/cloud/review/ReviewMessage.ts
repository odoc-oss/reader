/* eslint-disable */
import type { AcquirePolicyCallbackInfoResponse, UploadBizScene } from "../oss/AliOSS";

export const protobufPackage = "cn.edu.idea.cloud.review";

/**
 * 接口描述: 获取上传到阿里云OSS所需的policy和Callback等信息
 * 	接口url:/microservice-review/review/getFileIsNeedUpload
 * 	接口请求方式: POST
 */
export interface GetFileIsNeedUploadReq {
  scene: UploadBizScene;
  md5: string;
}

export interface GetFileIsNeedUploadResponse {
  data?: AcquirePolicyCallbackInfoResponse | undefined;
  status: number;
  message: string;
}

/**
 * 接口描述:收藏-添加文献
 *   接口url:/review/uploadFromCollection
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface PdfUploadRequest {
  pdfId: string;
}

export interface PdfUploadResponse {
  token: string;
}

/**
 * 接口描述:收藏-添加文献(查询上传进度)
 *   接口url:/review/getUploadProgress
 *   接口请求方式:GET
 */
export interface PdfUploadProgressRequest {
  token: string;
}

export interface PdfUploadProgressResponse {
  progress: number;
  pdfEntity?: PdfEntity | undefined;
  message?: string | undefined;
}

/**
 * 接口描述:删除用户pdf
 *   接口url:/review/deleteUserPdf
 *   接口请求方式:POST
 */
export interface DeleteUserPdfRequest {
  token: string;
}

/**
 * 接口描述:评审分析,入参
 *   接口url:/review/analysis
 *   接口请求方式:POST
 *   参数格式:application/json
 */
export interface PdfAnalysisRequest {
  pdfEntity?: PdfEntity | undefined;
}

export interface PdfAnalysisResponse {
  token: string;
}

/**
 * 接口描述:评审分析(查询评审进度)
 *   接口url:/review/getAnalysisProgress
 *   接口请求方式:GET
 */
export interface PdfAnalysisProgressRequest {
  token: string;
}

export interface PdfAnalysisProgressResponse {
  progress: number;
  reviewResult?: ReviewResult | undefined;
  message?: string | undefined;
}

/**
 * 接口描述:根据用户token获取pdf列表,出参(list)
 *   接口url:/review/getUserPdfs
 *   接口请求方式:GET
 */
export interface UserPdfsResponse {
  pdfList: PdfEntity[];
}

/**
 * 接口描述:根据阿里云私有桶信息生成token并获取可访问url
 *   接口url:/review/generatePdfToken
 *   接口请求方式:POST
 */
export interface PdfUploadBucketRequest {
  bucketName: string;
  objectName: string;
}

export interface PdfUploadBucketResponse {
  pdfEntity?: PdfEntity | undefined;
}

/**
 * 接口描述:根据token获取评审结果缓存
 *   接口url:/review/getReviewResult
 *   接口请求方式:GET
 */
export interface ReviewResultRequest {
  token: string;
}

export interface ReviewResultResponse {
  reviewResult: ReviewResult[];
}

/**
 * 接口描述:根据reviewId删除评审结果缓存
 *   接口url:/review/deleteReviewResult
 *   接口请求方式:POST
 */
export interface ReviewResultDeleteRequest {
  reviewId: string;
}

/**
 * 接口描述:编辑评审结果缓存
 *   接口url:/review/editReviewResult
 *   接口请求方式:POST
 */
export interface ReviewResultEditRequest {
  reviewResult?: ReviewResult | undefined;
}

export interface ReviewResult {
  reviewId: string;
  result: string;
}

export interface PdfEntity {
  token: string;
  pdfUrl: string;
  fileName: string;
}
