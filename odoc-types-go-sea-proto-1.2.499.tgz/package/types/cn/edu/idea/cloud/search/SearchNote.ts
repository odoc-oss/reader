/* eslint-disable */
import type { UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.search";

export enum SortType {
  DEFAULT = 0,
  LAST_READ = 1,
  LAST_ADD = 2,
  UNRECOGNIZED = -1,
}

/**
 * /search/userCenterSearch
 * 搜索我创建的笔记信息
 */
export interface UserCenterSearchRequest {
  /** 搜索内容 */
  searchContent: string;
  currentPage: number;
  sortType: SortType;
  classifyIds: string[];
  pageSize: number;
  folderId: string;
}

export interface UserCenterSearchResponse {
  /** 搜索到的列表数据 */
  items: UserCenterSearchListItem[];
  total: number;
}

export interface UserCenterSearchListItem {
  title: string;
  content: string;
  docInfo?: MyCollectedDocInfo | undefined;
  remark: string;
  docName: string;
}

export interface MyCollectedDocInfo {
  paperId: string;
  pdfId: string;
  sort: number;
  type: number;
  remark: string;
  docName: string;
  classifyInfos: UserDocClassifyInfo[];
  id: string;
  paperRepositoryStatus: string;
  authors: string[];
  journal: string;
  conference: string;
  publishDate: string;
  isLatestRead: boolean;
}

export interface UserDocClassifyInfo {
  classifyId: string;
  classifyName: string;
}

/**
 * /search/groupSearch
 * 搜索我创建的笔记信息
 */
export interface GroupSearchRequest {
  /** 搜索内容 */
  searchContent: string;
  currentPage: number;
  sortType: SortType;
  classifyIds: string[];
  groupId: string;
  pageSize: number;
}

export interface GroupSearchResponse {
  /** 搜索到的列表数据 */
  items: GroupSearchListItem[];
  total: number;
}

export interface GroupSearchListItem {
  title: string;
  content: string;
  remark: string;
  docId: string;
  paperId: string;
  pdfId: string;
  /** 是否存在公开pdf */
  hasPublicPdf: boolean;
  /** 是否存在私密pdf */
  hasPrivatePdf: boolean;
  contributorInfo?: UserInfoBean | undefined;
  paperRepositoryStatus: string;
  groupPdfId?: string | undefined;
}
