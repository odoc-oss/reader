/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.search";

/**
 * 【PDF外部拉取】 从arxiv上下载PDF
 * url: /paper/search/auto_cp
 * method: POST
 */
export interface AutoCpRequest {
  query: string;
  cpType: number;
}

export interface CpMask {
  start: number;
  end: number;
}

export interface CpPaperInfo {
  id: string;
  title: string;
  isCollected: boolean;
  authors: string[];
  ifInsert: boolean;
  mask: CpMask[];
  publishDate: string;
}

export interface AutoCpResponse {
  isSucc: boolean;
  errMsg: string;
  data: CpPaperInfo[];
}
