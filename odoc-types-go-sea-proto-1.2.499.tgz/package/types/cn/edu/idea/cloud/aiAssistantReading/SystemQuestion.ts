/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiAssistantReading";

/**
 * 接口描述: 系统自定义十问
 * 	接口url:/microservice-ai-reading/systemQuestion/list
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface GetQuestionListReq {
}

export interface GetQuestionListResp {
  items: QuestionItem[];
}

export interface QuestionItem {
  /** 问题中文 */
  questionCN: string;
  /** 问题英文 */
  questionEN: string;
}
