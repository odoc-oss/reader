/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiAssistantReading";

/**
 * 接口描述: 辅读信用退豆
 * 	接口url: /refund/aibean
 * 	接口请求方式: post
 * 	参数格式:application/json
 *  service-id: microservice-ai-reading
 */
export interface RefundAiBeanReq {
  /** 理由 */
  reason: string[];
  /** 补充说明 */
  supplementaryExplanation?:
    | string
    | undefined;
  /** 截图 */
  screenshotUrl?:
    | string
    | undefined;
  /** 回答id */
  answerId: string;
}

export interface RefundAiBeanResp {
  /** 优化id，xx分钟内有效 */
  optimizeId: string;
}

/**
 * 接口描述: 优化答案反馈
 * 	接口url:/microservice-ai-reading/optimize/feedback
 * 	接口请求方式: post
 * 	参数格式:application/json
 */
export interface OptimizeFeedbackReq {
  /** 结果反馈 */
  result: string;
  /** 回答id */
  answerId: string;
}

export interface OptimizeFeedbackResp {
}
