/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.aiAssistantReading";

export enum CustomQuestionSortType {
  /** EARLIEST - 最早添加 */
  EARLIEST = 0,
  /** MOST_USE - 最常使用 */
  MOST_USE = 1,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述:添加自定义问题
 * 	接口url:/microservice-ai-reading/customQuestion/add
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface AddQuestionReq {
  /** 问题内容 */
  question: string;
}

export interface AddQuestionResponse {
  /** 自定义问题id */
  questionId: string;
}

/**
 * 接口描述:删除自定义问题
 * 	接口url:/microservice-ai-reading/customQuestion/delete
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface DeleteQuestionReq {
  /** 自定义问题id */
  questionId: string;
}

/**
 * 接口描述:自定义问题提问计数
 * 	接口url:/microservice-ai-reading/customQuestion/useCount
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface QuestionUseCountReq {
  /** 自定义问题id */
  questionId: string;
}

/**
 * 接口描述:自定义问题列表
 * 	接口url:/microservice-ai-reading/customQuestion/getList
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface GetListReq {
  sortType: CustomQuestionSortType;
}

export interface GetListResponse {
  questionList: QuestionInfo[];
}

export interface QuestionInfo {
  id: string;
  question: string;
  /** 提问次数 */
  useCount: number;
}
