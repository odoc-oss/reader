/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.increase";

/**
 * 接口描述: 发货信息列表
 * 	接口url: increase-activity/manage/shippingInfo/getList
 * 	接口请求方式: GET
 * 	参数格式:application/json
 */
export interface GetShippingInfoListReq {
  uin?: string | undefined;
  startCreateDate?: string | undefined;
  endCreateDate?: string | undefined;
  currentPage?: number | undefined;
  pageSize?: number | undefined;
}

export interface GetShippingInfoListResponse {
  total: number;
  items: ShippingInfoItem[];
}

export interface ShippingInfoItem {
  /** 礼包种类&任务名 */
  taskName: string;
  /**  */
  receiver: string;
  mobile: string;
  address: string;
  /** 物流单号 */
  courierNumber: string;
  /** 发货状态,true=已发货,false=未发货 */
  shippingStatus: boolean;
  /** id */
  itemId: string;
}

/**
 * 接口描述: 更改发货信息
 * 	接口url: increase-activity/manage/shippingInfo/updateShippingInfo
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface UpdateShippingInfoReq {
  itemId: string;
  shippingStatus: boolean;
  courierNumber: string;
}

/**
 * 接口描述: 更改发货状态
 * 	接口url: increase-activity/manage/shippingInfo/updateShippingStatus
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface UpdateShippingStatusReq {
  itemId: string;
  shippingStatus: boolean;
}

/**
 * 接口描述: 更改物流单号
 * 	接口url: increase-activity/manage/shippingInfo/updateCourierNumber
 * 	接口请求方式: POST
 * 	参数格式:application/json
 */
export interface UpdateCourierNumberReq {
  itemId: string;
  courierNumber: string;
}
