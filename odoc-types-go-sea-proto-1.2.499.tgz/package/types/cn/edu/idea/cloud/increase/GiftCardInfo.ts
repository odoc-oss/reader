/* eslint-disable */
import type { VipType } from "../user/VipUserInterface";

export const protobufPackage = "cn.edu.idea.cloud.increase";

export enum BindGiftCardStatus {
  /** SUCCESS - 绑定成功 */
  SUCCESS = 0,
  /** EXPIRED - 礼品卡已过期 */
  EXPIRED = 1,
  /** ZERO_AMOUNT - 礼品卡已领完 */
  ZERO_AMOUNT = 2,
  /** ILLEGAL_CODE - 非法的卡号 */
  ILLEGAL_CODE = 3,
  /** DUPLICATE_BIND - 已领取过 */
  DUPLICATE_BIND = 4,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 用户领取礼品卡
 * 	接口url: /increase-activity/giftCard/bind
 * 	接口请求方式: Post
 */
export interface BindGiftCardReq {
  /** 礼品码 */
  code: string;
}

export interface BindGiftCardResp {
  /** 绑定状态 */
  bindStatus: BindGiftCardStatus;
}

/**
 * 接口描述: 获取礼品卡信息
 * 	接口url: /increase-activity/public/giftCard/getGiftCardInfo
 * 	接口请求方式: get
 */
export interface GetGiftCardInfoReq {
  code: string;
}

export interface GetGiftCardInfoResp {
  /** 项目名称 */
  projectName: string;
  /** vip天数 */
  vipDays?:
    | number
    | undefined;
  /** ai辅读天数 */
  aiReadingDays?:
    | number
    | undefined;
  /** ai润色天数 */
  aiPolishDays?:
    | number
    | undefined;
  /** 截止时间 */
  endTime?:
    | string
    | undefined;
  /** 剩余数量 */
  remain?:
    | number
    | undefined;
  /** 是否领取, true=已领取过 */
  isConsume?: boolean | undefined;
  vipType?: VipType | undefined;
  oldVersionGiftCard: boolean;
}
