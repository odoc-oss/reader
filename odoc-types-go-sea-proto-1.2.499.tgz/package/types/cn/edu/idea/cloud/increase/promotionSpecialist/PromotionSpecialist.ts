/* eslint-disable */
import type { InvitationRecord } from "../../user/ProfileInvitationCode";

export const protobufPackage = "cn.edu.idea.cloud.increase.promotionSpecialist";

export enum InviteTaskTypeEnum {
  /** HOLD - 等待开启 */
  HOLD = 0,
  /** CAN_START - 是否能开启任务 */
  CAN_START = 1,
  /** IS_COMPLETED - 任务类型已完成,同一文件不能有重名，改一下名称 */
  IS_COMPLETED = 2,
  /** IS_ADD_ADDRESS - 待填写收货地址 */
  IS_ADD_ADDRESS = 3,
  UNRECOGNIZED = -1,
}

export enum InviteTaskInstanceEnum {
  /** OVERTIME - 已过期 */
  OVERTIME = 0,
  /** IN_PROGRESS - 进行中 */
  IN_PROGRESS = 1,
  /** COMPLETED - 任务实例已完成 */
  COMPLETED = 2,
  /** IS_RECEIVCE - 已接收奖励 */
  IS_RECEIVCE = 3,
  /** IS_HISTORY - 历史任务，不会再被激活，后台用 */
  IS_HISTORY = 4,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 获取开启任务顺序
 *  serviceId: increase-activity
 * 	接口url: /promotionSpecialist/getMyTaskList
 * 	接口请求方式: Get
 */
export interface GetMyTaskListReq {
}

export interface GetMyTaskListResp {
  /** 获取任务列表 */
  taskInfos: TaskInfo[];
}

export interface TaskInfo {
  taskType?: TaskType | undefined;
  taskInstance?: TaskInstance | undefined;
}

export interface TaskType {
  /** 任务id */
  id: string;
  /** 需要邀请人数 */
  numberOfNeedInvit: number;
  /** 奖励信息 */
  awardDescription: string;
  /** 任务顺序 */
  sort: number;
  /** 任务状态 */
  taskTypeStatus: InviteTaskTypeEnum;
}

export interface TaskInstance {
  /** 任务id */
  id: string;
  /** 已邀请人数 */
  nowInvitees: number;
  /** 任务实例状态 */
  taskStatus: InviteTaskInstanceEnum;
  /** 需要邀请的人数 */
  numberOfNeedInvit: number;
}

/**
 * 接口描述: 查看我的邀请记录
 * url: /promotionSpecialist/invitation/record
 * serviceId: increase-activity
 * 接口请求方式: get
 */
export interface GetMyInvitationRecordByTaskReq {
  taskInstanceId: string;
}

export interface GetMyInvitationRecordByTaskResp {
  invitationRecords: InvitationRecord[];
}

/**
 * 接口描述: 开启任务
 *  serviceId: increase-activity
 * 	接口url: /promotionSpecialist/openMyTask
 * 	接口请求方式: post
 */
export interface OpenMyTaskReq {
  taskId: string;
}

export interface OpenMyTaskResp {
  taskInstance?: TaskInstance | undefined;
}

/**
 * 接口描述: 重置任务
 *  serviceId: increase-activity
 * 	接口url: /promotionSpecialist/resetMyTask
 * 	接口请求方式: post
 */
export interface ResetMyTaskReq {
}

/**
 * 接口描述: 查看任务倒计时
 *  serviceId: increase-activity
 * 	接口url: /promotionSpecialist/getCountDown
 * 	接口请求方式: get
 */
export interface GetCountDownReq {
  taskInstanceId: string;
}

export interface GetCountDownResp {
  /** 服务器时间 */
  serverTime: string;
  /** 截止时间 */
  endTime: string;
  /** 获取分享邀请链接 */
  shareInvitUrl: string;
  /** 任务信息 */
  taskInfo?: TaskInfo | undefined;
}

/**
 * 接口描述: 领取奖励，获取收货地址
 *  serviceId: increase-activity
 * 	接口url: /promotionSpecialist/receiveRewards
 * 	接口请求方式: get
 */
export interface ReceiveRewardsReq {
  taskInstanceId: string;
}

export interface ReceiveRewardsResp {
  receiver: string;
  mobile: string;
  address: string;
}

/**
 * 接口描述: 保存收件人地址
 *  serviceId: increase-activity
 * 	接口url: /promotionSpecialist/saveRecipientAddress
 * 	接口请求方式: post
 */
export interface SaveReceiverAddressReq {
  taskInstanceId: string;
  receiver: string;
  mobile: string;
  address: string;
}

export interface SaveReceiverAddressResp {
}

/**
 * 接口描述: 用于验证用户是否已认证（实习生按钮专用）
 *  serviceId: increase-activity
 * 	接口url: /promotionSpecialist/userVerifyStatus
 * 	接口请求方式: post
 */
export interface GetUserVerifyStatusReq {
  /** 场景Id，可以不传 */
  sceneId?: string | undefined;
}

export interface GetUserVerifyStatusResp {
}
