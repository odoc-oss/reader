/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.increase";

export enum InvitationAcceptResultEnum {
  NEW_USER_ACCEPT = 0,
  EXIST_USER_ACCEPT = 1,
  INVITER_HIMSELF = 2,
  UNRECOGNIZED = -1,
}

export enum AcceptStatus {
  /** ACCEPT_SUCCESS -  */
  ACCEPT_SUCCESS = 0,
  EXISTED_USER_ACCEPT = 1,
  /** UNCHECKT_EDU_MAIL - 新版被废弃 */
  UNCHECKT_EDU_MAIL = 2,
  /** UNVERIFIED_MOBLE - 新版被废弃 */
  UNVERIFIED_MOBLE = 3,
  /** NEW_USER_NOT_RELOGIN - 新版被废弃 */
  NEW_USER_NOT_RELOGIN = 4,
  /** WAIT_ACTIVATED - 待激活 */
  WAIT_ACTIVATED = 5,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 获取活动海报
 * 	接口url: increase-activity/term/begin/poster
 * 	接口请求方式: GET
 */
export interface PosterRequest {
  channel: string;
}

export interface PosterResponse {
  posterCdnUrl: string[];
  activityId: string;
}

/**
 * 接口描述: 判断用户是否已完成邮箱认证
 * 	接口url: increase-activity/term/begin/isEduMailVerified
 * 	接口请求方式: GET
 */
export interface IsEduMailVerifiedRequest {
}

export interface IsEduMailVerifiedResponse {
  /** true=已验证 */
  verified: boolean;
}

/**
 * 接口描述: 获取邀请人信息
 * 	接口url: increase-activity/term/begin/inviter
 * 	接口请求方式: GET
 *  参数activityId: 存在于海报的二维码中
 */
export interface InviterRequest {
  activityId: string;
}

export interface InviterResponse {
  nickName: string;
  avatarUrl: string;
  canNotInvite: boolean;
}

/**
 * 接口描述: 接受邀请后的结果
 * 	接口url: increase-activity/term/begin/invitation/accept/result
 * 	接口请求方式: GET
 *  参数activityId: 存在于海报的二维码中
 */
export interface InvitationAcceptResultRequest {
  activityId: string;
}

export interface InvitationAcceptResultResponse {
  invitationAcceptResultEnum: InvitationAcceptResultEnum;
  accepters: Accepter[];
  isVerified: boolean;
}

export interface Accepter {
  nickName: string;
  avatarUrl: string;
  acceptTimestamp: string;
  acceptStatus: AcceptStatus;
  userId: string;
}

/**
 * 接口描述: 获取邀请记录
 * 	接口url: increase-activity/term/begin/inviteList
 * 	接口请求方式: GET
 * 无参数请求,需要用户登录
 */
export interface GetInviteListResponse {
  list: Accepter[];
}

/**
 * 接口描述: 查询是否已验证邮箱
 * 	接口url: increase-activity/term/begin/verified
 * 	接口请求方式: GET
 * 无参数请求,需要用户登录
 */
export interface VerifiedResponse {
  isVerified: boolean;
}

/**
 * 接口描述: 获取邮箱验证码
 * 	接口url: increase-activity/term/begin/email/verify/code
 * 	接口请求方式: GET
 * 需要登录态
 */
export interface GetEmailVerifiedCodeRequest {
  email: string;
  activityId: string;
}

export interface GetEmailVerifiedCodeResponse {
  status: boolean;
  errorMsg: string;
}

/**
 * 接口描述: 验证
 * 	接口url: increase-activity/term/begin/email/verify
 * 	接口请求方式: GET
 * 需要登录态
 */
export interface EmailVerifyRequest {
  email: string;
  code: string;
  activityId: string;
}

export interface EmailVerifyResponse {
  status: boolean;
  errorMsg: string;
}
