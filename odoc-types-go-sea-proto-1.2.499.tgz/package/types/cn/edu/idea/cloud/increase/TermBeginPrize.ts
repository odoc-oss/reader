/* eslint-disable */
import type { UserInfoBean } from "../user/UserInfo";
import type { Accepter } from "./TermBeginActivity";

export const protobufPackage = "cn.edu.idea.cloud.increase";

export enum ExchangeStatusEnum {
  /** EXCHANGE_SUCCESS - 兑换成功 */
  EXCHANGE_SUCCESS = 0,
  /** EXCHANGE_FAIL - 兑换失败 */
  EXCHANGE_FAIL = 1,
  /** UN_EXCHANGED - 未兑换 */
  UN_EXCHANGED = 2,
  /** AUDITING - 审核中 */
  AUDITING = 3,
  /** AUDIT_FAIL - 审核失败 */
  AUDIT_FAIL = 4,
  UNRECOGNIZED = -1,
}

export enum PrizeEnum {
  /**
   * rpvip_7 - 一重礼
   * RP-VIP7天
   */
  rpvip_7 = 0,
  /** rpvip_30 - RP-VIP30天 */
  rpvip_30 = 1,
  /** mtwm_5 - 美团外卖5元红包 */
  mtwm_5 = 2,
  /** wyvip_7 - 网易云黑胶会员周卡 */
  wyvip_7 = 3,
  /** mgvip_7 - 芒果会员周卡 */
  mgvip_7 = 4,
  /** txvip_7 - 腾讯视频会员周卡 */
  txvip_7 = 5,
  /** l1_zfb_30 - 30元支付宝立减金 */
  l1_zfb_30 = 6,
  /** txvip_365 - 腾讯视频会员年卡 */
  txvip_365 = 7,
  /**
   * txvip_30 - 二重礼
   * 腾讯视频会员年卡
   */
  txvip_30 = 8,
  /** l2_zfb_30 - 30元支付宝立减金 */
  l2_zfb_30 = 9,
  /** l2_zfb_50 - 50元支付宝立减金 */
  l2_zfb_50 = 10,
  /**
   * rpvip_365 - 大礼包
   * ReadPaper1年VIP
   */
  rpvip_365 = 11,
  /** idea_ticket - IEAD门票 */
  idea_ticket = 12,
  /** idea_practice - 志愿实习 */
  idea_practice = 13,
  UNRECOGNIZED = -1,
}

/**
 * 接口描述: 获取奖品信息
 * 	接口url: increase-activity/public/term/begin/getPrizeInfo
 * 	接口请求方式: GET
 *  无参数请求
 */
export interface GetPrizeInfoResponse {
  /** 一重礼 */
  l1PrizeInfo?:
    | L1PrizeInfo
    | undefined;
  /** 2重礼 */
  l2PrizeInfo?:
    | L2PrizeInfo
    | undefined;
  /** 3重礼 */
  l3PrizeInfo?:
    | L3PrizeInfo
    | undefined;
  /** RP大礼包 */
  rpPrizeInfo?:
    | RpPrizeInfo
    | undefined;
  /** 邀请记录 */
  inviteList: Accepter[];
  /** 活动开始时间 */
  activityStartTime: string;
  /** 活动结束时间 */
  activityEndTime: string;
  /** 服务器当前时间 */
  serverCurrentTime: string;
  /** 数量等相关配置 */
  config?:
    | CustomConfig
    | undefined;
  /** 有无参加活动资格, true=无,false=有资格 */
  notQualified: boolean;
  /** 邀请码,当notQualified为true的时候才有值 */
  invitationCode?:
    | string
    | undefined;
  /** 是否解锁了奖品,true=已解锁 */
  isUnlock?:
    | boolean
    | undefined;
  /** 使用规则 */
  activityRules: string[];
  /** 当前周激活人数 */
  currentWeekActivateCount?: number | undefined;
}

export interface CustomConfig {
  /** 每次抽奖机会所需的邀请人数 */
  requiredInviteCountPerLuckyChance: number;
  /** 抽奖次数上限 */
  luckyChanceLimit: number;
  /** 开启二重礼所需的邀请人数(>=) */
  requiredInviteCountOpenL2: number;
  /** 获取到二重礼腾讯视频VIP月卡所需的邀请人数(>=) */
  requiredInviteCountPrizeL2TxVip30: number;
  /** 获取到二重礼支付宝30立减金所需的邀请人数(>=) */
  requiredInviteCountPrizeL2Zfb30: number;
  /** 获取到二重礼支付宝50立减金所需的邀请人数(>=) */
  requiredInviteCountPrizeL2Zfb50: number;
  /** 开启三重礼所需的邀请人数(>=) */
  requiredInviteCountOpenL3: number;
  /** 获取到RP大礼包所需的邀请人数(>=) */
  requiredInviteCountRpPrize: number;
  /** 配置的id,前端无需关心该字段 */
  idName: string;
}

export interface RpPrizeInfo {
  /** 二重礼奖品列表 */
  items: RpPrizeInfoItem[];
}

export interface RpPrizeInfoItem {
  /** 奖品id */
  prizeId: string;
  /** 奖品名称 */
  name: string;
  /** 是否已领取当前礼品 */
  isReceived: boolean;
  /** 该礼品是否已经被领取光了 */
  isExhausted: boolean;
}

export interface L3PrizeInfo {
  /** 我的排名 */
  myRanking?:
    | RankingListItem
    | undefined;
  /** 1-25名 */
  rankingList: RankingListItem[];
}

export interface RankingListItem {
  /** 奖品名称(为空时即暂无奖励) */
  prizeName?:
    | string
    | undefined;
  /** 总邀请人数 */
  inviteCount?:
    | number
    | undefined;
  /** 获奖用户信息,没人占据榜一的时候该值为空 */
  userInfo?: UserInfoBean | undefined;
}

export interface L2PrizeInfo {
  /** 二重礼奖品列表 */
  items: L2PrizeInfoItem[];
}

/** 二重礼奖品信息 */
export interface L2PrizeInfoItem {
  /** 奖品id */
  prizeId: string;
  /** 奖品名称 */
  name: string;
  /** 是否已领取 */
  isReceived: boolean;
}

export interface L1PrizeInfo {
  /** 剩余抽奖次数 */
  remainCount?:
    | number
    | undefined;
  /** 中奖播报 */
  broadcasts: BroadcastInfo[];
  /** 是否用完所有的抽奖次数 */
  isExhaustChance: boolean;
}

export interface BroadcastInfo {
  /** 中奖时间 */
  time: string;
  /** 中奖播报信息 */
  broadcast: string;
}

/**
 * 接口描述: 获取中奖记录
 * 	接口url: increase-activity/term/begin/getPrizeRecord
 * 	接口请求方式: GET
 *  无参数请求,需要用户登录
 */
export interface GetPrizeRecordResponse {
  items: PrizeRecordItem[];
}

export interface PrizeRecordItem {
  /** 中奖记录id */
  recordId: string;
  /** 奖品名称 */
  name: string;
  /** 是否为虚拟奖品 */
  isVirtualPrize: boolean;
  /** 奖品是否为vip */
  isVipPrize: boolean;
  /** 使用规则 */
  usageRules?:
    | string
    | undefined;
  /** 兑换的账号 */
  exchangedAccount?:
    | string
    | undefined;
  /** 是否为支付宝立减金 */
  isAliPay: boolean;
  /** 兑换状态 */
  exchangeStatus: ExchangeStatusEnum;
}

/**
 * 接口描述: 一重礼抽奖
 * 	接口url: increase-activity/term/begin/drawLottery
 * 	接口请求方式: POST
 *  无参数请求,需要用户登录
 */
export interface DrawLotteryResponse {
  /** 奖品id */
  prizeId: string;
  /** 奖品名称 */
  name: string;
  /** 中奖记录id */
  recordId: string;
  /** 使用规则 */
  usageRules?: string | undefined;
}

/**
 * 接口描述: 领取奖品到中奖记录
 * 	接口url: increase-activity/term/begin/receivePrize
 * 	接口请求方式: POST
 *  需要用户登录
 */
export interface ReceivePrizeReq {
  /** 奖品id */
  prizeId: string;
}

/**
 * 接口描述: 兑换虚拟奖品
 * 	接口url: increase-activity/term/begin/exchangePrize
 * 	接口请求方式: POST
 *  需要用户登录
 */
export interface ExchangePrizeReq {
  /** 奖品id */
  recordId: string;
  userId?:
    | string
    | undefined;
  /** 领取奖品的账号(手机号) */
  account?: string | undefined;
}

export interface ExchangePrizeResponse {
  exchangeStatus: ExchangeStatusEnum;
  /** 当exchangeStatus为EXCHANGE_FAIL时,该字段有值 */
  errorMsg?: string | undefined;
}
