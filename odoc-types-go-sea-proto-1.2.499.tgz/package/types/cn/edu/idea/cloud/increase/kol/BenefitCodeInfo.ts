/* eslint-disable */
import type { UserInfoBean } from "../../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.increase.kol";

/**
 * 接口描述: 绑定福利码与uid
 * 	接口url: /increase-activity/public/kol/submitBind
 * 	接口请求方式: Post
 */
export interface SubmitBindCodeReq {
  code: string;
  token: string;
  userId: string;
}

export interface SubmitBindCodeResp {
  /** 是否消费成功 */
  consumeSuccess: boolean;
}

/**
 * 接口描述: 查看福利绑定状态
 * 	接口url: /increase-activity/public/kol/getBindStatus
 * 	接口请求方式: get
 */
export interface GetBindStatusReq {
  token: string;
  userId: string;
}

export interface GetBindStatusResp {
  /** 是否已绑定 */
  isBind: boolean;
  code: string;
}

/**
 * 接口描述: 获取福利信息
 * 	接口url: /increase-activity/public/kol/getInfo
 * 	接口请求方式: get
 */
export interface GetInfoReq {
  code: string;
  userId: string;
}

export interface GetInfoResp {
  /** 项目名称 */
  projectName: string;
  /** vip天数 */
  vipDays?:
    | number
    | undefined;
  /** ai辅读天数 */
  aiReadingDays?:
    | number
    | undefined;
  /** 模拟多少天内有人加入 */
  joinPersons: number;
  /** 领卡成功后的文案 */
  successCopywriting: string;
}

/**
 * 接口描述: 绑定福利码与uid
 * 	接口url: /increase-activity/public/kol/getCountDown
 * 	接口请求方式: get
 */
export interface GetCountDownReq {
  code: string;
  userId: string;
}

export interface GetCountDownResp {
  /** 服务器时间 */
  serverTime: string;
  /** 绑定时间 */
  bindTime: string;
  /** 邀请了哪些人加入 */
  userInfo: UserInfoBean[];
  /** 获取分享邀请链接 */
  shareInvitUrl: string;
}

/**
 * 接口描述: 获取海报
 * 	接口url: /increase-activity/public/kol/getPoster
 * 	接口请求方式: get
 */
export interface GetPosterReq {
  userId: string;
}

export interface GetPosterResp {
  /** 海报cdn地址 */
  posterCdnUrl: string;
}
