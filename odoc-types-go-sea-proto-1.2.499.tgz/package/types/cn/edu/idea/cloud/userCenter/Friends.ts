/* eslint-disable */
import type { UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.userCenter";

/**
 * 添加关注
 * url: /friends/addIdol
 */
export interface AddIdolRequest {
  /** 被关注者id */
  idolId: string;
}

/**
 * 取消关注
 * url: /friends/removeIdol
 */
export interface RemoveIdolRequest {
  /** 被关注者id */
  idolId: string;
}

/**
 * 关注列表
 * url: /friends/idolList
 */
export interface IdolListRequest {
  currentPage: number;
  pageSize: number;
}

export interface IdolListResponse {
  total: number;
  list: FriendsInfo[];
}

/**
 * 粉丝列表
 * url: /friends/fansList
 */
export interface FansListRequest {
  currentPage: number;
  pageSize: number;
}

export interface FansListResponse {
  total: number;
  list: FriendsInfo[];
}

export interface FriendsInfo {
  /** 是否互相关注 */
  friendFlag: boolean;
  userInfo?: UserInfoBean | undefined;
}
