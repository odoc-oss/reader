/* eslint-disable */
import type { GroupDocInfo } from "../groups/GroupDoc";
import type { UserInfoBean } from "../user/UserInfo";

export const protobufPackage = "cn.edu.idea.cloud.userCenter";

export enum SortType {
  DEFAULT = 0,
  LAST_READ = 1,
  LAST_ADD = 2,
  UNRECOGNIZED = -1,
}

/** 用户文献创建状态 */
export enum UserDocCreateStatus {
  UPLOAD = 0,
  PARSE = 1,
  MATCH = 2,
  FINISH = 3,
  ERROR = 4,
  CANCEL = 5,
  CONFLICT = 6,
  GROUP_OTHER_VERSION = 7,
  SELF_OTHER_VERSION = 8,
  DOC_COUNT_OVERFLOW = 9,
  DOC_COUNT_OVERFLOW_FOR_ALL_USER = 10,
  UNRECOGNIZED = -1,
}

/** 文献创建场景 */
export enum CreateDocScene {
  /** SCENE_DEFAULT - 历史问题原因，【个人】和【小组】都算作DEFAULT */
  SCENE_DEFAULT = 0,
  /**
   * SCENE_VERIFY - SCENE_PERSONAL = 2;
   * SCENE_GROUP = 3;
   */
  SCENE_VERIFY = 1,
  UNRECOGNIZED = -1,
}

/**
 * 获取用户的PDF上传状态
 * url= /userDoc/GetUserDocCreateStatus
 */
export enum ConflictScene {
  SCENE_GROUP = 0,
  SCENE_GROUP_DISCUSS = 1,
  SCENE_PERSONAL = 2,
  UNRECOGNIZED = -1,
}

/**
 * 识别pdf语言
 * method:GET
 * url:/aiKnowledge/userDoc/getPdfLang
 */
export interface GetPdfLangReq {
  pdfId: string;
}

export interface GetPdfLangResponse {
  status: number;
  message: string;
  /** 语言信息,english/chinese */
  data: string;
}

/**
 * 收藏论文
 * url: /userDoc/collectPaper
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1003
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/835
 */
export interface CollectPaperRequest {
  /** 论文id */
  paperId: string;
  folderId: string;
  paperTitle: string;
}

export interface CollectPaperResponse {
  /** 文献id */
  id: string;
}

/**
 * 获取我收藏论文的分类
 * url: /userDoc/getMyCollectedPaperClassifyList
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1007
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/853
 */
export interface GetMyCollectedPaperClassifyListRequest {
  /** 论文id */
  paperId: string;
}

/**
 * 取消收藏论文
 * url: /userDoc/cancelCollectPaper
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1015
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/862
 */
export interface CancelCollectPaperRequest {
  /** 论文id */
  paperId: string;
}

/**
 * 保存分类
 * url: /userDoc/addClassify
 */
export interface AddClassifyRequest {
  classifyName: string;
}

export interface AddClassifyResponse {
  classifyName: string;
  classifyId: string;
}

/**
 * 更新分类
 * url: /userDoc/updateClassify
 */
export interface UpdateClassifyRequest {
  classifyName: string;
  remark: string;
  classifyId: string;
}

export interface UpdateClassifyResponse {
  classifyName: string;
  classifyId: string;
}

/**
 * 删除收藏的文献
 * url: /userDoc/deleteUserDoc
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1011
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/871
 */
export interface DeleteUserDocRequest {
  /** 文献id */
  docId: string;
}

/**
 * 置顶文献
 * url: /userDoc/userDocTopSetting
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1019
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/880
 */
export interface UserDocTopSettingRequest {
  /** 文献id */
  docId: string;
}

/**
 * 更新文献备注
 * url: /userDoc/updateDocRemark
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1023
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/889
 */
export interface UpdateDocRemarkRequest {
  /** 文献id */
  docId: string;
  remark: string;
}

/**
 * 我收藏的文献-列表形式
 * url: /userDoc/getMyCollectedDocList
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1027
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/898
 */
export interface GetMyCollectedDocListRequest {
  sortType: SortType;
  classifyIds: string[];
  currentPage: number;
  pageSize: number;
}

export interface GetMyCollectedDocListResponse {
  total: number;
  list: MyCollectedDocInfo[];
}

/**
 * 我收藏的文献-文件夹形式
 * url: /userDoc/getUserCollectedDocFolder
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1031
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/907
 */
export interface GetMyCollectedDocFolderRequest {
  ownerId: string;
}

export interface GetMyCollectedDocFolderResponse {
  status: number;
  message: string;
  data: UserDocClassifyInfo[];
}

/**
 * 已分类的文献标签详情页
 * url: /aiKnowledge/userDoc/getClassifiedDocDetail
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1035
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/916
 */
export interface GetClassifiedDocDetailRequest {
  classifyId: string;
  currentPage: number;
  pageSize: number;
}

export interface GetClassifiedDocDetailResponse {
  total: number;
  items: MyCollectedDocInfo[];
  ownerInfo?: UserInfoBean | undefined;
  classifyInfo?: UserDocClassifyInfo | undefined;
}

/**
 * 未分类的文献标签详情页
 * url: /userDoc/getUnClassifiedDocDetail
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1039
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/925
 */
export interface GetUnClassifiedDocDetailRequest {
  currentPage: number;
  pageSize: number;
}

export interface GetUnClassifiedDocDetailResponse {
  total: number;
  items: MyCollectedDocInfo[];
  ownerInfo?: UserInfoBean | undefined;
  classifyInfo?: UserDocClassifyInfo | undefined;
}

/**
 * 改变文献的排序
 * url: /userDoc/changeDocSort
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1043
 */
export interface ChangeNoteSortRequest {
  /** 论文id */
  id1: string;
  sort1: number;
  id2: string;
  sort2: string;
}

/**
 * 删除分类
 * url: /userDoc/deleteClassify
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1059
 */
export interface DeleteClassifyRequest {
  classifyId: string;
}

/**
 * 改变文献的排序
 * url: /userDoc/changeDocClassifySort
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1063
 */
export interface ChangeDocClassifySortRequest {
  items: ChangeDocClassifySortItem[];
}

export interface ChangeDocClassifySortItem {
  id: string;
  sort: number;
}

/**
 * 论文关联分类
 * url: /userDoc/attachPaperToClassify
 */
export interface AttachPaperToClassifyRequest {
  classifyId: string;
  paperId: string;
}

/**
 * 移除论文分类
 * url: /userDoc/removePaperFromClassify
 */
export interface RemovePaperFromClassifyRequest {
  classifyId: string;
  paperId: string;
}

/**
 * 获取用户的所有分类
 * url: /userDoc/getUserAllClassifyList
 * yapi: http://yapi.team.idea.edu.cn/project/24/interface/api/1067
 * yapi测试: http://yapi.team.idea.edu.cn/project/24/interface/case/979
 */
export interface GetUserAllClassifyListRequest {
}

export interface GetUserAllClassifyListResponse {
  status: number;
  message: string;
  data: UserDocClassifyInfo[];
}

/**
 * 文献关联分类
 * url: /userDoc/attachDocToClassify
 */
export interface AttachDocToClassifyRequest {
  classifyId: string;
  docId: string;
}

/**
 * 文献移除分类
 * url: /userDoc/removeDocFromClassify
 */
export interface RemoveDocFromClassifyRequest {
  classifyId: string;
  docId: string;
}

export interface AttachDocToClassifyResponse {
  status: number;
  message: string;
}

export interface MyCollectedDocInfo {
  ownerNoteId: string;
  paperId: string;
  pdfId: string;
  userId: string;
  sort: number;
  type: number;
  remark: string;
  docName: string;
  lastReadTime: string;
  classifyInfos: UserDocClassifyInfo[];
  id: string;
  isLatestRead: boolean;
  paperRepositoryStatus: string;
  authors: string[];
  journal: string;
  conference: string;
  publishDate: string;
}

export interface UserDocClassifyInfo {
  classifyId: string;
  classifyName: string;
  docCount: number;
  sort: number;
  isContain: boolean;
  remark: string;
}

export interface ConflictDocInfo {
  originPdfId: string;
  conflictPdfId: string;
  conflictNoteId: string;
  folderId: string;
  scene: ConflictScene;
}

export interface GetUserDocCreateStatusRequest {
  token: string;
}

export interface GetUserDocCreateStatusResponse {
  status: UserDocCreateStatus;
  msg: string;
  docInfo?: MyCollectedDocInfo | undefined;
  groupDocInfo?: GroupDocInfo | undefined;
  conflictPdfId?: ConflictDocInfo | undefined;
  pdfId: string;
  /** 在没有新建文献的情况下，是否替换了之前在阅读的PDF */
  pdfUpdated: boolean;
}

/**
 * 根据MD5预处理是否需要上传，如果不需要上传直接关联用户与同MD5的PDF
 * url= /userDoc/GetPdfNeedUploadPdf
 */
export interface GetPdfNeedUploadPdfRequest {
  md5: string;
  fileName: string;
  groupId: string;
  classifyId: string;
  scene: CreateDocScene;
  paperId: string;
  folderId: string;
}

export interface GetPdfNeedUploadPdfResponse {
  needUpload: boolean;
  /** 只有在不需要上传的时候返回docInfo */
  docInfo?:
    | MyCollectedDocInfo
    | undefined;
  /** 是不是自己已有的文献 */
  selfRepeat: boolean;
  groupDocInfo?:
    | GroupDocInfo
    | undefined;
  /** 小组内已有他人上传 */
  groupRepeat: boolean;
  /** 冲突信息 */
  conflictDocInfo?:
    | ConflictDocInfo
    | undefined;
  /** 用来解除冲突的token */
  token: string;
  /** 不用上传PDF的情况下，是否替换了之前在阅读的PDF */
  pdfUpdated: boolean;
}

/**
 * 获取上传文件token
 * url= /userDoc/GetUploadToken
 * method= GET
 */
export interface GetTokenRequest {
  md5: string;
  fileName: string;
  groupId: string;
  classifyId: string;
  scene: CreateDocScene;
  paperId: string;
  folderId: string;
}

export interface GetTokenResponse {
  needUpload: boolean;
  /** 只有在不需要上传的时候返回docInfo */
  docInfo?:
    | MyCollectedDocInfo
    | undefined;
  /** 是不是自己已有的文献 */
  selfRepeat: boolean;
  groupDocInfo?:
    | GroupDocInfo
    | undefined;
  /** 小组内已有他人上传 */
  groupRepeat: boolean;
  /** 冲突信息 */
  conflictDocInfo?:
    | ConflictDocInfo
    | undefined;
  /** 用来解除冲突的token */
  conflictToken: string;
  /** 用来上传文件的token */
  uploadToken: string;
  /** 用来查询文献创建状态的token */
  queryStatusToken: string;
  /** 不用上传PDF的情况下，是否替换了之前在阅读的PDF */
  pdfUpdated: boolean;
}

/**
 * 取消文献的创建
 * url= /userDoc/cancelUserDocCreate
 */
export interface CancelUserDocCreateRequest {
  token: string;
}

export interface CancelUserDocCreateResponse {
  nextStatus: UserDocCreateStatus;
}

/**
 * 解决文档生成冲突
 * url= /userDoc/resolveConflict
 */
export interface ResolveConflictRequest {
  token: string;
  /** 如果为True则使用原来的PDF，为False使用新的PDF */
  useOrigin: boolean;
}

export interface ResolveConflictResponse {
  newPdfId: string;
  /** 个人上传场景返回这个 */
  docInfo?:
    | MyCollectedDocInfo
    | undefined;
  /** 小组上传场景返回这个 */
  groupDocInfo?: GroupDocInfo | undefined;
}
