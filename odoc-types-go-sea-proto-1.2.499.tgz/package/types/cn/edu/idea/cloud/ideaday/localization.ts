/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.ideaday";

/** POST /ideaday/localization */
export interface LocalizationRequest {
  authorId: string;
}

export interface LocalizationResponse {
  avatarUrl: string;
  paperList: LocalizationPaperInfo[];
}

export interface LocalizationPaperInfo {
  id: string;
  name: string;
}

/** POST /ideaday/citation */
export interface CitationRequest {
  paperid: string;
}

export interface CitationResponses {
  edges: string[];
  nodes: CitationNode[];
}

export interface CitationNode {
  id: string;
  cls: string;
  globalCitation: string;
  kws: string[];
  localCitation: number;
  publishdate: string;
  semanticSimi: number;
  title: string;
}
