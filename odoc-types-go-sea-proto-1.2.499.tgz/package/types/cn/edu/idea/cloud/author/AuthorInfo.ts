/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.author";

export interface BaseAuthorInfo {
  id: string;
  name: string;
  /** 是否认证作者 */
  isAuthentication: boolean;
}

export interface SimpleAuthorInfo {
  id: string;
  name: string;
}
