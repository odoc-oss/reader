/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.common";

/** 通用错误码，非单一领域专用，范围：1-9999 */
export enum ErrorCode {
  /** SUCCESS - ErrorCode begin, append your error code below */
  SUCCESS = 0,
  /** ERR_UNLOGIN - 无法获取登录太 */
  ERR_UNLOGIN = 1,
  /** ERR_ACCESS_CONTROL - 无法获取访问权限信息 */
  ERR_ACCESS_CONTROL = 2,
  /** ERR_SITE_INFO - 无法获取站点信息 */
  ERR_SITE_INFO = 3,
  /** ERR_UNKNOW - ErrorCode end, do not edit below area */
  ERR_UNKNOW = 10000,
  UNRECOGNIZED = -1,
}

export interface ResponseInfo {
  /** 参考common及各领域下 ErrorCode */
  errCode: number;
  msg: string;
}

/** 分页相关 */
export interface PageRequest {
  pageNum: number;
  pageSize: number;
}

/** 分页相关 对应cn.edu.idea.cloud.common.page.PageQuery */
export interface PageQuery {
  currentPage: number;
  pageSize: number;
}

export interface PageResponse {
  pageNum: number;
  isFirstPage: boolean;
  isLastPage: boolean;
  total: number;
}
