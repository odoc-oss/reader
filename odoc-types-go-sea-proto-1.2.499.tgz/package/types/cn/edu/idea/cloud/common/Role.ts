/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.common";

export enum PlatformRoleEnum {
  PLATFORM_ADMINISTRATOR = 0,
  UNRECOGNIZED = -1,
}
