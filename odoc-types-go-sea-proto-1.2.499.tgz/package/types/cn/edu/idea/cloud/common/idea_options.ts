/* eslint-disable */

export const protobufPackage = "cn.edu.idea.cloud.common";
