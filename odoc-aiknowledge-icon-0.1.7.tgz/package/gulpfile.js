const gulp = require("gulp");
const iconfont = require("gulp-iconfont");
const iconfontCss = require("gulp-iconfont-css");
const template = require("gulp-template");
const fs = require("fs");
const fontName = "icon";

// 构建任务
gulp.task("build", () => {
  console.log("🚀 ~ file: gulpfile.js ~ line 41 ~ gulp.task ~ build");

  return gulp
    .src("./svg/*.svg")
    .pipe(
      iconfontCss({
        fontName: fontName,
        path: "./templates/iconfont.css",
        targetPath: "../css/iconfont.css",
        fontPath: "../fonts/",
      })
    )
    .pipe(
      iconfont({
        fontName: fontName,
        formats: ["svg", "ttf", "eot", "woff", "woff2"],
        normalize: true,
        fontHeight: 1001,
      })
    )
    .on("glyphs", function (glyphs, options) {
      // CSS templating, e.g.
      //console.log(glyphs, options);
    })
    .pipe(gulp.dest("./dist/fonts/"));
});

let icons = fs.readdirSync("svg");

icons = icons.map(function (icon) {
  return icon.replace(/\.\w+$/, "");
});

// 示例文件
gulp.task("example", function () {
  return gulp
    .src(`./templates/index.html`) //样式例子文件
    .pipe(template({ icons: icons, cssName: "iconfont" }))
    .pipe(gulp.dest("./example")); //样式例子文件存放位置
});

exports.default = {};
