# 安装依赖

```
yarn install
```

# 构建

```
yarn build
```

# 发布

```
npm publish --registry=http://192.168.230.115:4873/
```

# 查看效果

打开 `example/index.html` 可预览所有 icon

# 备注

如果 icon 显示异常，可能是文件格式有误，可将 svg 上传到 https://icomoon.io/app/#/select 再替换掉，即可正常显示

# 使用

全局引入 css

```js
import "@odoc/aiknowledge-icon/dist/css/iconfont.css";
```

```html
<i class="aiknowledge-icon icon-apple-fill"></i>
```
