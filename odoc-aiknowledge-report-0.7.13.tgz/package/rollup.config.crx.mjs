import typescript from '@rollup/plugin-typescript';
import { getCommonConfig, SCENE_PATH } from './rollup.config.mjs';

const crxConfig = getCommonConfig();
crxConfig.plugins.unshift(typescript({
  tsconfig: './tsconfig.crx.json',
}))
crxConfig.resolve.alias[SCENE_PATH] = 'src/scene-crx';
crxConfig.output.push({
  file: 'dist/report.crx.js',
  format: 'umd',
  name: 'aiKnowledgeReporter',
})

export default crxConfig
