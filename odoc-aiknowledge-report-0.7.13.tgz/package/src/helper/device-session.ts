import { ShareSessionStorage } from '@odoc/aiknowledge-special-util/share-session-storage';
import { once } from '@odoc/aiknowledge-special-util/once';
import fingerprint from '@fingerprintjs/fingerprintjs';
import Cookies from 'js-cookie';

import { uuidv4 } from './uuid';
import { detectPlatform } from './platform';

export const STORAGE_DEVICE_ID = 'REPORT_DEVICE_ID';
export const COOKIE_TRAFFIC_RANDOM_NUMBER = 'traffic-number';
export const CHANNEL_DEVICE_ID = 'electron-client-device-id';
export const CHANNEL_SESSION_ID = 'electron-client-session-id';

let webDeviceIdPromise: Promise<void> | null = null

const getWebDeviceId = async () => {

  if (!localStorage.getItem(STORAGE_DEVICE_ID)) {
    if (!webDeviceIdPromise) {
      webDeviceIdPromise = (async () => {
        const load = await fingerprint.load();
        const get = await load.get();
        localStorage.setItem(STORAGE_DEVICE_ID, get.visitorId);
      })()
    }

    await webDeviceIdPromise;
  }

  return localStorage.getItem(STORAGE_DEVICE_ID)!;
};

const invokeElectronWithCache = <T = string>(
  channel: string,
  params: any = {}
) => {
  let promise: Promise<T> | null = null;
  return () => {
    if (!promise) {
      promise = (async () => {
        const deviceResult = await (
          window as any
        ).electron?.readpaperBridge?.invoke(channel, params);
        return deviceResult?.data ?? '';
      })();
    }

    return promise;
  };
};

const getElectronDeviceId = invokeElectronWithCache(
  CHANNEL_DEVICE_ID,
  {}
);

export const getDeviceId = async () => {
  const { isElectron, isChromeExtension } = detectPlatform();
  let deviceId = '';

  if (isElectron) {
    deviceId = await getElectronDeviceId();
  } else if (isChromeExtension) {
    return deviceId
  } else {
    deviceId = await getWebDeviceId()
  }

  if (typeof window !== 'undefined' && window.location.protocol.startsWith('http')) {
    const expires = new Date();
    expires.setDate(expires.getDate() + 400)
    Cookies.set('guid', deviceId, {
      expires,
      secure: window.location.protocol.startsWith('https'),
      domain: '.' + window.location.host,
      path: '/',
    });
  }

  return deviceId;
};

const getElectronSessionId = invokeElectronWithCache(
  CHANNEL_SESSION_ID,
  {}
);

const getWebSessionId = once(async () => {
  const webShare = new ShareSessionStorage('SESSION_ID');
  webShare.exportable = true;
  webShare.importable = true;
  await webShare.importFromOtherTab();
  webShare.importable = false;

  if (!webShare.value) {
    webShare.value = uuidv4();
  }

  return webShare.value;
});

const getChromeExtensionSessionId = once(uuidv4);

export const getSessionId = async (): Promise<string> => {
  const { isElectron, isChromeExtension } = detectPlatform();
  if (isElectron) {
    return getElectronSessionId();
  }

  if (isChromeExtension) {
    return getChromeExtensionSessionId();
  }

  return getWebSessionId();
};
