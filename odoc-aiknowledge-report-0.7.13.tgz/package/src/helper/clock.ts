import { RenewWatch } from '@odoc/aiknowledge-special-util/stopwatch'

export class Clock {
  private static isClient = typeof window !== 'undefined';

  public static renewWatch = new RenewWatch();
  public static renew() {
    return Clock.renewWatch.start();
  }
  private static listening = false;
  private static listen() {
    if (!Clock.isClient || Clock.listening) {
      return;
    }

    Clock.listening = true;

    const listenerOptions: AddEventListenerOptions = {
      capture: true,
      passive: true,
    };

    if (typeof document === 'undefined') {
      return
    }

    document.addEventListener('mousedown', Clock.renew, listenerOptions);
    document.addEventListener('mouseup', Clock.renew, listenerOptions);
    document.addEventListener('mousemove', Clock.renew, listenerOptions);
    document.addEventListener('keydown', Clock.renew, listenerOptions);
    document.addEventListener('keyup', Clock.renew, listenerOptions);
    document.addEventListener('dragstart', Clock.renew, listenerOptions);
    document.addEventListener('dragover', Clock.renew, listenerOptions);
    document.addEventListener('drop', Clock.renew, listenerOptions);
    document.addEventListener('touchstart', Clock.renew, listenerOptions);
    document.addEventListener('touchend', Clock.renew, listenerOptions);
    document.addEventListener('touchcancel', Clock.renew, listenerOptions);
    document.addEventListener('touchmove', Clock.renew, listenerOptions);
    document.addEventListener('scroll', Clock.renew, listenerOptions);
  }

  public static get isActive() {
    return (
      Clock.isClient &&
      document.visibilityState === 'visible' &&
      Clock.renewWatch.isActive
    );
  }

  private timeoutId = 0;

  private count = 0;

  private readonly callbackMap = new Map<number, Set<() => void>>();

  public constructor(private intervalSeconds = 30) {
    this.tick();
    Clock.renew();
    if (!Clock.listening) {
      Clock.listen();
    }

    if (Clock.isClient) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any).debugClock = this;
    }
  }

  private tick() {
    if (!Clock.isClient) {
      return;
    }

    this.timeoutId = window.setTimeout(() => {
      this.tock();
    }, 1000);
  }

  private tock() {
    this.tick();

    if (Clock.isActive) {
      this.count += 1;
      this.invoke();
    }
  }

  public add(callback: () => void) {
    const exists = [...this.callbackMap.values()].some((callbackSet) =>
      callbackSet.has(callback)
    );
    if (exists) {
      return;
    }

    if (!this.callbackMap.has(this.mod)) {
      this.callbackMap.set(this.mod, new Set());
    }

    this.callbackMap.get(this.mod)?.add(callback);
  }

  public remove(callback: () => void) {
    [...this.callbackMap.values()].forEach((callbackSet) => {
      if (callbackSet.has(callback)) {
        callbackSet.delete(callback);
      }
    });
  }

  private get mod() {
    return this.count % this.intervalSeconds;
  }

  private invoke() {
    const callbackSet = this.callbackMap.get(this.mod);
    if (callbackSet) {
      [...callbackSet].forEach((callback) => callback());
    }
  }

  public destroy() {
    if (!Clock.isClient) {
      return;
    }

    window.clearTimeout(this.timeoutId);
    this.callbackMap.clear();
  }
}
