import { once } from '@odoc/aiknowledge-special-util/once';
import { ShareSessionStorage } from '@odoc/aiknowledge-special-util/share-session-storage';
import { ChannelAndReferer } from '@odoc/aiknowledge-report-common';
import { detectPlatform } from './platform';

const defaultChannelAndReferer: ChannelAndReferer = {
  channel: '',
  referer: '',
  referer_detail: '',
};

const getChannel = () => {
  if (typeof URLSearchParams === 'undefined') {
    return '';
  }

  return new URLSearchParams(location.search).get('channel') || '';
};

const getReferer = () => {
  const searchReferer = new URLSearchParams(location.search).get('referer');
  const referer = searchReferer || document.referrer;
  if (referer.includes(location.hostname)) {
    return '';
  }

  return referer;
};

const getDomain = (url: string) => {
  return url
    .replace(/^https?:\/\//, '')
    .replace(/\/.*/, '');
};

/**
 * 初始化channel和referer
 * 自己有channel或referer则以自己为准
 * 没有则从其他tab读取
 * 注意，初始化后本tab的channel和referer不会再改变
 * 即使后续用户开了其他有channel和referer的tab，改变了sessionStorage里的值
 * 也不影响本tab缓存的channel和referer
 *  */
export const getChannelAndReferer = once(
  async (): Promise<ChannelAndReferer> => {
    if (detectPlatform().isChromeExtension) {
      return {
        channel: '',
        referer: '',
      };
    }

    const originalChannel = getChannel();
    const originalReferer = getReferer();
    const crShareSession = new ShareSessionStorage('CHANNEL_REFERER');
    crShareSession.exportable = true;

    if (!originalChannel && !originalReferer) {
      crShareSession.importable = true;
      await crShareSession.importFromOtherTab();
      crShareSession.importable = false;

      const channelAndReferer: ChannelAndReferer = crShareSession.value
        ? JSON.parse(crShareSession.value)
        : { ...defaultChannelAndReferer };
      return channelAndReferer;
    } else {
      const channelAndReferer: ChannelAndReferer = {
        channel: originalChannel,
        referer: getDomain(originalReferer),
        referer_detail: originalReferer,
      };
      const sharedData = JSON.stringify(channelAndReferer);
      crShareSession.value = sharedData;
      return channelAndReferer;
    }
  }
);
