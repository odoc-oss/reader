let platformInfo: {
  isI18n: boolean;
  isElectron: boolean;
  isChromeExtension: boolean;
  isIpad: boolean;
  platform: string;
} | null = null;

const patternMobile = /(android|iphone|ipad|ipod|blackberry|windows phone)/i;

export const detectPlatform = () => {
  if (platformInfo) {
    return platformInfo;
  }

  const ua = navigator.userAgent.toLowerCase();
  const url = typeof window !== 'undefined' && window.location
    ? window.location.href
    : '';

  const isI18n = ua.indexOf('i18n/') !== -1;
  const isElectron = ua.indexOf(' electron/') !== -1 && ua.indexOf('readpaper') !== -1;

  const isH5 = patternMobile.test(ua);
  const isChromeExtension = location.protocol === 'chrome-extension:';

  const isIpad =
    !isChromeExtension &&
    (ua.indexOf('ipad') !== -1 ||
      (ua.indexOf('safari') !== -1 &&
        ua.indexOf('version') !== -1 &&
        ua.indexOf('iphone') === -1 &&
        'ontouchend' in document));

  let platform = isElectron ? 'pc' : isH5 ? 'h5' : 'web';
  if (isI18n || url.includes('/en/')) {
    platform += '_en';
  }

  platformInfo = {
    isI18n,
    isElectron,
    isChromeExtension,
    isIpad,
    platform,
  };

  return platformInfo;
};
