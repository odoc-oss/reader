import bowser from 'bowser';

const browserAndOs: {
  browser_type?: string;
  browser_version?: string;
  browser_language?: string;
  os_name: string;
} = {
  os_name: '',
};

export const getBrowserAndOs = (isElectron: boolean) => {
  if (!browserAndOs.os_name) {
    const parser = bowser.getParser(navigator.userAgent);
    const os = parser.getOSName();
    browserAndOs.os_name = convertOsName(os);

    if (!isElectron) {
      const info = parser.getBrowser();
      browserAndOs.browser_type = info.name || '';
      browserAndOs.browser_version = info.version || '';
    }
  }

  browserAndOs.browser_language = navigator.language || '';

  return browserAndOs;
};

export const convertOsName = (bowserOsName: string) => {
  if (bowserOsName === 'macOS') {
    if (isIpadPro()) {
      return 'iOS';
    } else {
      return 'MacOS';
    }
  } else {
    return bowserOsName.replace(/ /g, '');
  }
};

export const isIpadPro = () => {
  return navigator.maxTouchPoints && navigator.maxTouchPoints > 2 && /MacIntel/.test(navigator.platform);
};
