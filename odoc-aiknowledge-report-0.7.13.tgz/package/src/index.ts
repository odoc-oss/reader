import { AbstractReporter } from '@odoc/aiknowledge-report-common';

import { post, get } from '~scene/net';
import { defaultGetUrl, generateData } from '~scene/generate';
import { defaultGetUin } from '~scene/uin';
import { defaultGetLanguage } from '~scene/lang';

export class Reporter extends AbstractReporter {
  public constructor() {
    super();
    this.config.getUin = defaultGetUin;
    this.config.getLanguage = defaultGetLanguage;
    this.config.axios = { post, get };
  }

  public headers: Record<string, string> = {};

  public getUrl = defaultGetUrl;

  public generateData = generateData;
}

let reporter: Reporter;

if (typeof window !== 'undefined') {
  const AIKnowledgeReporter = 'AIKnowledgeReporter';
  if (!(window as any)[AIKnowledgeReporter]) {
    (window as any)[AIKnowledgeReporter] = new Reporter();
  }

  reporter = (window as any)[AIKnowledgeReporter] as Reporter;
} else {
  reporter = new Reporter();
}

export default reporter;
export { reporter };
export { getChannelAndReferer } from '~scene/generate';
export { Clock } from './helper/clock';
export { uuidv4 } from './helper/uuid';
export {
  getDeviceId,
  COOKIE_TRAFFIC_RANDOM_NUMBER,
  CHANNEL_DEVICE_ID,
  CHANNEL_SESSION_ID,
  STORAGE_DEVICE_ID,
} from './helper/device-session';
export * from '@odoc/aiknowledge-report-common';
