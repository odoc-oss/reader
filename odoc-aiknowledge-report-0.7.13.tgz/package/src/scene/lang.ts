import Cookies from 'js-cookie';

export const defaultGetLanguage = () => {
  let i18nCookie = '';
  let i18nUA = '';
  if (typeof document !== 'undefined') {
    i18nCookie = Cookies.get('i18n') ?? '';
    i18nUA = navigator.userAgent.toLowerCase();
  }

  return i18nCookie || /readpaperi18n\//.test(i18nUA) ? 'en-US' : 'zh-CN';
};
