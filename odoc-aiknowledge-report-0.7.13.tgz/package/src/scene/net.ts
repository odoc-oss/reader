import 'promise-polyfill/src/polyfill';
import { AxiosRequestConfig, AxiosRequestHeaders } from 'axios'

export const get = (api: string, config?: AxiosRequestConfig) => {
  return createXhr(
    (xhr: XMLHttpRequest) => {
      const url = new URLSearchParams(config?.params)
      xhr.open('GET', `${api}?${url}`)
    },
    (xhr: XMLHttpRequest) => {
      xhr.responseType = 'json';
      xhr.send();
    },
    config?.headers
  )
}

export const post = (api: string, data: any, config?: AxiosRequestConfig) => {
  return createXhr(
    (xhr: XMLHttpRequest) => {
      xhr.open('POST', api);
    },
    (xhr: XMLHttpRequest) => {
      xhr.send(JSON.stringify(data));
    },
    config?.headers
  )
}

const createXhr = (
  open: (xhr: XMLHttpRequest) => void,
  send: (xhr: XMLHttpRequest) => void,
  headers?: AxiosRequestHeaders,
) => {
  const xhr = new XMLHttpRequest();

  open(xhr)

  xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');

  if (headers) {
    Object.keys(headers).forEach((key) => {
      xhr.setRequestHeader(key, headers![key] as string);
    })
  }

  return new Promise<any>((resolve, reject) => {
    xhr.onload = () => {
      resolve(xhr.response);
    };
    xhr.onerror = () => {
      reject(xhr.responseText);
    };
    send(xhr);
  });
}
