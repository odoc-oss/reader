import { GeneratedData } from '@odoc/aiknowledge-report-common';
import { getBrowserAndOs } from '../helper/browser';
import { detectPlatform } from '../helper/platform';
import { getDeviceId, getSessionId } from '../helper/device-session';
import { getChannelAndReferer } from '../helper/channel-referer';
import Cookies from 'js-cookie';
export { getChannelAndReferer } from '../helper/channel-referer';

export const generateData = async (): Promise<GeneratedData> => {
  const reportTime = Date.now();
  const { channel, referer, referer_detail } = await getChannelAndReferer();
  const platformInfo = detectPlatform();
  const browserAndOs = getBrowserAndOs(platformInfo.isElectron);
  const deviceId = await getDeviceId();
  const sessionId = await getSessionId();
  const abUuid = Cookies.get('ab-uuid');
  const { height, width } = window.screen;

  return {
    report_time: reportTime,
    channel: channel || 'none',
    referer: referer || 'none',
    referer_detail: referer_detail || 'none',
    platform: platformInfo.platform,
    ...browserAndOs,
    device_id: deviceId,
    session_id: sessionId,
    service_unique_code: abUuid || 'none',
    screen_size: JSON.stringify({
      height,
      width,
    }),
  };
};

export const defaultGetUrl = () => window.location.href;
