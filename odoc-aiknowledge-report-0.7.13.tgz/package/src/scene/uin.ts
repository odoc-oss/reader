import Cookies from 'js-cookie';

export const defaultGetUin = () => {
  return typeof document === 'undefined'
    ? ''
    : Cookies.get('aiKnowledge-UID') || '';
};
