/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { AxiosRequestConfig } from 'axios';

export const post = async (api: string, data: any, config?: AxiosRequestConfig) => { }
export const get = async (api: string, config?: AxiosRequestConfig) => { }
