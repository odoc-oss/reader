export const defaultGetUin = () => ''
