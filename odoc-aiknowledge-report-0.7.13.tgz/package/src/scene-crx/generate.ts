import { ChannelAndReferer, GeneratedData } from '@odoc/aiknowledge-report-common'

export const generateData = async (): Promise<GeneratedData> => {
  return {
    report_time: Date.now(),
  }
};

export const getChannelAndReferer = (): ChannelAndReferer => ({});

export const defaultGetUrl = () => 'https://www.readpaper.com';
