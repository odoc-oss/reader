export const defaultGetLanguage = () => '';
