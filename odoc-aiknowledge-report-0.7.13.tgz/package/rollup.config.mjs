import typescript from '@rollup/plugin-typescript';
import { terser } from 'rollup-plugin-terser';
import { nodeResolve } from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';

export const getCommonConfig = () => ({
  input: 'src/index.ts',
  output: [],
  resolve: {
    alias: {},
  },
  plugins: [
    nodeResolve(),
    commonjs(),
  ],
});

export const SCENE_PATH = '~scene'

const defaultConfig = getCommonConfig()
defaultConfig.plugins.unshift(typescript({
  tsconfig: './tsconfig.json',
}))
defaultConfig.resolve.alias[SCENE_PATH] = 'src/scene';
defaultConfig.output.push(
  {
    file: 'dist/report.js',
    format: 'cjs'
  },
  {
    file: 'dist/report.min.js',
    format: 'cjs',
    plugins: [terser()],
  },
);

export default defaultConfig
