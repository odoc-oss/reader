import { dateToString } from '../../src/helper/date';

describe('date', () => {
  test('dateToString', () => {
    const date = new Date();
    date.setFullYear(2022);
    date.setMonth(6);
    date.setDate(7);
    date.setHours(8);
    date.setMinutes(9);
    date.setSeconds(10);
    const string = dateToString(date);
    expect(string).toBe('2022-07-07 08-09-10');
  });
});
