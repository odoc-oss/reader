"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const date_1 = require("../../src/helper/date");
describe('date', () => {
    test('dateToString', () => {
        const date = new Date();
        date.setFullYear(2022);
        date.setMonth(6);
        date.setDate(7);
        date.setHours(8);
        date.setMinutes(9);
        date.setSeconds(10);
        const string = (0, date_1.dateToString)(date);
        expect(string).toBe('2022-07-07 08-09-10');
    });
});
