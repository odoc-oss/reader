module.exports = {
  root: true,
  extends: [
    'plugin:@typescript-eslint/eslint-recommended',
    'plugin:@typescript-eslint/recommended',
  ],
  parser: '@typescript-eslint/parser',
  "parserOptions": {
      project: "./tsconfig.json",
  },
  plugins: [
    '@typescript-eslint',
  ],
  rules: {
    '@typescript-eslint/no-explicit-any': 'off',
    '@typescript-eslint/no-non-null-assertion': 'off',
    'no-use-before-define': 'off',
    'no-nested-ternary': 'off',
    quotes: ['error', 'single'],
    'import/prefer-default-export': 'off',
  },
  ignorePatterns: ['src/**/*.test.ts', 'src/frontend/generated/*'],
  // overrides: [
  //   {
  //     files: ['*.ts', '*.tsx'], // Your TypeScript files extension

  //     // As mentioned in the comments, you should extend TypeScript plugins here,
  //     // instead of extending them outside the `overrides`.
  //     // If you don't want to extend any rules, you don't need an `extends` attribute.
  //     extends: [
  //       'plugin:@typescript-eslint/eslint-recommended',
  //       'plugin:@typescript-eslint/recommended',
  //     ],

  //     parserOptions: {
  //       project: ['./tsconfig.json'], // Specify it only for TypeScript files
  //     },

  //     rules: {
  //       '@typescript-eslint/no-explicit-any': 'off',

  //     },
  //   },
  // ],
};
