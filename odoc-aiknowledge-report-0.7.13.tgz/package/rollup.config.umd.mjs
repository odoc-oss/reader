import typescript from '@rollup/plugin-typescript';
import { getCommonConfig, SCENE_PATH } from './rollup.config.mjs';
import { babel } from '@rollup/plugin-babel';

const umdConfig = getCommonConfig();
umdConfig.plugins.unshift(typescript({
  tsconfig: './tsconfig.json',
}))

umdConfig.plugins.push(babel({ babelHelpers: 'bundled' }))

umdConfig.resolve.alias[SCENE_PATH] = 'src/scene';
umdConfig.output.push({
  file: 'dist/report.umd.js',
  format: 'umd',
  name: 'ReadPaperReporter',
},
{
  file: 'dist/report.umd.min.js',
  format: 'umd',
  name: 'ReadPaperReporter',
  plugins: [terser()],
},)

export default umdConfig
