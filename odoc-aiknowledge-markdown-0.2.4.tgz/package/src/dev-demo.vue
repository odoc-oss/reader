<template>
  <main>
    <div class="wrap">
      <Markdown
        :editing="editing"
        :raw="raw"
        :upload="todoUpload"
        uniq-id="demo-md"
        width="300px"
        @blur="blur($event)"
        @submit="submit($event)"
        @click-view="editing = true"
      />
    </div>
    <Tag
      :list="mockTagList"
      :selected="mockSelected"
      @input-tag="createTag"
      @select-tag="bindTag"
      @remove="removeTag"
    />
  </main>
</template>

<script setup lang="ts">
import type { AnnotateTag } from '@odoc/types-readpaper-proto/types/cn/edu/idea/cloud/aiKnowledge/notev2/Common';
import { ref } from 'vue';
import Markdown from './components/markdown-entry.vue';
import Tag from './components/tag-entry.vue';

const raw = ref(`
texttexttext

# h1h1h1h1h1
## h2h2h2h2h2
### h3h3h3h3h3
#### h4h4h4h4h4

*boldboldbold*

\`inlinecodecodecodecode\`

\`\`\`
block code
block code
\`\`\`

- itemitemitemitem
- itemitemitem
  - subitemsubitem

1. oneoneone
2. twotwotwo
4. threethree

> quotequotequote
> > subquotesubquote

[hyperlinkhyperlink](https://www.google.com)

$$

\\begin{aligned}

P(B|A)&=\\frac{P(AB)}{P(A)}\\

P(\\overline{B}|A)&=1-P(B|A)=1-\\frac{P(AB)}{P(A)}

\\end{aligned}

$$


:cry:

![meme](https://img.win3000.com/m00/e9/81/127156083ab2c26a5d3ee692447740f7.jpg)
`);

const mockTagList = ref<AnnotateTag[]>([
  {
    tagId: '1',
    tagName: '11111',
    latestUseTime: '7777',
    relationId: '',
  },
  {
    tagId: '2',
    tagName: '222222',
    latestUseTime: '999999',
    relationId: '',
  },
  {
    tagId: '3',
    tagName: '3333333',
    latestUseTime: '11',
    relationId: '',
  },
]);

const mockSelected = ref([mockTagList.value[2]]);

const createTag = (name: string) => {
  console.log('createTag', name);
  const newTag = {
    tagId: String(Math.random()),
    tagName: name,
    latestUseTime: '',
    relationId: '',
  };
  mockTagList.value.push(newTag);
  mockSelected.value.push(newTag);
};
const bindTag = (id: string) => {
  console.log('bindTag', id);
  mockSelected.value.push(mockTagList.value.find((item) => item.tagId === id)!);
};
const removeTag = (id: string) => {
  mockSelected.value = mockSelected.value.filter((item) => item.tagId !== id);
};
const editing = ref(false);
const submit = (content: string) => {
  console.log('submit', { content });
  raw.value = content;
  editing.value = false;
};
const blur = (content: string) => {
  console.log('blur', content);
};
const todoUpload = async (src: string) => {
  console.log({ src });
  return src;
};
</script>

<style scoped>
main {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
}

.wrap {
  outline: solid 1px lightblue;
}
.idea-markdown-view-container {
  max-height: 800px;
}
</style>
