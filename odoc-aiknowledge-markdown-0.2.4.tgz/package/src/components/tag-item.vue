<template>
  <div
    class="idea-tag-item-container"
    :style="{ paddingRight: readonly ? '8px' : '21px' }"
  >
    <div class="idea-tag-item-name">
      {{ name }}
    </div>
    <div
      v-if="!readonly"
      class="idea-tag-item-remove"
      @click="emit('remove')"
    >
      <CloseOutlined />
    </div>
  </div>
</template>

<script setup lang="ts">
import { CloseOutlined } from '@ant-design/icons-vue';

defineProps<{
  name: string;
  readonly?: boolean;
}>();

const emit = defineEmits<{
  (event: 'remove'): void;
}>();
</script>

<style>
.idea-tag-item-container {
  flex-basis: 30px;
  position: relative;
  outline: solid 1px lightblue;
  margin-right: 4px;
  margin-bottom: 4px;
  display: inline-block;
  max-width: 164px;
  height: 20px;
  padding-left: 8px;
  white-space: nowrap;
  font-size: 12px;
  border-radius: 2px;
}

.idea-tag-item-name {
  height: 100%;
  line-height: 20px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.idea-tag-item-remove {
  position: absolute;
  width: 16px;
  top: 50%;
  transform: translateY(-50%);
  right: 0;
  cursor: pointer;
}

.idea-tag-item-remove > * {
  scale: 0.8;
}
</style>
