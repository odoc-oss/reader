<template>
  <div
    class="idea-tag-select-container"
    @scroll.stop
    @wheel.stop
    @mousewheel.stop
  >
    <div
      v-for="item in list"
      :key="item.tagId"
      class="idea-tag-select-item"
      :class="[cursor === item.tagId && 'idea-tag-select-cursor']"
      :data-tag-id="item.tagId"
      :title="item.tagName"
      @click="emit('select', item.tagId)"
      @mouseenter="emit('hover', item.tagId)"
    >
      {{ item.tagName }}
    </div>
  </div>
</template>

<script setup lang="ts">
import type { AnnotateTag } from '@odoc/types-readpaper-proto/types/cn/edu/idea/cloud/aiKnowledge/notev2/Common';
import { watch } from 'vue';

const props = defineProps<{
  list: AnnotateTag[];
  cursor: AnnotateTag['tagId'];
}>();

const emit = defineEmits<{
  (event: 'select', id: AnnotateTag['tagId']): void;
  (event: 'hover', id: AnnotateTag['tagId']): void;
}>();

watch(
  () => props.cursor,
  () => {
    console.warn('cursor');
    if (props.cursor) {
      const child = document.querySelector(
        `.idea-tag-select-item[data-tag-id="${props.cursor}"]`
      )!;
      const parent = child.parentElement!;
      const childBound = child.getBoundingClientRect();
      const parentBound = parent.getBoundingClientRect();
      const topDistance = childBound.top - parentBound.top;
      if (topDistance < 0) {
        parent.scrollTop += topDistance;
        return;
      }

      const bottomDistance = childBound.bottom - parentBound.bottom;
      if (bottomDistance > 0) {
        parent.scrollTop += bottomDistance;
      }
    }
  }
);
</script>

<style>
.idea-tag-select-container {
  position: absolute;
  box-sizing: border-box;
  top: 120%;
  left: 1px;
  width: 92px;
  padding-top: 4px;
  box-sizing: border-box;
  border-width: 1px;
  border-style: solid;
  border-color: #ffffff26;
  border-radius: 2px;
  box-shadow: 2px 6px 12px 4px rgba(0, 0, 0, 0.08),
    1px 3px 8px 1px rgba(0, 0, 0, 0.12);

  z-index: 9;
}

.idea-tag-select-item {
  width: 100%;
  height: 32px;
  line-height: 32px;
  box-sizing: border-box;
  padding-left: 11px;
  padding-right: 11px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
  font-family: 'PingFang SC';
}

.idea-tag-select-cursor {
  background-color: lightblue;
}
</style>
