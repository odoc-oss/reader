<template>
  <MarkdownEdit
    v-if="editing"
    :raw="content"
    :width="width"
    :uniq-id="uniqId"
    :upload="upload"
    :placeholder="placeholder"
    :min-rows="minRows"
    :max-rows="maxRows"
    :allow-enter="allowEnter"
    :maxLength="maxLength"
    @change="change($event)"
    @blur="blur()"
    @submit="submit()"
  />
  <MarkdownView
    v-else
    :raw="raw"
    :width="width"
    @clickView="emit('clickView')"
  />
</template>

<script setup lang="ts">
import { watch, ref } from 'vue';
import MarkdownEdit from './markdown-edit.vue';
import MarkdownView from './markdown-view.vue';
import {
  IMAGE_PLACEHOLDER_UPLOADING_REGEX,
  IMAGE_PLACEHOLDER_ERROR,
} from './helper';

const props = defineProps<{
  raw: string;
  width?: string;
  uniqId?: string;
  upload(url: File | string): Promise<string>;

  editing: boolean;
  placeholder?: string;
  minRows?: number;
  maxRows?: number;
  allowEnter?: boolean;
  maxLength?: number;
}>();

const emit = defineEmits<{
  (event: 'blur', content: string): void;
  (event: 'submit', content: string): void;
  (event: 'clickView'): void;
}>();

const content = ref(props.raw);
const change = (value: string) => {
  content.value = value;
};
const blur = () => {
  if (props.editing) {
    replace();
    emit('blur', content.value);
  }
};
const submit = () => {
  replace();
  emit('submit', content.value);
};
const replace = () => {
  content.value = content.value.replace(
    IMAGE_PLACEHOLDER_UPLOADING_REGEX,
    IMAGE_PLACEHOLDER_ERROR
  );
};

watch(
  () => props.raw,
  () => {
    content.value = props.raw;
  },
  { immediate: true }
);
</script>

<style></style>
