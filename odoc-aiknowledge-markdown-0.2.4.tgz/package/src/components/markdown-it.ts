import markdownIt from 'markdown-it';
import mathJax3 from 'markdown-it-mathjax3';
import emoji from 'markdown-it-emoji';
import { IMAGE_PLACEHOLDER_ERROR } from './helper';

export const mdi = markdownIt({
  html: true,
  linkify: true,
  typographer: true,
});

mdi.use(mathJax3);
mdi.use(emoji);

const regexImage = new RegExp(
  `<img\\s+src="${encodeURIComponent(
    IMAGE_PLACEHOLDER_ERROR
  )}"\\s+alt="([^"]*)">`,
  'g'
);

export const markdownToHtml = (raw: string) => {
  const html = mdi
    .render(raw)
    .trim()
    .replace(/\n/g, '<br>')
    .replace(/<table>.*<\/table>/g, (searchValue) => {
      return searchValue.replace(/<br>/g, '');
    })
    .replace(regexImage, (img, alt) => {
      return `<div class="idea-image-error" title="${IMAGE_PLACEHOLDER_ERROR}"><i class="aiknowledge-icon icon-image"></i>${alt}</div>`;
    });
  return html;
};
