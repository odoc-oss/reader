<template>
  <TextArea
    v-model:value="value"
    :class="[MARDOWN_EDITOR_CLASS_NAME]"
    :style="{ ...(width && { width }) }"
    :data-id="uniqId || defaultUniqId"
    :placeholder="placeholder || ''"
    :maxLength="maxLength || 10000"
    @blur="blur()"
    @press-enter="enter($event)"
    @click.stop="() => {}"
    :autoSize="{ minRows: minRows || 1, maxRows: maxRows || 18 }"
  ></TextArea>
</template>

<script setup lang="ts">
import { Input } from 'ant-design-vue';
import { computed, nextTick, onMounted } from 'vue';
import { IMAGE_PLACEHOLDER_ERROR, IMAGE_PLACEHOLDER_PREFIX } from './helper';

const defaultUniqId = Math.random().toString();
const MARDOWN_EDITOR_CLASS_NAME = 'idea-markdown-edit-container';
const getMarkdownEditorElement = () =>
  document.querySelector<HTMLTextAreaElement>(
    `.${MARDOWN_EDITOR_CLASS_NAME}[data-id="${props.uniqId || defaultUniqId}"]`
  )!;

const { TextArea } = Input;

const props = defineProps<{
  raw: string;
  width?: string;
  uniqId?: string;
  upload(image: File | string): Promise<string>;
  placeholder?: string;
  minRows?: number;
  maxRows?: number;
  allowEnter?: boolean;
  maxLength?: number;
}>();

const emit = defineEmits<{
  (event: 'change', value: string): void;
  (event: 'blur'): void;
  (event: 'submit'): void;
}>();

const value = computed({
  get() {
    return props.raw;
  },
  set(val) {
    emit('change', val);
  },
});

const paste = (event: ClipboardEvent) => {
  const images = [...event.clipboardData!.files].filter((file) =>
    file.type.startsWith('image/')
  );
  if (images.length) {
    event.preventDefault();
    return pasteImageFile(images);
  }

  const textHtml = event.clipboardData?.getData('text/html') ?? '';
  if (textHtml) {
    event.preventDefault();
    return pasteHtml(textHtml);
  }
};

const NEW_LINE = '\n';

const uploadWithPlaceholder = (image: Parameters<typeof props.upload>[0]) => {
  const placeholder = Math.random()
    .toString()
    .replace('0.', IMAGE_PLACEHOLDER_PREFIX);
  (async () => {
    let url = '';
    try {
      url = await props.upload(image);
    } catch (error) {
      url = IMAGE_PLACEHOLDER_ERROR;
    }

    const newValue = props.raw.replace(placeholder, url);
    value.value = newValue;
  })();
  return placeholder;
};

const pasteImageFile = (imageList: File[]) => {
  const markdownImageList = imageList.map((file) => {
    const placeholder = uploadWithPlaceholder(file);
    return createMarkdownImage(placeholder, file.name);
  });
  const content = markdownImageList.join(NEW_LINE);
  insertAndSelect(content);
};

const pasteHtml = (textHtml: string) => {
  console.log({ pasteHtml: textHtml });
  const div = document.createElement('div');
  div.innerHTML = textHtml;
  const removeDoubleNewLine = (child: typeof div.firstChild) => {
    const doubleNewLine = NEW_LINE + NEW_LINE;
    if (child instanceof Text && child.textContent === doubleNewLine) {
      div.removeChild(child);
    }
  };
  removeDoubleNewLine(div.firstChild);
  removeDoubleNewLine(div.lastChild);
  const fragmentList: string[] = walk(div.childNodes);
  const content = fragmentList.join('');
  insertAndSelect(content);
};

const insertAndSelect = async (content: string) => {
  console.log({ event: 'paste', content });
  const { element, selectionStart } = await insert(content);
  element.selectionStart = selectionStart;
  element.selectionEnd = selectionStart;
};

const walk = (nodeList: NodeList, fragmentList: string[] = []) => {
  for (const node of nodeList) {
    if (node instanceof Text) {
      fragmentList.push(node.textContent!);
    } else if (node instanceof HTMLImageElement) {
      fragmentList.push(transformImage(node));
    } else if (node instanceof HTMLAnchorElement) {
      fragmentList.push(transformAnchor(node));
    } else if (node instanceof HTMLBRElement) {
      fragmentList.push(NEW_LINE);
    } else if (node instanceof HTMLParagraphElement) {
      fragmentList.push(NEW_LINE);
      walk(node.childNodes, fragmentList);
      fragmentList.push(NEW_LINE);
    } else if (!(node instanceof HTMLScriptElement)) {
      walk(node.childNodes, fragmentList);
    }
  }

  return fragmentList;
};

const transformAnchor = (anchor: HTMLAnchorElement) => {
  const anchorFragmentList = walk(anchor.childNodes);
  return createMarkdownLink(anchor.href, anchorFragmentList.join());
};

const createMarkdownLink = (href: string, text = '') => {
  return `[${text || href}](${href})`;
};

const transformImage = (image: HTMLImageElement) => {
  console.log({ image });
  const { src } = image;

  if (!src.startsWith('http')) {
    const placeholder = uploadWithPlaceholder(src);
    return createMarkdownImage(placeholder, image.alt);
  }

  const internal = new URL(src).hostname.includes('idea.edu.cn');
  // 站外图片显示为链接
  return internal
    ? createMarkdownImage(src, image.alt)
    : createMarkdownLink(src, image.alt);
};

const createMarkdownImage = (url: string, alt = '') => {
  return `![${alt}](${url})`;
};

onMounted(() => {
  const element = getMarkdownEditorElement();
  element.focus();
  element.addEventListener('paste', paste);
  element.addEventListener('scroll', stopPropagation);
  element.addEventListener('wheel', stopPropagation);
  element.addEventListener('mousewheel', stopPropagation);
});

const stopPropagation = (event: Event) => {
  event.stopPropagation();
};

const enter = async (event: KeyboardEvent) => {
  if (event.shiftKey) {
    return;
  }

  if (event.ctrlKey || event.altKey || event.metaKey) {
    const { element, selectionStart } = await insert(NEW_LINE);
    element.selectionStart = selectionStart + 1;
    element.selectionEnd = element.selectionStart;
    return;
  }

  if(!props.allowEnter) event.preventDefault();

  emit('submit');
};

const blur = async () => {
  console.warn('blur');
  await nextTick();
  setTimeout(() => {
    emit('blur');
  }, 300);
};

const insert = async (content: string) => {
  const element = getMarkdownEditorElement();
  const { selectionStart, selectionEnd } = element;
  const oldValue = value.value;
  const newValue =
    oldValue.slice(0, selectionStart) + content + oldValue.slice(selectionEnd);
  value.value = newValue;
  await nextTick();
  return { element, selectionStart };
};
</script>
