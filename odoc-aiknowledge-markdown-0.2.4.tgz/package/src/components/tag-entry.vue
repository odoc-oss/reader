<template>
  <div class="idea-tag-entry-container">
    <TagItem
      v-for="item in selected"
      :key="item.tagId"
      :name="item.tagName"
      @remove="emit('remove', item.tagId)"
      @click.stop
    />
    <div v-if="!inputVisible" class="idea-tag-add" @click.stop="inputStart()">
      <PlusOutlined />
      {{ tagLabel || '标签' }}
    </div>
    <div class="idea-tag-entry-edit" @click.stop>
      <input
        v-if="inputVisible"
        v-model="inputValue"
        ref="inputRef"
        class="idea-tag-input"
        @keypress.enter="inputSubmit()"
        @keydown="arrow($event)"
      />
      <TagSelect
        v-if="inputVisible && filtered.length"
        :list="filtered"
        :cursor="cursor"
        @select="selectSubmit($event)"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, ref, watch } from 'vue';
import { PlusOutlined } from '@ant-design/icons-vue';
import type { AnnotateTag } from '@odoc/types-readpaper-proto/types/cn/edu/idea/cloud/aiKnowledge/notev2/Common';

import TagSelect from './tag-select.vue';
import TagItem from './tag-item.vue';

const props = defineProps<{
  list: AnnotateTag[];
  selected: AnnotateTag[];
  tagLabel?: string;
}>();

const emit = defineEmits<{
  (event: 'remove', id: AnnotateTag['tagId']): void;
  (event: 'selectTag', id: AnnotateTag['tagId']): void;
  (event: 'inputTag', name: AnnotateTag['tagName']): void;
}>();

const inputRef = ref<HTMLInputElement | null>(null);
const inputVisible = ref(false);
const inputValue = ref('');
const inputStart = async () => {
  console.log('inputStart');
  inputVisible.value = true;
  await nextTick();
  inputRef.value?.focus();
  setTimeout(() => {
    document.body.addEventListener('click', inputEnd, { once: true });
  }, 300);
};
const inputEnd = () => {
  inputVisible.value = false;
  inputValue.value = '';
  document.body.removeEventListener('click', inputEnd);
};
const inputSubmit = () => {
  if (cursor.value) {
    selectSubmit(cursor.value);
    return;
  }

  if (!inputValue.value) {
    inputEnd();
    return;
  }

  const equal = (item: AnnotateTag) => item.tagName === inputValue.value;
  const selectedTag = props.selected.some(equal);
  if (selectedTag) {
    return;
  }

  const selectTag = props.list.find(equal);
  if (selectTag) {
    selectSubmit(selectTag.tagId);
    return;
  }

  emit('inputTag', inputValue.value);
  inputEnd();
};

const selectSubmit = (id: AnnotateTag['tagId']) => {
  emit('selectTag', id);
  inputEnd();
};

const cursor = ref('');

const filtered = computed(() => {
  const set = new Set(props.selected.map((item) => item.tagId));
  return props.list
    .filter((item) => !set.has(item.tagId))
    .filter(
      (item) => !inputValue.value || item.tagName.includes(inputValue.value)
    )
    .sort((itemA, itemB) => {
      const getTime = (tag: AnnotateTag) => Number(tag.latestUseTime) || 0;
      return getTime(itemB) - getTime(itemA);
    })
    .slice(0, 5);
});

watch(filtered, () => {
  if (!filtered.value.some((item) => item.tagId === cursor.value)) {
    cursor.value = '';
  }
});

const arrow = (event: KeyboardEvent) => {
  const up = 'ArrowUp';
  const down = 'ArrowDown';
  const escape = 'Escape';

  if (escape === event.key) {
    inputEnd();
    return;
  }

  if (up !== event.key && down !== event.key) {
    return;
  }

  event.preventDefault();
  event.stopPropagation();

  const currentIndex = filtered.value.findIndex(
    (item) => item.tagId === cursor.value
  );

  if (up === event.key) {
    if (currentIndex === 0) {
      cursor.value = '';
    } else if (currentIndex !== -1) {
      cursor.value = filtered.value[currentIndex - 1].tagId;
    } else if (filtered.value.length) {
      cursor.value = filtered.value[filtered.value.length - 1].tagId;
    }

    return;
  }

  if (currentIndex === filtered.value.length - 1) {
    cursor.value = '';
  } else if (filtered.value.length) {
    cursor.value = filtered.value[currentIndex + 1].tagId;
  }
};
</script>

<style>
.idea-tag-entry-container {
  outline: solid 1px lightblue;
  display: flex;
  justify-content: flex-start;
  align-items: flex-start;
  flex-wrap: wrap;
}

.idea-tag-entry-container .idea-tag-add {
  visibility: hidden;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  height: 20px;
  width: 50px;
  cursor: pointer;
  border-radius: 2px;
  margin-bottom: 4px;
  line-height: 20px;
  font-size: 12px;
}

.idea-tag-entry-container:hover .idea-tag-add {
  visibility: visible;
}

.idea-tag-entry-container .idea-tag-add > span {
  margin-right: 2px;
}

.idea-tag-entry-container .idea-tag-add > span > * {
  font-size: 10px;
}

.idea-tag-entry-edit {
  position: relative;
  display: inline-block;
  height: 20px;
  top: -2px;
  margin-bottom: 4px;
}

.idea-tag-input {
  display: inline-block;
  box-sizing: border-box;
  padding: 1px 3px;
  width: 94px;
  height: 22px;
  border-radius: 2px;
  outline: 0;
}
</style>
