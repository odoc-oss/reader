export interface EditEmits {
  (event: 'change', value: string): void;
  (event: 'blur'): void;
  (event: 'enter', keyboardEvent: KeyboardEvent): void;
}

export interface MarkdownEmits extends EditEmits {
  (event: 'clickView'): void;
}

export const IMAGE_PLACEHOLDER_PREFIX = '图片上传中';
export const IMAGE_PLACEHOLDER_UPLOADING_REGEX = new RegExp(
  `${IMAGE_PLACEHOLDER_PREFIX}\\d+`,
  'g'
);
export const IMAGE_PLACEHOLDER_ERROR = '图片上传失败';

export const openWindow = (url: string) => {
  const anchor = document.createElement('a');
  anchor.target = '_blank';
  anchor.href = url;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
};
