<template>
  <div
    class="idea-markdown-view-container"
    :style="{ ...(width && { width }) }"
    v-html="cooked"
    @click="click($event)"
  ></div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { openWindow } from './helper';
import { markdownToHtml } from './markdown-it';

const props = defineProps<{
  raw: string;
  width?: string;
}>();

const emit = defineEmits<{
  (event: 'clickView'): void;
}>();

const cooked = computed(() => {
  return markdownToHtml(props.raw);
});

const click = (event: MouseEvent) => {
  let href = '';
  let target = event.target as unknown as HTMLElement;
  while (target !== event.currentTarget) {
    if (target instanceof HTMLAnchorElement) {
      ({ href } = target);
      break;
    }

    target = target.parentElement!;
  }

  if (href) {
    event.preventDefault();
    event.stopPropagation();
    openWindow(href);
  } else {
    emit('clickView');
  }
};
</script>

<style>
.idea-markdown-view-container {
  overflow-x: hidden;
  word-break: break-all;
}

.idea-markdown-view-container p,
.idea-markdown-view-container ul {
  font-size: 14px;
}

.idea-markdown-view-container * {
  margin: 0;
  padding: 0;
}

.idea-markdown-view-container th,
.idea-markdown-view-container td {
  padding-left: 6px;
  padding-right: 6px;
  padding-top: 3px;
  padding-bottom: 3px;
}

.idea-markdown-view-container ol,
.idea-markdown-view-container ul {
  padding-left: 20px;
}

.idea-markdown-view-container ol,
.idea-markdown-view-container ol li {
  list-style: decimal !important;
  list-style-type: decimal !important;
}

.idea-markdown-view-container ul,
.idea-markdown-view-container ul li {
  list-style: disc !important;
  list-style-type: disc !important;
}

.idea-markdown-view-container svg,
.idea-markdown-view-container img {
  max-width: 100%;
  height: auto;
}

.idea-markdown-view-container blockquote {
  padding-left: 8px;
  padding-right: 8px;
  padding-top: 10px;
  padding-bottom: 10px;
  border-left-width: 4px;
  border-left-style: solid;
  border-left-color: #eee;
}
.idea-markdown-view-container blockquote blockquote {
  margin-top: 10px;
}

.idea-markdown-view-container ol br,
.idea-markdown-view-container ul br,
.idea-markdown-view-container blockquote > br {
  display: none;
}

.idea-markdown-view-container pre {
  display: block;
  padding: 10px;
  font-size: 13px;
  line-height: 1.42857143;
  word-break: break-all;
  word-wrap: break-word;
  background-color: rgba(255,255,255,0.08);
  border-radius: 4px;
}

.idea-markdown-view-container .idea-image-error {
  color: #bf4330;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}
.idea-markdown-view-container .idea-image-error > i {
  margin-right: 8px;
}
</style>
