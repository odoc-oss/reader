import MarkdownEntry from './components/markdown-entry.vue';
import MarkdownEdit from './components/markdown-edit.vue';
import MarkdownView from './components/markdown-view.vue';

import TagEntry from './components/tag-entry.vue';
import TagItem from './components/tag-item.vue';

export const IdeaMarkdown = MarkdownEntry;
export const IdeaTag = TagEntry;

export const MarkdownEditor = MarkdownEdit;
export const MarkdownViewer = MarkdownView;
export const IdeaTagItem = TagItem;

export { mdi, markdownToHtml } from './components/markdown-it';
