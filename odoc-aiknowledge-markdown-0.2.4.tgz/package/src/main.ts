import { createApp } from 'vue';
import DevDemo from './dev-demo.vue';

createApp(DevDemo).mount('#app');
