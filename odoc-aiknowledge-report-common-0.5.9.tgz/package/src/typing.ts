export interface Config {
  host: string;
  api: string;
  axios?: {
    post(api: string, data: any, config?: any): Promise<any>;
    get?(api: string, config?: { params: any, }): Promise<any>;
  };
  getUin?(): string;
  getLanguage?(): string;
}

export interface ChannelAndReferer {
  channel?: string;
  referer?: string;
  referer_detail?: string;
}

/** 自动生成的字段，无需开发填充 */
export interface GeneratedData extends ChannelAndReferer {
  report_time: number;
  device_id?: string;
  session_id?: string;
  platform?: string;
  os_name?: string;
  browser_type?: string;
  browser_version?: string;
  language?: string;
  service_unique_code?: string;
  screen_size?: string;
}

/** 全局字段，配置一次即可 */
export interface GlobalData {
  app_version: string;
}

/** 标准字段，每个埋点都要有，但值可能不一样 */
export interface EventInfoRaw {
  event_code: string;
  touin?: string;
  experiment_id?: string;
  tactics_id?: string;
}

export interface EventInfoCreate {
  event_time: number;
  url: string;
}

export interface UserInfo {
  uin: string;
}

/** 默认字段 */
export type BaseInfo = GeneratedData & UserInfo & GlobalData;

/** 业务字段 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type EventData = Record<string, any>;

export interface ReportEvent {
  eventInfo: EventInfoRaw & EventInfoCreate;
  eventData: EventData;
}

export interface ReportBody {
  baseInfo: BaseInfo;
  eventList: ReportEvent[];
}
