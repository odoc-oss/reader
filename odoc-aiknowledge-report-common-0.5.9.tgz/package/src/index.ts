import { ConfigItem, GetExperimentReq, GetExperimentResp } from '@odoc/types-readpaper-proto/types/cn/edu/idea/cloud/ab/ABTestInfo'
import generateSignature from '@odoc/aiknowledge-api-signature';

import { Batch } from './batch';
import {
  Config,
  BaseInfo,
  EventData,
  GeneratedData,
  GlobalData,
  ReportEvent,
  ReportBody,
  EventInfoRaw,
  EventInfoCreate,
} from './typing';

const getDefaultGlobalData = (): GlobalData => {
  const reg = /ReadPaper(I18n)?\/(([0-9]+.)+[0-9]+)/;
  const m = typeof window === 'undefined' ? null : window.navigator.userAgent.match(reg);
  return {
    app_version: m?.[2] ?? '',
  };
};

export const DEFAULT_API = '/report/collection_tracking0';
const AB_CONFIG_API = '/api/microService-app-aiKnowledge/ab/get';

export abstract class AbstractReporter {
  public config: Config = {
    host: '',
    api: DEFAULT_API,
    axios: undefined,
    getUin: undefined,
  };

  private abConfigRequest: null | Promise<ConfigItem> = null;

  public get abConfigItem() {
    if (!this.abConfigRequest) {
      this.abConfigRequest = (async (): Promise<ConfigItem> => {
        const defaultItem = {} as ConfigItem
        return defaultItem
        // const url = new URL(this.getUrl())
        // const params: GetExperimentReq = {
        //   path: url.pathname,
        // };
        // try {
        //   const response = await this
        //     .config
        //     .axios!
        //     .get
        //     ?.(this.config.host + AB_CONFIG_API, { params });
        //   const data = response?.data as GetExperimentResp;
        //   return data?.item ?? defaultItem;
        // } catch (error) {
        //   return defaultItem;
        // }
      })();
    }

    return this.abConfigRequest;
  }

  public set abConfigItem(value) {
    this.abConfigRequest = value;
  }

  public abstract headers: Record<string, string>;

  public abstract getUrl(): string;

  public globalData = getDefaultGlobalData();

  public abstract generateData(): Promise<GeneratedData>;

  public initing: null | Promise<void> = null;

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  protected async createPayload(eventList: ReportEvent[]): Promise<ReportBody> {
    const generatedData = await this.generateData();
    const baseInfo: BaseInfo = {
      ...generatedData,
      app_version: this.globalData.app_version,
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      uin: this.config.getUin!(),
      language: this.config.getLanguage?.() || '',
    };

    return {
      baseInfo,
      eventList,
    };
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  public async report(eventInfoRaw: EventInfoRaw, eventData: EventData) {
    if (this.initing) {
      await this.initing;
    }

    const abConfigItem = await this.abConfigItem;

    const eventInfoCreate: EventInfoCreate = {
      event_time: Date.now(),
      url: this.getUrl(),
    }

    const event: ReportEvent = {
      eventInfo: {
        experiment_id: abConfigItem.experimentId,
        tactics_id: abConfigItem.strategyId,
        ...eventInfoRaw,
        ...eventInfoCreate,
      },
      eventData,
    };

    this.batch.add(event);
  }

  public batch = new Batch(async (eventList: ReportEvent[]) => {
    return this.post(await this.createPayload(eventList));
  });

  private post(body: ReportBody) {
    let { api } = this.config;

    const signature = generateSignature(JSON.stringify(body));
    if (signature) {
      const urlHelper = new URL(api, 'https://www.readpaper.com');
      api += urlHelper.search ? '&' : '?';
      api += signature;
    }

    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    return this.config.axios!.post(this.config.host + api, body, {
      headers: this.headers,
    });
  }
}

export * from './typing';
export * from './batch';
