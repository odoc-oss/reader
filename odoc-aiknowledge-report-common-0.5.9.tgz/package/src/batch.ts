/**
 * 触发时机
 * 1. 周期
 * 2. 满了
 * 3. 退出，需在具体项目监听执行flush
 */
export class Batch<Data> {
  protected list: Data[] = [];

  protected timoutId: NodeJS.Timeout | null = null;

  public interval = 500;

  public constructor(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public exec: (dataList: Data[]) => Promise<any>,
    public size: number = 10,
    maxInterval = 3000,
  ) {
    const changeInterval = () => {
      this.interval = maxInterval;
    };

    if (this.interval > maxInterval) {
      changeInterval();
    } else {
      setTimeout(changeInterval, 10 * 1000);
    }
  }

  public add(data: Data) {
    this.list.push(data);

    const order = () => {
      this.timoutId = setTimeout(() => {
        this.timoutId = null;
        this.rawFlush();
      }, this.interval);
    };

    const now = () => {
      if (this.timoutId !== null) {
        this.clearTimeout();
      }

      this.rawFlush();
    };

    if (this.list.length === this.size) {
      now();
    } else if (this.timoutId === null) {
      order();
    }
  }

  private clearTimeout() {
    clearTimeout(this.timoutId as NodeJS.Timeout);
    this.timoutId = null;
  }

  private rawFlush() {
    const { list } = this;
    this.list = [];
    return this.exec(list);
  }

  // eslint-disable-next-line consistent-return
  public flush() {
    if (this.timoutId !== null) {
      this.clearTimeout();

      if (this.list.length) {
        return this.rawFlush();
      }
    }
  }
}
